-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 12 2015 г., 16:46
-- Версия сервера: 5.5.36-34.0-632.precise
-- Версия PHP: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `printtex_new`
--

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block`
--

DROP TABLE IF EXISTS `k2_block`;
CREATE TABLE IF NOT EXISTS `k2_block` (
`ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL DEFAULT '',
  `BLOCK_GROUP` smallint(6) NOT NULL DEFAULT '0',
  `CATEGORY` int(11) NOT NULL,
  `FORM_EDIT_ELEMENT` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block`
--

INSERT INTO `k2_block` (`ID`, `NAME`, `BLOCK_GROUP`, `CATEGORY`, `FORM_EDIT_ELEMENT`) VALUES
(1, 'Текстовая страница', 4, 0, ''),
(2, 'Карта сайта', 4, 0, ''),
(6, 'Блок услуг', 9, 0, ''),
(7, 'Обратная связь', 4, 0, ''),
(26, 'Блок о компании', 9, 0, ''),
(27, 'Услуги', 4, 0, ''),
(28, 'Оборудование', 4, 1, ''),
(29, 'Блок наши возможности', 9, 0, ''),
(30, 'Блок наши клиенты', 9, 0, ''),
(31, 'Слайдшоу(эксперементальный цех)', 4, 0, ''),
(32, 'Портфолио', 4, 0, ''),
(33, 'Тарифы на печать', 4, 0, '/k2/dev/block/33/form_edit_element.php'),
(34, 'Заявка', 4, 0, ''),
(35, 'Блок нам доверяют', 9, 0, ''),
(36, 'Блок слайдер', 9, 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block1`
--

DROP TABLE IF EXISTS `k2_block1`;
CREATE TABLE IF NOT EXISTS `k2_block1` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `TEXT` mediumtext NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block1`
--

INSERT INTO `k2_block1` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `TEXT`) VALUES
(13, '2012-11-27 09:25:56', '0000-00-00 00:00:00', 1, 0, 1, 10, 53, 0, '<p>Страница не найдена, воспользуйтесь <a href="/site-map/">картой сайта</a> для поиска нужной информации</p>'),
(14, '2012-11-27 12:26:26', '2014-10-21 13:40:58', 1, 1, 0, 10, 60, 0, '<p>Для разработки новых моделей изделий на нашем предприятии сформирован экспериментальный участок. В штате предприятия 3 профессиональных конструктора, лаборанты, технолог. Участок оснащен современным программным обеспечением, позволяющим конструировать изделия различной сложности, и делать градацию размерно-ростового ряда. Наши профессиональные дизайнеры разработают по индивидуальным требованиям интересные модели для новых коллекций заказчиков, предложат оригинальные дизайны декора, порекомендуют подходящее полотно.&nbsp; В нашем экспериментальном участке мы предлагаем:</p>\r\n<p>&mdash; разработку лекал по чертежам клиента</p>\r\n<p>&mdash; разработку моделей и их конструирование</p>\r\n<p>&mdash; разработку принтов и технических карт</p>\r\n<p>&mdash; отшив экспериментальных образцов продукции</p>\r\n<p>&mdash; полное составление всей технической документации по изготовлению трикотажного изделия массового производства.</p>\r\n<p style="text-align: center;"><span style="color: #00a3cc;"><strong>Стоимость изготовления пробных образцов печати</strong></span></p>\r\n<table style="width: 700px; height: 50px; border-width: 1px; border-color: #d0d1d1; border-style: solid;" border="1" cellspacing="0" cellpadding="0" align="center"><colgroup> </colgroup>\r\n<tbody>\r\n<tr valign="TOP">\r\n<td width="56">\r\n<p class="western" align="LEFT"><span style="font-size: medium;"><strong>Тираж</strong></span></p>\r\n</td>\r\n<td width="34">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>1 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>2 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>3 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>4 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>5 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>6 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>7 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>8 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>9 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>10 цв.</strong></span></p>\r\n</td>\r\n<td width="45">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>11 цв.</strong></span></p>\r\n</td>\r\n</tr>\r\n<tr valign="TOP">\r\n<td width="56">\r\n<p class="western" align="LEFT"><span style="font-size: medium;"><strong>1-10 шт.</strong></span></p>\r\n</td>\r\n<td width="34">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">800</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">1000</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">1200</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">1800</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">2250</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">2650</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">2900</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">3100</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">3300</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">3450</span></p>\r\n</td>\r\n<td width="45">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">3600</span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p><span style="color: #00a3cc;"><strong>Стоимость пошива пробных образцов</strong></span></p>\r\n<p>1.отшив до трех образцов продукции с учетом наличия лекал &mdash; 1000 руб. (цена приведена за майку, поло и любое простое изделие)</p>\r\n<p>2.разработка и построение новых лекал &mdash; от 1000 рублей</p>\r\n<p>3.разработка новой модели, ее пошив и составление технической документации для дальнейшего массового производства &mdash; от 3000 руб.</p>\r\n<p><br /> Мы знаем, что очень важно видеть готовое изделие до его запуска в массовое производство, оценить, как смотрится принт на изделии, его расположение, размер и т. д. Именно поэтому мы разработали услугу по изготовлению пробного образца продукции независимо от технологии печати и сложности оригинал макета, конструирования модели, ее выкройки и пошива.</p>');
INSERT INTO `k2_block1` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `TEXT`) VALUES
(20, '2013-03-14 07:44:33', '2013-03-14 07:52:26', 1, 1, 1, 10, 74, 0, '<table style="width: 100%; border: 1px solid #bcbcbc;" border="1" cellspacing="0" cellpadding="5"><colgroup><col width="93" /><col width="57" /><col width="55" /><col width="54" /><col width="56" /><col width="56" /><col width="56" /><col width="55" /><col width="54" /><col width="56" /><col width="57" /><col width="54" /><col width="61" /></colgroup>\r\n<tbody>\r\n<tr>\r\n<td align="LEFT" width="93" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td colspan="8" align="CENTER" width="442"><strong>Профили</strong></td>\r\n<td align="CENTER" width="56"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" width="57"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" width="54"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" width="61"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong>Размер рамы</strong></td>\r\n<td align="LEFT">25х25*2</td>\r\n<td align="LEFT">30х30*2</td>\r\n<td align="LEFT">40х20*2</td>\r\n<td align="LEFT">40х30*2</td>\r\n<td align="LEFT">40х40*2</td>\r\n<td align="LEFT">40х40*3</td>\r\n<td align="LEFT">30х50*2</td>\r\n<td align="LEFT">40х60*2</td>\r\n<td align="LEFT">40х60*3</td>\r\n<td align="LEFT">40x80x2</td>\r\n<td align="LEFT">40x80x3</td>\r\n<td align="LEFT">40x100x4</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>20х30</strong></td>\r\n<td align="RIGHT">826</td>\r\n<td align="RIGHT">880</td>\r\n<td align="RIGHT">880</td>\r\n<td align="RIGHT">935</td>\r\n<td align="RIGHT">1043</td>\r\n<td align="RIGHT">1458</td>\r\n<td align="RIGHT">1043</td>\r\n<td align="RIGHT">1197</td>\r\n<td align="RIGHT">1676</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>25X40</strong></td>\r\n<td align="RIGHT" valign="MIDDLE">940</td>\r\n<td align="RIGHT" valign="MIDDLE">963</td>\r\n<td align="RIGHT" valign="MIDDLE">963</td>\r\n<td align="RIGHT" valign="MIDDLE">1090</td>\r\n<td align="RIGHT" valign="MIDDLE">1110</td>\r\n<td align="RIGHT" valign="MIDDLE">1552</td>\r\n<td align="RIGHT" valign="MIDDLE">1110</td>\r\n<td align="RIGHT" valign="MIDDLE">1270</td>\r\n<td align="RIGHT" valign="MIDDLE">1778</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>30х40</strong></td>\r\n<td align="RIGHT">1042</td>\r\n<td align="RIGHT">1062</td>\r\n<td align="RIGHT">1062</td>\r\n<td align="RIGHT">1153</td>\r\n<td align="RIGHT">1171</td>\r\n<td align="RIGHT">1638</td>\r\n<td align="RIGHT">1171</td>\r\n<td align="RIGHT">1368</td>\r\n<td align="RIGHT">1915</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>40х50</strong></td>\r\n<td align="RIGHT">1060</td>\r\n<td align="RIGHT">1124</td>\r\n<td align="RIGHT">1124</td>\r\n<td align="RIGHT">1278</td>\r\n<td align="RIGHT">1386</td>\r\n<td align="RIGHT">1938</td>\r\n<td align="RIGHT">1386</td>\r\n<td align="RIGHT">1548</td>\r\n<td align="RIGHT">2167</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>43X53</strong></td>\r\n<td align="RIGHT">1120</td>\r\n<td align="RIGHT">1210</td>\r\n<td align="RIGHT">1210</td>\r\n<td align="RIGHT">1350</td>\r\n<td align="RIGHT">1440</td>\r\n<td align="RIGHT">2014</td>\r\n<td align="RIGHT">1440</td>\r\n<td align="RIGHT">1620</td>\r\n<td align="RIGHT">2268</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong>43х80</strong></td>\r\n<td align="RIGHT">1300</td>\r\n<td align="RIGHT">1350</td>\r\n<td align="RIGHT">1350</td>\r\n<td align="RIGHT">1530</td>\r\n<td align="RIGHT">1590</td>\r\n<td align="RIGHT">2223</td>\r\n<td align="RIGHT">1610</td>\r\n<td align="RIGHT">1750</td>\r\n<td align="RIGHT">2450</td>\r\n<td align="LEFT">&nbsp;</td>\r\n<td align="LEFT">&nbsp;</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>50х60</strong></td>\r\n<td align="RIGHT">1191</td>\r\n<td align="RIGHT">1288</td>\r\n<td align="RIGHT">1288</td>\r\n<td align="RIGHT">1431</td>\r\n<td align="RIGHT">1530</td>\r\n<td align="RIGHT">2140</td>\r\n<td align="RIGHT">1530</td>\r\n<td align="RIGHT">1692</td>\r\n<td align="RIGHT">2369</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>53X73</strong></td>\r\n<td align="RIGHT">1330</td>\r\n<td align="RIGHT">1370</td>\r\n<td align="RIGHT">1370</td>\r\n<td align="RIGHT">1560</td>\r\n<td align="RIGHT">1620</td>\r\n<td align="RIGHT">2265</td>\r\n<td align="RIGHT">1620</td>\r\n<td align="RIGHT">1800</td>\r\n<td align="RIGHT">2520</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong>50х89</strong></td>\r\n<td align="RIGHT">1400</td>\r\n<td align="RIGHT">1490</td>\r\n<td align="RIGHT">1490</td>\r\n<td align="RIGHT">1746</td>\r\n<td align="RIGHT">1790</td>\r\n<td align="RIGHT">2503</td>\r\n<td align="RIGHT">1790</td>\r\n<td align="RIGHT">1970</td>\r\n<td align="RIGHT">2758</td>\r\n<td align="LEFT">&nbsp;</td>\r\n<td align="LEFT">&nbsp;</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong>56х66</strong></td>\r\n<td align="RIGHT">1305</td>\r\n<td align="RIGHT">1355</td>\r\n<td align="RIGHT">1355</td>\r\n<td align="RIGHT">1535</td>\r\n<td align="RIGHT">1595</td>\r\n<td align="RIGHT">2230</td>\r\n<td align="RIGHT">1595</td>\r\n<td align="RIGHT">1760</td>\r\n<td align="RIGHT">2464</td>\r\n<td align="LEFT">&nbsp;</td>\r\n<td align="LEFT">&nbsp;</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>60х70</strong></td>\r\n<td align="RIGHT">1341</td>\r\n<td align="RIGHT">1404</td>\r\n<td align="RIGHT">1404</td>\r\n<td align="RIGHT">1602</td>\r\n<td align="RIGHT">1692</td>\r\n<td align="RIGHT">2366</td>\r\n<td align="RIGHT">1692</td>\r\n<td align="RIGHT">1854</td>\r\n<td align="RIGHT">2596</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>60х80</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">1499</td>\r\n<td align="RIGHT">1499</td>\r\n<td align="RIGHT">1746</td>\r\n<td align="RIGHT">1791</td>\r\n<td align="RIGHT">2504</td>\r\n<td align="RIGHT">1791</td>\r\n<td align="RIGHT">1971</td>\r\n<td align="RIGHT">2759</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>70х80</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">1647</td>\r\n<td align="RIGHT">1647</td>\r\n<td align="RIGHT">1962</td>\r\n<td align="RIGHT">2009</td>\r\n<td align="RIGHT">2809</td>\r\n<td align="RIGHT">2009</td>\r\n<td align="RIGHT">2178</td>\r\n<td align="RIGHT">3049</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>80х90</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">1715</td>\r\n<td align="RIGHT">1715</td>\r\n<td align="RIGHT">2178</td>\r\n<td align="RIGHT">2205</td>\r\n<td align="RIGHT">3083</td>\r\n<td align="RIGHT">2205</td>\r\n<td align="RIGHT">2367</td>\r\n<td align="RIGHT">3314</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>73X93</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">1690</td>\r\n<td align="RIGHT">1690</td>\r\n<td align="RIGHT">2100</td>\r\n<td align="RIGHT">2120</td>\r\n<td align="RIGHT">2964</td>\r\n<td align="RIGHT">2120</td>\r\n<td align="RIGHT">2300</td>\r\n<td align="RIGHT">3220</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>70х100</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">1715</td>\r\n<td align="RIGHT">2178</td>\r\n<td align="RIGHT">2205</td>\r\n<td align="RIGHT">3083</td>\r\n<td align="RIGHT">2205</td>\r\n<td align="RIGHT">2367</td>\r\n<td align="RIGHT">3314</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>81X97</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">1850</td>\r\n<td align="RIGHT">2230</td>\r\n<td align="RIGHT">2300</td>\r\n<td align="RIGHT">3216</td>\r\n<td align="RIGHT">2300</td>\r\n<td align="RIGHT">2420</td>\r\n<td align="RIGHT">3388</td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>90х100</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">2000</td>\r\n<td align="RIGHT">2300</td>\r\n<td align="RIGHT">2360</td>\r\n<td align="RIGHT">3300</td>\r\n<td align="RIGHT">2360</td>\r\n<td align="RIGHT">2565</td>\r\n<td align="RIGHT">3591</td>\r\n<td align="RIGHT">2840</td>\r\n<td align="RIGHT">3120</td>\r\n<td align="RIGHT">5066</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>100х100</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">2421</td>\r\n<td align="RIGHT">2484</td>\r\n<td align="RIGHT">3473</td>\r\n<td align="RIGHT">2484</td>\r\n<td align="RIGHT">2664</td>\r\n<td align="RIGHT">3730</td>\r\n<td align="RIGHT"><span style="color: #000000;">2935</span></td>\r\n<td align="RIGHT"><span style="color: #000000;">3210</span></td>\r\n<td align="RIGHT"><span style="color: #000000;">5333</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>93X118</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">2470</td>\r\n<td align="RIGHT">2520</td>\r\n<td align="RIGHT">3524</td>\r\n<td align="RIGHT">2520</td>\r\n<td align="RIGHT">2710</td>\r\n<td align="RIGHT">3794</td>\r\n<td align="RIGHT">2990</td>\r\n<td align="RIGHT">3300</td>\r\n<td align="RIGHT">5627</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>105х125</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">2590</td>\r\n<td align="RIGHT">2620</td>\r\n<td align="RIGHT">3664</td>\r\n<td align="RIGHT">2670</td>\r\n<td align="RIGHT">2790</td>\r\n<td align="RIGHT">3906</td>\r\n<td align="RIGHT">3070</td>\r\n<td align="RIGHT">3480</td>\r\n<td align="RIGHT">6133</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>100х130</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">2590</td>\r\n<td align="RIGHT">2620</td>\r\n<td align="RIGHT">3664</td>\r\n<td align="RIGHT">2670</td>\r\n<td align="RIGHT">2790</td>\r\n<td align="RIGHT">3906</td>\r\n<td align="RIGHT">3070</td>\r\n<td align="RIGHT">3480</td>\r\n<td align="RIGHT">6133</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>114X128</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">2660</td>\r\n<td align="RIGHT">2780</td>\r\n<td align="RIGHT">3887</td>\r\n<td align="RIGHT">2853</td>\r\n<td align="RIGHT">2920</td>\r\n<td align="RIGHT">4088</td>\r\n<td align="RIGHT">3220</td>\r\n<td align="RIGHT">3560</td>\r\n<td align="RIGHT">6453</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>130х160</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="RIGHT">2754</td>\r\n<td align="RIGHT">3331</td>\r\n<td align="RIGHT">4658</td>\r\n<td align="RIGHT">2925</td>\r\n<td align="RIGHT">3500</td>\r\n<td align="RIGHT">4900</td>\r\n<td align="RIGHT">3410</td>\r\n<td align="RIGHT">3780</td>\r\n<td align="RIGHT">7733</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>150X210</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="RIGHT">9600</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>160x190</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="RIGHT">9333</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>160X220</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="RIGHT">10133</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" valign="MIDDLE" height="17"><strong>160X240</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="RIGHT">10666</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong>160X260</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="RIGHT">11199</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong>168X279</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="RIGHT">11919</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong>175X260</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="RIGHT">11599</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong>200X350</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="RIGHT">14665</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong><br /></strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#c3eefd">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><strong>225X425</strong></td>\r\n<td align="LEFT" bgcolor="#ffffff">&nbsp;</td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000;"><br /></span></td>\r\n<td align="RIGHT">17331</td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="17"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>от 10шт. скидка 10% от 20шт. скидка 15% от 50шт. скидка 20%</p>');
INSERT INTO `k2_block1` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `TEXT`) VALUES
(15, '2012-11-27 13:24:46', '2014-11-26 15:33:29', 1, 1, 1, 10, 63, 0, '<p>344064, г. Ростов-на-Дону, ул. Вавилова 53<br />+ 7 (863) 204 32 54, 204 32 55, 204 32 56, 204 32 57, 204 32 58, 204 32 59<br />e-mail:&nbsp;<a href="mailto:zakaz@printtextil.com" target="_blank">zakaz@printtextil.com</a>&nbsp;<br /><a href="http://www.printtextil.com" target="_blank">www.printtextil.com</a></p>\r\n<p><strong>Группа компаний &laquo;Победа&raquo;</strong>&nbsp;<br /><a href="http://www.pobedarf.com/" target="_blank">www.pobedarf.com<br /></a>Группа компаний &laquo;ПОБЕДА&raquo; начала свою деятельность в начале 2011 года. Сейчас - это молодое быстроразвивающееся объединение, которое включает собственную производственную базу полиграфических услуг, трафаретной печати на текстиле, производства сувенирной продукции и дизайн-бюро.Помимо производственных услуг, наша компания активно работает в сфере организации рекламных кампаний и специальных мероприятий.<br />Цель нашей компании - оказать комплекс профессиональных качественных производственных и маркетинговых услуг, соответствующих имиджу и статусу нашего партнера, отвечающих его потребностям и влияющих на повышение лояльности его аудитории.</p>\r\n<p><strong>Интернет-магазины<br /></strong>Тетради и Ручки&nbsp;<a href="http://tetradirychki.com/" target="_blank">tetradirychki.com</a>&nbsp;<br />БлокНОТ<a href="http://pappernoteshop.com/" target="_blank">pappernoteshop.com<br /></a>С 2013 года компания &laquo;ПОБЕДА&raquo; запустила свою линейку канцелярских товаров. В ассортимент входят как позиции изделий для записей (блокноты, тетради) экономклассатак и линейка современных ярких и креативных решений для офиса. В новой линейке представлены изделия для записей с обложками из дизайнерских материалов, а также искусственной и натуральной кожи. Так же в наших интернет-магазинах Вы найдете широкий ассортимент канцелярских товаров других известных производителей по очень выгодным ценам.</p>'),
(24, '2014-10-21 13:33:04', '2014-11-26 15:31:20', 1, 1, 1, 10, 82, 0, '<p><strong>ТРАФАРЕТНАЯ ПЕЧАТЬ НА ТЕКСТИЛЕ</strong><br />Изображение наносится методом шелкотрафаретной печати на футболки, толстовки, рубашки-поло, спецодежду, крой различных материалов от нейлона до кожи &ndash; с применением разнообразных красок: пластизоль, водные, металлизированные, флуоресцентные, перламутровые, светоотражающие, &laquo;пуфф&raquo;, &laquo;флок&raquo;.</p>\r\n<p><strong>ИЗГОТОВЛЕНИЕ ТЕРМОТРАНСФЕРА</strong><br />Изображение сначала наносится на бумагу трафаретным способом, а потом при помощи термотрансферного пресса переносится на изделие. В основном используется. Если печать по изделию трафаретным способом невозможна или затруднена, а также при маленьких тиражах.</p>\r\n<p><strong>НОВАЯ УСЛУГА!!! СОВМЕЩЕНИЕ ТРАФАРЕТНОЙ ПЕЧАТИ И ВЫШИВКИ</strong><br />Предлагаем Вам изготовление продукции со сложными изображениями, совмещающими шелкотрафаретную печать и вышивку.<br />Далее идет картинка, в виде табличке, я ее прикреплю к письму, название у нее будет 1.</p>\r\n<p>&nbsp;</p>\r\n<p>Стоимость изготовления форм на один цвет - 300 руб.<br />Стоимость печати на бейсболке +1,5 руб. Максимальный размер 7х12 см.<br />В таблице приведен расчет для печати размером 220Х290 мм пластизоливыми и водными красками. Максимально возможный формат изображения - 600х800мм.<br />Иные размеры и печать вытравными красками, лаком и глиттерами рассчитывается индивидуально нашими менеджерами.</p>\r\n<p><img src="/files/ophen/unnamed.jpg" border="0" width="781" height="391" /></p>'),
(16, '2012-11-27 17:29:22', '2014-11-26 19:01:45', 1, 1, 1, 10, 66, 0, '<p>Стоимость изготовления форм за один цвет &mdash; 300 руб.</p>\r\n<p>Нанесение на бейсболки + 1,2 руб., максимальный размер &mdash; 7x12 см.</p>\r\n<p>Цена рассчитана для печати пластизольными и водными красками. Для расчета печати вытравными красками, лаком или глиттером, обращайтесь за просчетом к нашим менеджерам. В прайсе указана стоимость печати изображения размером до 220 на 290 мм.</p>\r\n<p>Иные размеры изображения рассчитывается индивидуально. После предоставления макета и технического задания, наши специалисты смогут просмотреть макет и дать комментарии по его пригодности и качеству для дальнейшей работы. В 90% качество получаемого изделия, его яркость и насыщенность, тонкость слоя печати, а так же четкость изображения зависит от грамотности подготовки файла и его цветоделения.</p>\r\n<p>Мы рады предложить услуги по подготовке файлов к печати, цветоделению, разработке макетов и технологии печати.</p>\r\n<p style="text-align: left;"><span style="color: #00a3cc;"><strong><br /></strong></span></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>СТОИМОСТЬ ПЕЧАТИ НА РАЗМЕР ИЗОБРАЖЕНИЯ 410x510 мм</strong></span></p>\r\n<table style="border: currentColor; border-image: none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 133pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="177">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Тираж</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 99.2pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1 шт.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 99.25pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">2-5 шт.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 99.2pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">5-10 шт.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 92.15pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="123">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">От 11 шт.</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 133pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="177">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на белом</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">800 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.25pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">450 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">410 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 92.15pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="123">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">360 руб.</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.3pt; mso-yfti-irow: 2; mso-yfti-lastrow: yes;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 133pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="177">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на темном</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">900 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.25pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">550 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">480 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 92.15pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="123">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">420 руб.</span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>СТОИМОСТЬ ПЕЧАТИ НА РАЗМЕР ИЗОБРАЖЕНИЯ 200x300мм</strong></span></p>\r\n<table style="border: currentColor; border-image: none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 133pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="177">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Тираж</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 99.2pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1 шт.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 99.25pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">2-5 шт.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 99.2pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">5-10 шт.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 92.15pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="123">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">От 11 шт.</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 133pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="177">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на белом</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">500 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.25pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">300 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">280 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 92.15pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="123">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">250 руб.</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.3pt; mso-yfti-irow: 2; mso-yfti-lastrow: yes;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 133pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="177">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на темном</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">600 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.25pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">400 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">350 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 92.15pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="123">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">310 руб.</span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p><span style="color: #333333;"><strong>СТОИМОСТЬ ПЕЧАТИ НА РАЗМЕР ИЗОБРАЖЕНИЯ&nbsp;150х210мм</strong></span></p>\r\n<table style="border: currentColor; border-image: none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 133pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="177">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Тираж</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 99.2pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1 шт.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 99.25pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">2-5 шт.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 99.2pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">5-10 шт.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 92.15pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="123">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">От 11 шт.</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 133pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="177">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на белом</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">400 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.25pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">250 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">220 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 92.15pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="123">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">200 руб.</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.3pt; mso-yfti-irow: 2; mso-yfti-lastrow: yes;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 133pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="177">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на темном</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">500 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.25pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">350 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 99.2pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="132">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">300 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 92.15pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="123">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">280 руб.</span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>'),
(17, '2012-11-28 08:46:41', '2014-11-08 09:27:30', 1, 1, 1, 10, 67, 0, '<p>На сегодняшний день компания &laquo;ПОБЕДА&raquo;, обладает огромными возможностями по печатному производству, является одним из наиболее сильных игроков на рынке услуг по печати на текстиле на Юге России.</p>\r\n<p>Накопив уникальный опыт в сфере печати на натуральных и искусственных тканях, отточив искусство цветоделения, освоив технологии печати различными видами красок и использования эффектов, сейчас мы готовы предложить самые тщательно проработанные и уникальные технологии своим заказчикам.</p>\r\n<p>Осенью 2014 года мы преобразовали текстильное направление с целью создать удобный сервис для работы с заказчиками в секторе В2В.</p>\r\n<p>Сейчас мы готовы предложить следующие виды услуг:</p>\r\n<ul>\r\n<li>цветоделение и колорирование;</li>\r\n<li>разработка коллекций принтов, включающих всю необходимую предпечатную подготовку.</li>\r\n<li>продажа трикотажной и текстильной продукции;</li>\r\n<li>все виды печати и вышивки на готовой продукции и на крое;</li>\r\n<li>разработка экспериментальных образцов под требования заказчика (пошив/печать);</li>\r\n<li>разработка и изготовление индивидуальной упаковки для продукции заказчика.</li>\r\n</ul>');
INSERT INTO `k2_block1` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `TEXT`) VALUES
(18, '2012-12-02 06:10:01', '2014-11-26 19:43:28', 1, 1, 1, 10, 71, 0, '<p>Вышивальная машина на 6 голов по 12 нитей в каждой с возможностью пришивания пайеток, шнуров, выкладки вырезок на изделия, возможностью вышивки, как на крое, так и на готовых изделиях, так же на кепках, рукавах, воротниках и т.д.<br /> &laquo;YONTHIN&raquo; с площадью 360 на 480 мм.</p>\r\n<p style="text-align: left;">&nbsp;<a href="/files/ophen/atdq2-s.jpg" rel="lightbox[mhm]"><img src="/files/ophen/atdq2-s.jpg" border="0" width="173" height="173" /></a><a href="/files/ophen/cerm5.jpg" rel="lightbox[mhm]"><img src="/files/ophen/cerm5.jpg" border="0" width="173" height="173" /></a><a href="/files/ophen/l04m.jpg" rel="lightbox[mhm]"><img src="/files/ophen/l04m.jpg" border="0" width="173" height="130" style="width: 197px; height: 173px;" /></a><a href="/files/ophen/l05.jpg" rel="lightbox[mhm]"><img src="/files/ophen/l05.jpg" border="0" width="173" height="130" style="width: 201px; height: 173px;" /></a><a href="/files/ophen/gerbm3.jpg" rel="lightbox[mhm]"><span style="font-family: ''Lobster''; font-size: 18px; color: #c58b0e;"><img src="/files/ophen/gerbm3.jpg" border="0" width="173" height="130" style="width: 193px; height: 174px;" /></span></a></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>СОЗДАНИЕ ПРОГРАММЫ</strong></span></p>\r\n<p style="text-align: left;">Зависит от сложности от 500 до 5000 руб. Срок изготовления программы от 1 до 3 дней.</p>\r\n<p style="text-align: left;">&nbsp;</p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>ИЗГОТОВЛЕНИЕ ВЫШИВКИ НА КРОЕ И ТКАНЯХ (ЗА 1000 СТЕЖКОВ)</strong></span></p>\r\n<table style="border: currentColor; border-image: none; width: 697px; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 97.55pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="130">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Тираж</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1-10 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">11-30 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">31-100 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">101-500 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">свыше </span></strong></p>\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">500 ед.</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1; mso-yfti-lastrow: yes;">\r\n<td style="background: #fdfdfd; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 97.55pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt;" valign="top" width="130">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Цена</span></strong></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">договорная</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">15 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">8 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">7 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">5 руб.</span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p style="text-align: left;"><span style="color: #ff00ff;"><strong><br /></strong></span></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>ИЗГОТОВЛЕНИЕ ВЫШИВКИ НА ГОТОВЫХ ИЗДЕЛИЯХ (ЗА 1000 СТЕЖКОВ)</strong></span></p>\r\n<table style="border: currentColor; border-image: none; width: 584px; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 97.55pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="130">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Тираж</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1-10 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">11-30 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">31-100 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">свыше</span></strong></p>\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">101 ед.</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1; mso-yfti-lastrow: yes;">\r\n<td style="background: #fdfdfd; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 97.55pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt;" valign="top" width="130">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Цена</span></strong></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">договорная</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">16 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">9 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">7 руб.</span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p style="text-align: left;"><span style="color: #ff9900;"><strong><br /></strong></span></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>ШЕВРОНЫ (ЗА 1000 СТЕЖКОВ)</strong></span></p>\r\n<table style="border: currentColor; border-image: none; width: 584px; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 97.55pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="130">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Тираж</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1-10 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">11-30 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">31-100 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">свыше</span></strong></p>\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">101 ед.</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1; mso-yfti-lastrow: yes;">\r\n<td style="background: #fdfdfd; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 97.55pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt;" valign="top" width="130">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Цена</span></strong></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">договорная</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">17 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">9 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">6,2 руб.</span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p style="text-align: left;">&nbsp;</p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>ВЫШИВКА НА &nbsp;БЕЙСБОЛКАХ (ЗА 1000 СТЕЖКОВ)</strong></span></p>\r\n<table style="border: currentColor; border-image: none; width: 584px; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 97.55pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="130">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Тираж</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1-10 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">11-30 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">31-100 ед.</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 3cm; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">свыше</span></strong></p>\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">101 ед.</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1; mso-yfti-lastrow: yes;">\r\n<td style="background: #fdfdfd; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 97.55pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt;" valign="top" width="130">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Цена</span></strong></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">договорная</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">16 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">9 руб.</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 3cm; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="113">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">6,9 руб.</span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p style="text-align: left;">&nbsp;</p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>ДОПОЛНИТЕЛЬНЫЕ УСЛУГИ</strong></span></p>\r\n<p style="text-align: left;">- пришивание липучки (велкро) с обратной стороны шеврона - 60 руб;</p>\r\n<p style="text-align: left;">- обработка термо-клеевым слоем для приклейки утюгом - от 45 до 60 руб;</p>\r\n<p style="text-align: left;">- выезд курьера - от 500 руб;</p>\r\n<p style="text-align: left;">- вышивка металлизированной нитью (золото, серебро) на 30% дороже;</p>\r\n<p style="text-align: left;">- вышивка для единичных заказов рассчитывается индивидуально;</p>\r\n<p style="text-align: left;">- надбавка для единичных заказов рассчитывается индивидуально;</p>\r\n<p style="text-align: left;">- надбавка за срочное исполнение (один рабочий день) - 70%.</p>\r\n<hr />\r\n<p style="text-align: center;">Указанные цены являются усредненными. При обработке заказа учитывается сложность и объем работы.</p>\r\n<p style="text-align: center;"><strong> Для расчета стоимости свяжитесь с нами.</strong></p>'),
(19, '2013-03-11 11:38:45', '2013-03-11 11:46:11', 1, 1, 1, 10, 73, 0, '<p style="text-align: center;"><span style="color: #00a3cc;"><strong>Стоимость печати на размер изображения 410х510мм.</strong></span></p>\r\n<table style="width: 700px; height: 50px; border: 1px solid #d0d1d1;" border="1" cellspacing="0" cellpadding="5" align="center"><colgroup><col width="113" /> <col width="113" /> <col width="114" /> <col width="114" /> <col width="113" /> </colgroup>\r\n<tbody>\r\n<tr valign="TOP">\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>Тираж</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>1 шт.</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>2-5 шт.</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>5-10 шт.</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>От 11 шт.</strong></p>\r\n</td>\r\n</tr>\r\n<tr valign="TOP">\r\n<td width="113">\r\n<p>Печать на белом</p>\r\n</td>\r\n<td width="113">\r\n<p>800руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>450руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>410руб.</p>\r\n</td>\r\n<td width="113">\r\n<p>360руб.</p>\r\n</td>\r\n</tr>\r\n<tr valign="TOP">\r\n<td width="113">\r\n<p>Печать на темном</p>\r\n</td>\r\n<td width="113">\r\n<p>900руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>550руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>480руб.</p>\r\n</td>\r\n<td width="113">\r\n<p>420руб.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p style="text-align: center;"><span style="color: #00a3cc;"><strong>Стоимость печати на размер изображения 200х300мм.</strong></span></p>\r\n<table style="width: 700px; height: 50px; border: 1px solid #d0d1d1;" border="1" cellspacing="0" cellpadding="5" align="center"><colgroup><col width="113" /> <col width="113" /> <col width="114" /> <col width="114" /> <col width="113" /> </colgroup>\r\n<tbody>\r\n<tr valign="TOP">\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>Тираж</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>1 шт.</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>2-5 шт.</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>5-10 шт.</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>От 11 шт.</strong></p>\r\n</td>\r\n</tr>\r\n<tr valign="TOP">\r\n<td width="113">\r\n<p>Печать на белом</p>\r\n</td>\r\n<td width="113">\r\n<p>500руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>300руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>280руб.</p>\r\n</td>\r\n<td width="113">\r\n<p>250руб.</p>\r\n</td>\r\n</tr>\r\n<tr valign="TOP">\r\n<td width="113">\r\n<p>Печать на темном</p>\r\n</td>\r\n<td width="113">\r\n<p>600руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>400руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>350руб.</p>\r\n</td>\r\n<td width="113">\r\n<p>310руб.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p style="text-align: center;"><span style="color: #00a3cc;"><strong>Стоимость печати на размер изображения 150х210мм.</strong></span></p>\r\n<table style="width: 700px; height: 50px; border: 1px solid #d0d1d1;" border="1" cellspacing="0" cellpadding="5" align="center"><colgroup><col width="113" /> <col width="113" /> <col width="114" /> <col width="114" /> <col width="113" /> </colgroup>\r\n<tbody>\r\n<tr valign="TOP">\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>Тираж</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>1 шт.</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>2-5 шт.</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>5-10 шт.</strong></p>\r\n</td>\r\n<td style="background-color: #f9f9fa; width: 113px;">\r\n<p><strong>От 11 шт.</strong></p>\r\n</td>\r\n</tr>\r\n<tr valign="TOP">\r\n<td width="113">\r\n<p>Печать на белом</p>\r\n</td>\r\n<td width="113">\r\n<p>400руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>250руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>220руб.</p>\r\n</td>\r\n<td width="113">\r\n<p>200руб.</p>\r\n</td>\r\n</tr>\r\n<tr valign="TOP">\r\n<td width="113">\r\n<p>Печать на темном</p>\r\n</td>\r\n<td width="113">\r\n<p>500руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>350руб.</p>\r\n</td>\r\n<td width="114">\r\n<p>300руб.</p>\r\n</td>\r\n<td width="113">\r\n<p>280руб.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>');
INSERT INTO `k2_block1` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `TEXT`) VALUES
(21, '2013-03-14 08:00:15', '2013-03-14 08:01:18', 1, 1, 1, 10, 75, 0, '<p>Цены указаны в евро за погонный метр</p>\r\n<table style="border: 1px solid #bdbcbc; width: 100%;" border="1" cellspacing="0" cellpadding="5"><colgroup><col width="121" /><col width="65" /><col width="65" /><col width="65" /><col width="69" /></colgroup>\r\n<tbody>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000; font-family: Calibri;">Цена евро/пог.м</span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000; font-family: Calibri;"> Ширина, см</span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="CENTER" bgcolor="#ffffff" height="20"><span style="color: #000000; font-family: Calibri;">Описание</span></td>\r\n<td align="CENTER" bgcolor="#ffffff"><span style="color: #000000; font-family: Calibri;">Цвет</span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000; font-family: Calibri;">113-118,9</span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000; font-family: Calibri;">155-161,9</span></td>\r\n<td align="LEFT" bgcolor="#ffffff"><span style="color: #000000; font-family: Calibri;">184-189,9</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" bgcolor="#ffffff" height="20"><span style="color: #000000; font-family: Calibri;">PE AM</span></td>\r\n<td align="LEFT"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="LEFT"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">15.200 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">8,65</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">12,29</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">14,93</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">18.160 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">7,79</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">11,07</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">21.160 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">7,79</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">11,07</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">13,44</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">24.120 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">7,79</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">11,07</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">13,44</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">32.100 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">7,14</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">10,15</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">43. 80 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">7,49</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">10,7</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">12,54</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">55. 64 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">8,33</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">11,93</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">13,93</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">62. 64 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">9,62</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">13,7</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">15,9</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">71. 55 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">11,18</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">15,9</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">18,56</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">77. 55 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">11,51</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">16,51</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">19,15</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" bgcolor="#7ed1e3" height="20"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">Yellow</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">13,31</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">18,29</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">20,95</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">90. 40 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">12,93</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">18,49</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">21,63</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" bgcolor="#7ed1e3" height="20"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">Yellow</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">14,73</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">20,29</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">23,42</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">100.40 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">13,81</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">19,69</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">23,02</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" bgcolor="#7ed1e3" height="20"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">Yellow</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">15,61</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">21,49</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">24,81</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" height="20"><span style="color: #000000; font-family: Calibri;">120.34 PW</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">White</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">16,88</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">24,11</span></td>\r\n<td align="CENTER"><span style="color: #000000; font-family: Calibri;">28,39</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" bgcolor="#7ed1e3" height="20"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">Yellow</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">18,68</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">25,91</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">30,18</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" bgcolor="#7ed1e3" height="20"><span style="color: #000000; font-family: Calibri;">140.34 PW</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">Yellow</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">29,48</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">41,45</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">47,21</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" bgcolor="#7ed1e3" height="20"><span style="color: #000000; font-family: Calibri;">150.34 PW</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">Yellow</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">31,59</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">44,41</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">52,58</span></td>\r\n</tr>\r\n<tr>\r\n<td align="LEFT" bgcolor="#7ed1e3" height="20"><span style="color: #000000; font-family: Calibri;">165.31 PW</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">Yellow</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">34,22</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">48,25</span></td>\r\n<td align="CENTER" bgcolor="#7ed1e3"><span style="color: #000000; font-family: Calibri;">57,04</span></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>'),
(23, '2013-04-01 13:49:17', '2013-06-13 10:30:07', 1, 1, 1, 10, 77, 0, '<table style="width: 100%;" border="0" cellspacing="0" cellpadding="5"><colgroup><col width="182" /><col width="172" /><col width="84" /><col width="182" /><col width="119" /></colgroup>\r\n<tbody>\r\n<tr>\r\n<td style="border: 1px solid #d1d1d1; background-color: #1eb2e0;"><strong>Натяжка сетки</strong></td>\r\n<td style="border: 1px solid #d1d1d1; background-color: #1eb2e0;"><span style="color: #000000; font-family: Calibri;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td style="background-color: #ffffff; border: 1px solid #d1d1d1;"><strong>Формат рамы</strong></td>\r\n<td style="background-color: #ffffff; border: 1px solid #d1d1d1;"><strong><br /></strong></td>\r\n</tr>\r\n<tr>\r\n<td style="background-color: #ffffff; border: 1px solid #d1d1d1;"><strong>Сумма двух сторон, мм.</strong></td>\r\n<td style="background-color: #ffffff; border: 1px solid #d1d1d1;"><strong>Цена, руб.</strong></td>\r\n</tr>\r\n<tr>\r\n<td style="background-color: #ffffff; border: 1px solid #d1d1d1;"><strong>(по внешнему краю)</strong></td>\r\n<td style="background-color: #ffffff; border: 1px solid #d1d1d1;"><span style="color: #000000;"><br /></span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">0 -499</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">216</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">500-699</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">250</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">700-799</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">300</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">800-899</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">336</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">900-999</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">384</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">1000-1099</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">456</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">1100-1199</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">516</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">1200-1299</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">540</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">1300-1399</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">576</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">1400-1499</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">600</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">1500-1599</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">660</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">1600-1699</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">696</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">1700-1799</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">780</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">1800-1899</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">816</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">1900-2000</span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">864</span></td>\r\n</tr>\r\n<tr>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">Стоимость фотовывода&nbsp; 1м&sup2; </span></td>\r\n<td style="border: 1px solid #bcbcbc;"><span style="color: #000000;">800</span></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>'),
(25, '2014-10-21 13:40:44', '2014-11-27 12:12:04', 1, 1, 1, 20, 84, 0, '<div id="cc-m-7794713386" class="n j-text">Компания&nbsp;<strong>"ПОБЕДА"</strong>&nbsp;предлагает футболки и поло собственного производства со склада, в Ростове-на-Дону. Купить футболки, майки и бейсболки можно оптом. У нас Вы сможете подобрать дешевые бейсболки, поло и футболки производство Россия.&nbsp;</div>\r\n<div class="n j-text">&nbsp;\r\n<table style="width: 1199px; height: 1120px;" border="0">\r\n<tbody>\r\n<tr>\r\n<td style="text-align: justify;"><img src="/files/ophen/belaya.jpg" border="0" width="531" height="798" style="width: 187px; height: 266px;" /></td>\r\n<td>\r\n<p><strong>&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: #333333;">Футболка мужская, хлопок 100%, плотность 150 гр/м<sup>2</sup>.&nbsp;</span>&nbsp;</strong></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; Стоимость за единицу:</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 1-100 шт - 135 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 100-500 шт - 120 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 500&nbsp;- 1000 шт - 105 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; свыше 1000 шт - 95 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; свыше 10000 шт - индивидуально.</p>\r\n</td>\r\n<td>\r\n<p>&nbsp;</p>\r\n<p><span style="color: #333333;"><strong>&nbsp;&nbsp;&nbsp;&nbsp; Футболка женская, хлопок 100%, плотность 150 гр/м<sup>2</sup>.</strong></span></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; Стоимость за единицу:</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 1-100 шт - 135 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 100-500 шт - 120 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 500 - 1000 шт - 105 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; свыше 1000 шт - 95 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; свыше 10000 шт - индивидуально.</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style="text-align: justify;">&nbsp;<img src="/files/ophen/krasnaya(1).jpg" border="0" width="531" height="799" style="width: 178px; height: 255px;" /></td>\r\n<td>\r\n<p><span style="font-family: Arial;">&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: #333333;"><strong>Футболка мужская, хлопок 95% лайкра 5%, плотность 170 гр/м<sup>2</sup>.&nbsp;</strong></span></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; Стоимость за единицу:</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 1-100 шт - 180 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 100-500 шт - 155 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 500&nbsp;- 1000 шт - 125 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; свыше 1000 шт -&nbsp;110 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; свыше 10000 шт - индивидуально.<span style="font-family: Arial;"><br /></span></p>\r\n</td>\r\n<td>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: #333333;"><strong>Футболка женская, хлопок 95% лайкра 5%, плотность 170 гр/м<sup>2</sup>.</strong></span></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; Стоимость за единицу:</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 1-100 шт - 180 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 100-500 шт - 155 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; от 500&nbsp;- 1000 шт - 125 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; свыше 1000 шт -&nbsp;110 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; свыше 10000 шт - индивидуально.<span style="font-family: Arial;"><br /></span></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style="text-align: justify;"><img src="/files/ophen/sinyaya(1).jpg" border="0" width="531" height="799" style="width: 185px; height: 263px;" /></td>\r\n<td>\r\n<p><strong>&nbsp;&nbsp;&nbsp; Поло мужская/женская, пике, хлопок 100%, плотность 230 гр/м<sup>2</sup>, </strong></p>\r\n<p><strong>&nbsp;&nbsp;&nbsp; в</strong><strong>оротник вязаный.</strong></p>\r\n<p>&nbsp;&nbsp;&nbsp; Стоимость за единицу:</p>\r\n<p>&nbsp;&nbsp; &nbsp;от 1-100 шт - 270 руб;</p>\r\n<p>&nbsp;&nbsp;&nbsp; от 100-500 шт - 250 руб;</p>\r\n<p>&nbsp; &nbsp; от 500-1000 шт - 240 руб;</p>\r\n<p>&nbsp; &nbsp; свыше 1000 шт - 230 руб;</p>\r\n<p>&nbsp;&nbsp; &nbsp;свыше 10000 шт - индивидуально.</p>\r\n</td>\r\n<td>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style="text-align: justify;"><img src="/files/ophen/chernaya(3).jpg" border="0" width="531" height="798" style="width: 195px; height: 291px;" /></td>\r\n<td>\r\n<p><strong>&nbsp;&nbsp;&nbsp;&nbsp; <em>Наши преимущества:</em></strong></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; - собственное производство;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; - использование только высококачественного турецкого полотна;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; - возможность разработать и изготовить изделие по индивидуальным</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; требованиям заказчика с пошивом пробного образца.</p>\r\n</td>\r\n<td>&nbsp;</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n<div id="cc-m-7794713386" class="n j-text">\r\n<p>&nbsp;</p>\r\n</div>');
INSERT INTO `k2_block1` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `TEXT`) VALUES
(26, '2014-10-21 13:45:01', '2014-11-08 09:52:20', 1, 1, 1, 10, 85, 0, '<p style="text-align: left;"><img src="/files/ophen/1-03-kopiya.png" border="0" width="195" height="285" style="float: left;" /><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; БЛОКНОТЫ<br /></strong></p>\r\n<p><strong>Блокнот "ЭКО" А5, 60 л</strong></p>\r\n<p>Блокнот ЭКО, формата А5, 60 л, пружина черная, блок офсет клетка, обложка Т+Т лен+картон.</p>\r\n<p>Доступные цвета:</p>\r\n<p>- светло-коричневый;</p>\r\n<p>- лайм;</p>\r\n<p>- слоновая кость.</p>\r\n<p><strong><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></strong><strong></strong><strong><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></strong><strong></strong><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">36,70 руб</span></strong></span></p>\r\n<p><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><img src="/files/ophen/bloknot-01.png" border="0" width="196" height="236" style="float: left;" /></span></strong></span></p>\r\n<p><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;"><br /></span></span><strong>Блокнот карманный "ЭКО" на серебряной пружине А6, 48л</strong></p>\r\n<p>Блокнот карманный ЭКО, формата А6, 48 л, пружина серебно, блок офсет клетка, обложка с тиснением лен.</p>\r\n<p>Доступные цвета:</p>\r\n<p>- бордо;</p>\r\n<p>- лайм;</p>\r\n<p>- слоновая кость;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - темно-синий;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - черный.</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">14,80 руб</span></strong></span></p>\r\n<p><img src="/files/ophen/1-01.png" border="0" width="197" height="259" style="float: left;" /></p>\r\n<p><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></p>\r\n<p><strong><span style="color: #000000;">Блокнот "ЭКО БЛЭК" А5, 48 л</span></strong></p>\r\n<p><span style="color: #000000;">Блокнот ЭКО БЛЭК, формата А5, 48 л, пружина белая, блок бежевый офсет, обложка Т+Т с конгревом, цвет черный.</span></p>\r\n<p><span style="color: #000000;"><strong><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;">86,70 руб</span></span></strong></span></p>\r\n<p><span style="color: #000000;"><br /></span></p>\r\n<p><span style="color: #000000;"><br /></span></p>\r\n<p><span style="color: #000000;"><br /></span></p>\r\n<p><span style="color: #000000;"><br /></span></p>\r\n<p><span style="color: #000000;"><img src="/files/ophen/1-01.png" border="0" width="200" height="284" style="float: left;" /></span></p>\r\n<p><strong><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;"><br /></span></span></strong></p>\r\n<p><strong><span style="color: #ff0000;"><span style="color: #000000;">Блокнот "ЭКО БЛЭК" А5, 96 л</span></span></strong></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">Блокнот ЭКО БЛЭК, формата А5, 96 л, пружина белая, блок бежевый офсет, обложка Т+Т с конгревом, цвет черный.</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">120,30 руб</span></strong></span></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: center;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong>БИЗНЕС-ТЕТРАДИ</strong><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><img src="/files/ophen/1-03-kopiya.png" border="0" width="202" height="310" style="float: left;" /><strong>Тетрадь "ЭКО" А4, 96 л</strong></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">Тетрадь ЭКО, формата А4, 96 л, пружина черная, блок офсет клетка, &nbsp;обложка Т+Т лён+картон.</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">Доступные цвета:</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">- светло-коричневый;</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">- лайм;</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">- слоновая кость.</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">от 88,70 руб</span></strong></span></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><img src="/files/ophen/pobeda-18-01.png" border="0" width="203" height="203" style="float: left;" /></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong>Тетрадь "ЭКО" на скобе А4, 48 л</strong></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">Тетрадь на скобе формата А4 с тиснением "лен" на лицевой стороне обложке, блок - клетка 48 листов.</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">Доступные цвета:</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">- светло-коричневый;</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">- лайм;</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; - слоновая кость.</span></span></span></p>\r\n<p><strong><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></strong><strong></strong><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">от 78,80 руб</span></strong></span></p>\r\n<p><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></p>\r\n<p><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><img src="/files/ophen/pobeda-18.png1-01-kopiya.png" border="0" width="206" height="206" style="float: left;" /></span></strong></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong>Тетрадь "ЭКО" на скобе А5, 48 л</strong></span></span></span></p>\r\n<p>Тетрадь на скобе формата А5 с тиснением "лен" на лицевой стороне обложке, блок - клетка 48 листов.</p>\r\n<p>&nbsp;Доступные цвета:</p>\r\n<p>- светло-коричневый;</p>\r\n<p>- лайм;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - слоновая кость.</p>\r\n<p><strong><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></strong><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">от 43,90 руб</span></strong></span></p>\r\n<p><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></p>\r\n<p><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><img src="/files/ophen/podgotovkanasayt-05.png" border="0" width="207" height="213" style="float: left;" /></span></strong></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong>Тетрадь двойная "ЭКО" А4, 80 л</strong></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong>Тетрадь двойая "ЭКО", обложка с тиснением лен, формат А4 (в сложенном виде) 80 листов. Тетрадь на двух пружинах, с двумя блоками оп 40 листов (неленованный+клетка).</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">Доступные цвета:</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">- бордо/темно-синий;</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">- бордо/слоновая кость;</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; - темно-синий/слоновая кость;</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - черный/бордо;</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - черный/слоновая кость;</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - черный/темно-синий.</span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></strong><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">85 руб</span></strong></span></span></span></span></p>\r\n<p><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><img src="/files/ophen/podgotovkanasayt-01-kopiya.png" border="0" width="211" height="214" style="float: left;" /></span></strong></span><strong>Тетрадь двойная "ЭКО" А4, 80 л</strong></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong>Тетрадь двойная "ЭКО",обложка с тиснением лен, формат А4 (в сложенном виде) 80 листов. Тетрадь на двух пружинах, с двумя блоками по 40 листов (неленованный+клетка).</span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">Доступные цвета:</span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">- лайм/слоновая кость.<br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">96,90 руб</span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><img src="/files/ophen/2-02.png" border="0" width="212" height="301" style="float: left;" /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong><br /></strong></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong>Тетрадь"ЭКО БЛЭК" А5, 96 л</strong></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong>Тетрадь ЭКО БЛЭК, формата А5, 96 л, пружина белая, блок бежевый офсет, обложка Т+Т с конгревом, цвет черный.</span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">122,50 руб</span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /><strong></strong></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong><br /></strong></span></span></span></p>\r\n<p>&nbsp;</p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><img src="/files/ophen/2-02.png" border="0" width="210" height="292" style="float: left;" /><strong>Тетрадь "ЭКО БЛЭК" А4, 96 л</strong></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong>Тетрадь ЭКО БЛЭК, формата А4, 96 л, пружина белая, блок бежевый офсет, обложка Т+Т с конгревом, цвет черный.</span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">240,70 руб</span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><img src="/files/ophen/simplprint-02-kopiya.png" border="0" width="212" height="231" style="float: left;" /><strong></strong></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong>Тетрадь рабочая "SIMPLE PRINT" А4, 96 л</strong></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong>Тетрадь рабочая <span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">SIMPLE PRINT Абстракт, цвет голубой, формат А4, блок в клетку, 96 листов.</span></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">95,90 руб</span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><br /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><img src="/files/ophen/simplprint-04-kopiya.png" border="0" width="217" height="225" style="float: left;" /></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong>Тетрадь рабочая "SIMPLE PRINT" А4, 96 л</strong></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong>Тетрадь рабочая <span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">SIMPLE PRINT Абстракт, цвет желтый, формат А4, блок в клетку, 96 листов.</span></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">95,90 руб</span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><img src="/files/ophen/simplprint-03-kopiya.png" border="0" width="219" height="231" style="float: left;" /></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #000000;"><strong>Тетрадь рабочая "SIMPLE PRINT" А4, 96 л</strong></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong>Тетрадь рабочая <span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">SIMPLE PRINT Абстракт, цвет салатовый, формат А4, блок в клетку, 96 листов.</span></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">95,90 руб</span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><img src="/files/ophen/simplprint-05-kopiya.png" border="0" width="221" height="221" style="float: left;" /></span></strong></span><span style="color: #333333;"><strong>Тетрадь рабочая "SIMPLE PRINT" А4, 96 л, глянцевая</strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong></strong>Тетрадь рабочая&nbsp;<span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">SIMPLE PRINT</span></span></span></span></span></span> кожа коричневая с календарем на задней обложке, цвет коричневый, глянцевая ламинация, формат А4, блок в клетку, 96 листов.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;">90,80 руб</span></span></strong><br /></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #333333;">&nbsp;</span></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><br /></span></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><br /></span></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><br /></span></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><img src="/files/ophen/simplprint-05-kopiya.png" border="0" width="224" height="224" style="float: left;" /><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong>Тетрадь рабочая "SIMPLE PRINT" А4, 96 л, матовая</strong></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong></strong>Тетрадь рабочая&nbsp;<span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;">SIMPLE PRINT</span></span></span></span></span></span> кожа коричневая с календарем на задней обложке, цвет коричневый, матовая ламинация, формат А4, блок в клетку, 96 листов.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;">89,10 руб</span></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;"><br /></span></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;"><br /></span></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;"><br /></span></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;"><br /></span></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;"><img src="/files/ophen/1-06-kopiya.png" border="0" width="225" height="190" style="float: left;" /></span></span></strong></span><span style="color: #333333;"><strong>Тетрадь "VI</strong><strong>VELLA" А4, 96 л, бежевый офсет</strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong><span style="color: #333333;">Тетрадь Вивелла, формата А4, 96 л, пружина белая, блок бежевый офсет, обложка Т+Т, нить.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">Доступные цвета:</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">- рыже-коричневый;</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">- антрацит;</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - темно-красный.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;">от 214,50 руб</span></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong></strong><br /></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><img src="/files/ophen/1-05-kopiya.png" border="0" width="228" height="185" style="float: left;" /><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong>Тетрадь "VI</strong><strong>VELLA" А4, 96 л, белый офсет</strong></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong><span style="color: #333333;">Тетрадь Вивелла, формата А4, 96 л, пружина белая, блок белый офсет, обложка Т+Т, нить.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">Доступные цвета:</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">- рыже-коричневый;</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">- антрацит;</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - темно-красный.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></strong><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">от 170,40 руб</span></strong></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><img src="/files/ophen/1-08-kopiya.png" border="0" width="231" height="185" style="float: left;" /><span style="color: #333333;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong>Тетрадь "VI</strong><strong>VELLA" А5, 96 л, бежевый офсет</strong></span></span></span></span></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong><span style="color: #333333;">Тетрадь Вивелла, формата А5, 96 л, пружина белая, блок бежевый офсет, обложка Т+Т, нить.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">Доступные цвета:</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">- рыже-коричневый;</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">- антрацит;</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - темно-красный.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></strong><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;">от 131,30 руб</span></strong></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><span style="text-decoration: underline;"><strong><span style="color: #ff0000; text-decoration: underline;"><br /></span></strong></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><img src="/files/ophen/1-07-kopiya.png" border="0" width="235" height="191" style="float: left;" /><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><span style="color: #333333;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong>Тетрадь "VI</strong><strong>VELLA" А5, 96 л, белый офсет</strong></span></span></span></span></span></span></span></span></span></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><strong></strong><span style="color: #333333;">Тетрадь Вивелла, формата А5, 96 л, пружина белая, блок белый офсет, обложка Т+Т, нить.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">Доступные цвета:</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">- рыже-коричневый;</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">- антрацит;</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - темно-красный.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;">от 87,50 руб</span></span></strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><br /></span></span></span></span></p>\r\n<p style="text-align: center;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong>ПЛАНИНГИ</strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong></strong><img src="/files/ophen/pobeda-04.png" border="0" width="238" height="166" style="float: left;" /><strong>Планинг настольный</strong></span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;"><strong></strong>Планинг настольный недатированный (обложка - кожзам, иск. замша). Цвета: синий, коричневый, красный, черный. Внутренняя сторона обложки - бежевая иск. замша. Размер 420x300 мм в закрытом виде. Блок недатированный.</span></span></span></span></p>\r\n<p style="text-align: left;"><span style="color: #ff0000;"><span style="color: #000000;"><span style="color: #000000;"><span style="color: #333333;">Доступная персонализация*:</span></span></span></span></p>\r\n<p><em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; на обложке</em></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - тиснение;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - вышивка.</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp; <em>персонализация блока</em></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - первая страница;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - постраничная персонализаия.</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ________</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; *стоимость на персонализированные изделия рассчитываются индивидуально. Сроки поставки могут изменяться.</p>\r\n<p><strong><span style="color: #ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="text-decoration: underline;"><span style="color: #ff0000; text-decoration: underline;">890 руб</span></span></strong></p>');
INSERT INTO `k2_block1` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `TEXT`) VALUES
(28, '2014-11-07 10:51:54', '2014-11-26 18:58:27', 1, 1, 1, 10, 89, 0, '<p>Цифровая печать является неотъемлемым атрибутом современного рекламного производства. Она позволяет изготовить высококачественную &nbsp;печатную продукции в самые короткие сроки, в том числе малыми тиражами.&nbsp;</p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>ПРАЙС НА ЦИФРОВУЮ ПЕЧАТЬ, В ЛИСТАХ А3 И СТОИМОСТЬ БУМАГИ</strong></span></p>\r\n<table style="border: currentColor; border-image: none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 203.85pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Тираж</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 63.8pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">50</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 63.8pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">100</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 63.8pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">300</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 63.75pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">500</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 63.8pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1000</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">А3, 4+0</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">20</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">18</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">16</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">15</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">13</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.3pt; mso-yfti-irow: 2;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">А3, 4+4</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">38</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">35</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">30</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">28</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">22</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.65pt; mso-yfti-irow: 3;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Мел. бумага до 150 гр/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1,42</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.8pt; mso-yfti-irow: 4;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Мел. бумага 150-200 гр/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1,72</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.1pt; mso-yfti-irow: 5;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Мел. бумага 200-300 гр/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">2,15</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.2pt; mso-yfti-irow: 6;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 28.2pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Картон мелованный 270 гр/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.2pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.2pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.2pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">2,65</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 28.2pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.2pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.2pt; mso-yfti-irow: 7;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 27.2pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Лен</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.2pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.2pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.2pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">12,5</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 27.2pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.2pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 8; mso-yfti-lastrow: yes;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Дизайнерский картон</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 318.95pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" colspan="5" valign="top" width="425">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><em style="mso-bidi-font-style: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 11pt; mso-themecolor: text1; mso-themetint: 217;">прибавляется индивидуально к стоимости каждого тиража</span></em></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;<span style="color: #000000;"><strong><br /></strong></span></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>ПРАЙС НА УСЛУГИ РИЗОГРАФИИ</strong></span></p>\r\n<p style="text-align: left;"><span style="color: #333333;"><strong>ТОЛЬКО НЕ НА МЕЛОВАННОЙ БУМАГЕ ПЛОТНОСТЬЮ ДО 130 гр/м<sup>2</sup></strong></span></p>\r\n<table style="border: currentColor; border-image: none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 203.85pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Тираж</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 63.8pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">50</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 63.8pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">100</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 63.8pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">300</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 63.75pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">500</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 63.8pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1000</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Лист формата А3, 1+0</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">3</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">2,5</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1,5</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,8</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.3pt; mso-yfti-irow: 2;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Лист формата А3, 1+1</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">5,6</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">4,8</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">2,9</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1,8</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">1,4</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.65pt; mso-yfti-irow: 3;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Офсет 65 гр/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,55</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,52</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,49</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,47</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,45</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.8pt; mso-yfti-irow: 4;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Офсет 80 гр/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,7</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,67</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,6</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,58</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,55</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.1pt; mso-yfti-irow: 5;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 203.85pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="272">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Офсет 100 гр/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,9</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,85</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,8</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.75pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,73</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 63.8pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="85">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">0,69</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.2pt; mso-yfti-irow: 6; mso-yfti-lastrow: yes;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 522.8pt; height: 28.2pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" colspan="6" valign="top" width="697">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><em style="mso-bidi-font-style: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 11pt; mso-themecolor: text1; mso-themetint: 217;">к стоимости печати прибавляется стоимость бумаги</span></em></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>');
INSERT INTO `k2_block1` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `TEXT`) VALUES
(29, '2014-11-12 15:59:29', '2014-11-26 18:57:48', 1, 1, 1, 10, 81, 0, '<p><span style="color: #333333;"><strong>ИНТЕРЬЕРНАЯ ПЕЧАТЬ</strong></span></p>\r\n<table style="border: currentColor; border-image: none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 210.95pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">&nbsp;</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 148.85pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">720 </span></strong><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-ansi-language: EN-US; mso-themecolor: text1; mso-themetint: 217;" lang="EN-US">dpi</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 163pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="217">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-ansi-language: EN-US; mso-themecolor: text1; mso-themetint: 217;" lang="EN-US">1440 dpi</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 210.95pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на баннере 330м</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 148.85pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">250 руб/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 163pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="217">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">320 руб/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.3pt; mso-yfti-irow: 2;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 210.95pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на баннере 440м</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 148.85pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">400 руб/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 163pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="217">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">450 руб/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.65pt; mso-yfti-irow: 3;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 210.95pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на самоклеющейся пленке</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 148.85pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">250 руб/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 163pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="217">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">360 руб/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.8pt; mso-yfti-irow: 4;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 210.95pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на самоклеющейся пленке с<span style="mso-spacerun: yes;"><span style="color: #262626; font-size: medium;">&nbsp;</span></span>ламинацией</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 148.85pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">530 руб/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 163pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="217">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">620 руб/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.1pt; mso-yfti-irow: 5; mso-yfti-lastrow: yes;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 210.95pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Печать на сетке</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 148.85pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">250 руб/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 163pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="217">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">360 руб/м<sup><span style="color: #262626; font-size: small;">2</span></sup></span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<table style="border: currentColor; border-image: none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 28.9pt; mso-yfti-irow: 0; mso-yfti-firstrow: yes;">\r\n<td style="background: #fdfdfd; padding: 0cm 5.4pt; border: 1pt solid windowtext; border-image: none; width: 210.95pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Услуга</span></strong></p>\r\n</td>\r\n<td style="background: #fdfdfd; border-width: 1pt 1pt 1pt 0px; border-style: solid solid solid none; border-color: windowtext windowtext windowtext #000000; padding: 0cm 5.4pt; border-image: none; width: 148.85pt; height: 28.9pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><strong style="mso-bidi-font-weight: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Цена</span></strong></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.3pt; mso-yfti-irow: 1;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 210.95pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Порезка обычная</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 148.85pt; height: 28.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">7 руб/м.п.</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.3pt; mso-yfti-irow: 2;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 210.95pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Порезка фигурная</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 148.85pt; height: 27.3pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">15 руб/м.п.</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.65pt; mso-yfti-irow: 3;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 210.95pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Проклейка</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 148.85pt; height: 27.65pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">30 руб/м.п.</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 28.8pt; mso-yfti-irow: 4;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 210.95pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">Проклейка кармана</span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 148.85pt; height: 28.8pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">40 руб/м.п.</span></p>\r\n</td>\r\n</tr>\r\n<tr style="height: 27.1pt; mso-yfti-irow: 5; mso-yfti-lastrow: yes;">\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt; border-style: none solid solid; border-color: #000000 windowtext windowtext; padding: 0cm 5.4pt; border-image: none; width: 210.95pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="281">\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;"><span style="mso-spacerun: yes;"><span style="color: #262626; font-size: medium;">Установка люверса (1 шт.) - 10d</span></span></span></p>\r\n<p style="margin: 0cm 0cm 0pt; line-height: normal;"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;"><span style="mso-spacerun: yes;"><span style="color: #262626; font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;- 12d<br /></span></span></span></p>\r\n</td>\r\n<td style="background: #f2f2f2; border-width: 0px 1pt 1pt 0px; border-style: none solid solid none; border-color: #000000 windowtext windowtext #000000; padding: 0cm 5.4pt; width: 148.85pt; height: 27.1pt; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; mso-background-themecolor: background1; mso-background-themeshade: 242;" valign="top" width="198">\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">5 руб</span></p>\r\n<p style="margin: 0cm 0cm 0pt; text-align: center; line-height: normal;" align="center"><span style="color: #262626; font-family: ''Arial'',''sans-serif''; font-size: 12pt; mso-themecolor: text1; mso-themetint: 217;">5 руб</span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block1category`
--

DROP TABLE IF EXISTS `k2_block1category`;
CREATE TABLE IF NOT EXISTS `k2_block1category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `DIR` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block2`
--

DROP TABLE IF EXISTS `k2_block2`;
CREATE TABLE IF NOT EXISTS `k2_block2` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block2category`
--

DROP TABLE IF EXISTS `k2_block2category`;
CREATE TABLE IF NOT EXISTS `k2_block2category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block6`
--

DROP TABLE IF EXISTS `k2_block6`;
CREATE TABLE IF NOT EXISTS `k2_block6` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `PHOTO` varchar(255) NOT NULL,
  `LINK` varchar(255) NOT NULL,
  `CLASS` varchar(255) NOT NULL,
  `PHOTO_` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block6`
--

INSERT INTO `k2_block6` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `NAME`, `PHOTO`, `LINK`, `CLASS`, `PHOTO_`) VALUES
(9, '2012-11-27 09:33:22', '2012-11-30 05:02:25', 1, 1, 1, 10, 54, 0, 'Трафаретная печать по текстилю', '284', 'http://printtextil.ru/service/56/1/', 'textile', '285'),
(10, '2012-11-27 09:34:15', '2013-07-11 09:56:40', 1, 1, 1, 20, 54, 0, 'Продажа промотрикотажа и готовых изделий', '286', 'http://printtextil.ru/service/56/8/', 'print-products', '287'),
(11, '2012-11-27 09:34:39', '2014-11-05 08:49:52', 1, 1, 1, 3, 54, 0, 'Швейное производство и вышивка', '288', '/service/56/3/', 'print-tailor', '289'),
(12, '2012-11-27 09:35:05', '2014-11-05 08:50:24', 1, 1, 0, 40, 54, 0, 'Экспериментальный цех', '290', 'http://printtextil.ru/service/56/4/', 'purl', '291'),
(13, '2012-11-27 09:35:31', '2014-11-05 08:41:36', 1, 1, 1, 1, 54, 0, 'Цифровая печать', '659', 'http://printtextil.ru/service/56/7/', 'strass', '658'),
(14, '2012-11-27 09:36:00', '2014-11-05 08:50:29', 1, 1, 1, 4, 54, 0, 'Дизайн и разработка', '294', 'http://printtextil.ru/service/56/6/', 'design', '295'),
(15, '2014-11-05 08:44:38', '2014-11-05 08:48:58', 1, 1, 1, 2, 54, 0, 'Широкоформатная печать и УФ-печать', '864', '/service/56/11/', 'strass', '865');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block6category`
--

DROP TABLE IF EXISTS `k2_block6category`;
CREATE TABLE IF NOT EXISTS `k2_block6category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block6category`
--

INSERT INTO `k2_block6category` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `SECTION_BLOCK`, `PARENT`, `ACTIVE`, `SORT`, `NAME`) VALUES
(1, '2011-06-07 09:02:26', '0000-00-00 00:00:00', 1, 0, 25, 0, 1, 10, 'Игрушки'),
(2, '2011-06-07 09:02:38', '0000-00-00 00:00:00', 1, 0, 25, 0, 1, 20, 'Напильники'),
(3, '2011-06-07 09:02:45', '0000-00-00 00:00:00', 1, 0, 25, 0, 1, 30, 'Машинки'),
(4, '2011-06-07 09:02:55', '0000-00-00 00:00:00', 1, 0, 25, 0, 1, 40, 'Балалайки'),
(5, '2011-06-07 09:03:02', '0000-00-00 00:00:00', 1, 0, 25, 0, 1, 50, 'Штаны'),
(6, '2011-06-07 09:03:15', '0000-00-00 00:00:00', 1, 0, 25, 0, 1, 60, 'Консервы');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block7`
--

DROP TABLE IF EXISTS `k2_block7`;
CREATE TABLE IF NOT EXISTS `k2_block7` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `PHONE` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `CH1` char(1) NOT NULL,
  `CH2` char(1) NOT NULL,
  `CH3` char(1) NOT NULL,
  `CH4` char(1) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block7category`
--

DROP TABLE IF EXISTS `k2_block7category`;
CREATE TABLE IF NOT EXISTS `k2_block7category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block26`
--

DROP TABLE IF EXISTS `k2_block26`;
CREATE TABLE IF NOT EXISTS `k2_block26` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `TEXT` mediumtext NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block26`
--

INSERT INTO `k2_block26` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `TEXT`) VALUES
(1, '2012-11-27 09:50:03', '2014-10-22 10:41:13', 1, 1, 1, 10, 55, 0, '<h1>О компании</h1>\r\n<p>Компания ООО &laquo;Победа&raquo; рада предложить вам услуги по печати различных изображений по всем видам текстильной продукции:</p>\r\n<p>Наше производство оснащено профессиональным оборудованием для печати по текстилю, с возможностью наносить изображение до 12 цветов размером до 500 х 600 мм! Со скоростью 1400 печатных прокатов в час!</p>\r\n<p>Услуги по вышивке изображений на высокоскоростных вышивальных машинах "Yonthin", услуги по цветоделению файлов, подготовке оригинал-макетов к печати, печать на футболках, вывод пленок и натяжке сеток на трафаретные рам.</p>\r\n<p>Так же на нашем производстве мы осуществляем услуги по тиснению фольгой, работе с глиттерными лаками и вспенкой, работу с красками любого рода эффектов: кожей, замшей, с запахом фруктов или шоколада, водными и вытравными красками и многое другое.</p>\r\n<p>Компания &laquo;Победа&raquo; занимается индивидуальным пошивом промоизделий на заказ и по имеющимся лекалам. Также на складе компании всегда имеется широкий ассортимент футболок, рубашек поло, маек любых размеров и самых популярных оттенков.</p>');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block26category`
--

DROP TABLE IF EXISTS `k2_block26category`;
CREATE TABLE IF NOT EXISTS `k2_block26category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block27`
--

DROP TABLE IF EXISTS `k2_block27`;
CREATE TABLE IF NOT EXISTS `k2_block27` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `TEXT` mediumtext NOT NULL,
  `PHOTO` varchar(255) NOT NULL,
  `TEXT_FULL` mediumtext NOT NULL,
  `CLASS` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block27`
--

INSERT INTO `k2_block27` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `NAME`, `TEXT`, `PHOTO`, `TEXT_FULL`, `CLASS`) VALUES
(1, '2012-11-27 10:19:52', '2014-11-26 19:55:54', 1, 1, 1, 3, 56, 0, 'Печать по текстилю', 'Мы предлагаем услуги трафаретной печати по текстилю на готовых изделиях, печать на полотне: футболках, кепках, а также на крое и полотне. Мы осуществляем печать различными видами красок:\r\nпластизольные;\r\nводные;\r\nфлуоресцентные;\r\nпечать вытравной технологией.', '296', '<p><strong>Трафаретная печать по текстилю</strong></p>\r\n<table border="0" cellspacing="5" cellpadding="5">\r\n<tbody>\r\n<tr>\r\n<td valign="top">\r\n<p><a href="/files/ophen/P1000127.JPG" rel="lightbox[rks]"><img src="/files/ophen/P1000127.JPG" border="0" width="150" /></a>&nbsp;<br /><a href="/files/ophen/P1000129.JPG" rel="lightbox[rks]"><img src="/files/ophen/P1000129.JPG" border="0" width="150" /></a>&nbsp;<a href="/files/ophen/P1000132.JPG" rel="lightbox[rks]"><img src="/files/ophen/P1000132.JPG" border="0" width="150" /></a>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n</td>\r\n<td valign="top">\r\n<p>Текстильный струйный цифровой принтер M&amp;R I-Dot предназначен для прямой печати&nbsp;как на белых и светлых, так и на цветных (в том числе черных) текстильных изделиях .</p>\r\n<ul>\r\n<li>повышенная плотность белой подложки при печати на темных изделиях обеспечивается&nbsp;с помощью четырех картриджей с высококроющими белыми чернилами производства&nbsp;американской компании DuPont, а цветная печать осуществляется одноканальной&nbsp;четырех красочной системой CMYK.</li>\r\n<li>для обеспечения максимальной скорости, качества и удобства в работе при цифровой&nbsp;печати как коротких, так и персонализированных тиражей.</li>\r\n<li>разрешение печати до 1440х1440 dpi позволяет воспроизводить на одежде изображения&nbsp;великолепного фотографического качества с безукоризненно высокой проработкой&nbsp;мельчайших деталей.</li>\r\n<li>максимальный формат печати 41х51 см обеспечивает выполнение практически любых&nbsp;задач, связанных с печатью на разнообразных текстильных изделиях.</li>\r\n<li>снабжен системой лазерной приводки, позволяющей моментально центрировать любое&nbsp;изделие относительно печатного стола.</li>\r\n</ul>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p><strong>&nbsp;</strong></p>\r\n<p><strong><span>Цифровая печать по текстилю</span></strong></p>\r\n<table style="width: 100%;" border="0" cellspacing="5" cellpadding="5">\r\n<tbody>\r\n<tr>\r\n<td style="width: 170px;" valign="top">\r\n<p><a href="/files/ophen/KOS_8846.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8846.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8838.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8838.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8843.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8843.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8859.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8859.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8866.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8866.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8911.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8911.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8917.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8917.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8927.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8927.jpg" border="0" width="150" /></a></p>\r\n</td>\r\n<td valign="top">\r\n<p>Мы предлагаем услуги трафаретной печати по текстилю на готовых изделиях, печать на полотне: футболках, кепках, а также на крое и полотне, печать на постельном белье. Мы осуществляем печать различными видами красок:</p>\r\n<ul>\r\n<li>пластизольные;</li>\r\n<li>водные;</li>\r\n<li>флуоресцентные;</li>\r\n<li>печать вытравной технологией.</li>\r\n</ul>\r\n<p><br />И применяем разного рода эффекты при печати на ткани:</p>\r\n<ul>\r\n<li>глиттеры;</li>\r\n<li>каменные базы;</li>\r\n<li>вспенка;</li>\r\n<li>печать под замшу и т.д.</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p>Основные технологические особенности:</p>\r\n<ul>\r\n<li>формат печати до 600 на 800 мм!</li>\r\n<li>печать СМУК;</li>\r\n<li>печать пантонами до 11 цветов;</li>\r\n<li>выпуск до 7000 полноцветных изделий за рабочую смену;</li>\r\n<li>печать эффектов: камень, замша, кожа, фольга, золото, серебро и т.д.</li>\r\n<li>печать размерников и ярлыков (от 1-го экземпляра продукции).</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p>После предоставления макета и технического задания, наши специалисты смогут просмотреть макет и дать комментарии к его пригодности и качеству для дальнейшей работы.<br />В 90% качество получаемого изделия, его яркость и насыщенность, тонкость слоя печати, а так же четкость изображения зависит от грамотности подготовки файла и его цветоделения. Мы рады предложить услуги по подготовке файлов к печати, цветоделению, разработке макетов и технологии печати.</p>\r\n<p><br />На нашем сайте Вы можете ознакомиться с прайсом по печати трафаретом или воспользоваться калькулятором, однако делая самостоятельный расчет, обратите внимание, что:</p>\r\n<ul>\r\n<li>прайс предназначен для просчета печати пластизольными и водными красками,</li>\r\n<li>прочие виды красок и эффектов требуют индивидуального расчета менеджеров;</li>\r\n<li>cтоимость изготовления форм за один цвет составляет 300 руб.;</li>\r\n<li>нанесение на бейсболки + 1,5 руб., максимальный размер 7х12см.</li>\r\n</ul>\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>\r\n</tr>\r\n</tbody>\r\n</table>', 'textile'),
(3, '2012-11-27 10:23:53', '2014-11-14 17:11:46', 1, 1, 1, 4, 56, 0, 'Швейное производство и вышивка', 'Компания "ПОБЕДА" предлагает большой ассортимент трикотажной продукции для рекламного рынка. В настоящее время сформирован склад мужских, женских и даже детских футболок, а также рубашек-поло, силуэтных футболок, маек без рукавов, борцовок, толстовок и даже тельняшек. Мы можем изготовить партию любой трикотажной продукцию с учетом всех Ваших пожеланий: модель, ткань, цвет, фурнитура и т.д. так же осуществляется изготовление шевронов.', '302', '<table style="width: 100%;" border="0" cellspacing="5" cellpadding="5">\r\n<tbody>\r\n<tr>\r\n<td style="width: 200px;" valign="top"><img src="/files/ophen/sobachka.png" border="0" width="600" height="600" style="width: 229px; height: 210px;" /><img src="/files/ophen/lev.png" border="0" width="600" height="600" style="width: 197px; height: 177px;" /><img src="/files/ophen/emblema(1).png" border="0" width="600" height="600" style="width: 201px; height: 182px;" />&nbsp;&nbsp;&nbsp;</td>\r\n<td valign="top">\r\n<p style="text-align: left;">Компания "ПОБЕДА" предлагает большой ассортимент трикотажной продукции для рекламного рынка. В настоящее время сформирован склад мужских, женских и даже детских футболок, а также рубашек-поло, силуэтных футболок, маек без рукавов, борцовок, толстовок и даже тельняшек.</p>\r\n<p style="text-align: left;">Мы можем изготовить партию любой трикотажной продукцию с учетом всех Ваших пожеланий: модель, ткань, цвет, фурнитура и т.д. так же осуществляется изготовление шевронов.<br /> При индивидуальном пошиве подбирается полотно необходимой Вам плотности, а цвет согласовывается по пантону TCX или TPX. Минимальный заказ на 1 цвет одной модели - 1000 шт."</p>\r\n<p style="text-align: left;">&nbsp;</p>\r\n<p style="text-align: left;">Для разработки новых моделей изделий на нашем предприятии сформирован <strong>экспериментальный участок</strong>. В штате предприятия 3 профессиональных конструктора, лаборанты, технолог. Участок оснащен современным программным обеспечением, позволяющим конструировать изделия различной сложности, и делать градацию размерно-ростового ряда. Наши профессиональные дизайнеры разработают по индивидуальным требованиям интересные модели для новых коллекций заказчиков, предложат оригинальные дизайны декора, порекомендуют подходящее полотно.&nbsp; В нашем экспериментальном участке мы предлагаем:</p>\r\n<p style="text-align: left;">&mdash; разработку лекал по чертежам клиента</p>\r\n<p style="text-align: left;">&mdash; разработку моделей и их конструирование</p>\r\n<p style="text-align: left;">&mdash; разработку принтов и технических карт</p>\r\n<p style="text-align: left;">&mdash; отшив экспериментальных образцов продукции</p>\r\n<p style="text-align: left;">&mdash; полное составление всей технической документации по изготовлению трикотажного изделия массового производства.</p>\r\n<p style="text-align: left;"><strong>Стоимость изготовления пробных образцов печати</strong></p>\r\n<table style="float: left;" border="1" cellspacing="0" cellpadding="0" align="center"><colgroup></colgroup>\r\n<tbody>\r\n<tr valign="TOP">\r\n<td width="56">\r\n<p class="western" align="LEFT"><strong>Тираж</strong></p>\r\n</td>\r\n<td width="34">\r\n<p class="western" align="LEFT"><strong>1 цв.</strong></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT"><strong>2 цв.</strong></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT"><strong>3 цв.</strong></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT"><strong>4 цв.</strong></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT"><strong>5 цв.</strong></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT"><strong>6 цв.</strong></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT"><strong>7 цв.</strong></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT"><strong>8 цв.</strong></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT"><strong>9 цв.</strong></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT"><strong>10 цв.</strong></p>\r\n</td>\r\n<td width="45">\r\n<p class="western" align="LEFT"><strong>11 цв.</strong></p>\r\n</td>\r\n</tr>\r\n<tr valign="TOP">\r\n<td width="56">\r\n<p class="western" align="LEFT"><strong>1-10 шт.</strong></p>\r\n</td>\r\n<td width="34">\r\n<p class="western" align="LEFT">800</p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT">1000</p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT">1200</p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT">1800</p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT">2250</p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT">2650</p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT">2900</p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT">3100</p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT">3300</p>\r\n</td>\r\n<td width="46">\r\n<p class="western" align="LEFT">3450</p>\r\n</td>\r\n<td width="45">\r\n<p class="western" align="LEFT">3600</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style="width: 200px;">\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;&nbsp;</p>\r\n<p>&nbsp;&nbsp;&nbsp;</p>\r\n</td>\r\n<td valign="top">\r\n<p><strong>Стоимость пошива пробных образцов</strong></p>\r\n<p>1.отшив до трех образцов продукции с учетом наличия лекал &mdash; 1000 руб. (цена приведена за майку, поло и любое простое изделие)</p>\r\n<p>2.разработка и построение новых лекал &mdash; от 1000 рублей</p>\r\n<p>3.разработка новой модели, ее пошив и составление технической документации для дальнейшего массового производства &mdash; от 3000 руб.</p>\r\n<p><br />Мы знаем, что очень важно видеть готовое изделие до его запуска в массовое производство, оценить, как смотрится принт на изделии, его расположение, размер и т. д. Именно поэтому мы разработали услугу по изготовлению пробного образца продукции независимо от технологии печати и сложности оригинал макета, конструирования модели, ее выкройки и пошива.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', 'print-tailor'),
(4, '2012-11-27 10:24:29', '2014-10-22 06:54:45', 1, 1, 0, 40, 56, 0, 'Экспериментальный цех', 'Для разработки новых моделей изделий на нашем предприятии сформирован экспериментальный участок. В штате предприятия 3 профессиональных конструктора, лаборанты, технолог. Участок оснащен современным программным обеспечением, позволяющим конструировать изделия различной сложности, и делать градацию размерно-ростового ряда. Наши профессиональные дизайнеры разработают по индивидуальным требованиям интересные модели для новых коллекций заказчиков, предложат оригинальные дизайны декора, порекомендуют подходящий трикотаж. ', '299', '<table style="width: 100%;" border="0" cellspacing="5" cellpadding="5">\r\n<tbody>\r\n<tr>\r\n<td style="width: 170px;" valign="top"><a href="/files/ophen/KOS_8719.jpg" rel="lightbox[rks]"><img src="/files/ophen/KOS_8719.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8728.jpg" rel="lightbox[rks]"><img src="/files/ophen/KOS_8728.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8735.jpg" rel="lightbox[rks]"><img src="/files/ophen/KOS_8735.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8737.jpg" rel="lightbox[rks]"><img src="/files/ophen/KOS_8737.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8740.jpg" rel="lightbox[rks]"><img src="/files/ophen/KOS_8740.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8746.jpg" rel="lightbox[rks]"><img src="/files/ophen/KOS_8746.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8883.jpg" rel="lightbox[rks]"><img src="/files/ophen/KOS_8883.jpg" border="0" width="150" /></a> <a href="/files/ophen/KOS_8886.jpg" rel="lightbox[rks]"><img src="/files/ophen/KOS_8886.jpg" border="0" width="150" /></a></td>\r\n<td>\r\n<p>Для разработки новых моделей изделий на нашем предприятии сформирован экспериментальный участок. В штате предприятия 3 профессиональных конструктора, лаборанты, технолог. Участок оснащен современным программным обеспечением, позволяющим конструировать изделия различной сложности, и делать градацию размерно-ростового ряда. Наши профессиональные дизайнеры разработают по индивидуальным требованиям интересные модели для новых коллекций заказчиков, предложат оригинальные дизайны декора, порекомендуют подходящее полотно.&nbsp; В нашем экспериментальном участке мы предлагаем:</p>\r\n<p>&mdash; разработку лекал по чертежам клиента</p>\r\n<p>&mdash; разработку моделей и их конструирование</p>\r\n<p>&mdash; разработку принтов и технических карт</p>\r\n<p>&mdash; отшив экспериментальных образцов продукции</p>\r\n<p>&mdash; полное составление всей технической документации по изготовлению трикотажного изделия массового производства.</p>\r\n<p style="text-align: center;"><span style="color: #00a3cc;"><strong>Стоимость изготовления пробных образцов печати</strong></span></p>\r\n<table style="width: 700px; height: 50px; border-width: 1px; border-color: #d0d1d1; border-style: solid;" border="1" cellspacing="0" cellpadding="0" align="center"><colgroup> </colgroup>\r\n<tbody>\r\n<tr valign="TOP">\r\n<td width="56">\r\n<p class="western" align="LEFT"><span style="font-size: medium;"><strong>Тираж</strong></span></p>\r\n</td>\r\n<td width="34">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>1 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>2 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>3 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>4 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>5 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>6 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>7 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>8 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>9 цв.</strong></span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>10 цв.</strong></span></p>\r\n</td>\r\n<td width="45">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;"><strong>11 цв.</strong></span></p>\r\n</td>\r\n</tr>\r\n<tr valign="TOP">\r\n<td width="56">\r\n<p class="western" align="LEFT"><span style="font-size: medium;"><strong>1-10 шт.</strong></span></p>\r\n</td>\r\n<td width="34">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">800</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">1000</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">1200</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">1800</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">2250</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">2650</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">2900</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">3100</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">3300</span></p>\r\n</td>\r\n<td width="46">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">3450</span></p>\r\n</td>\r\n<td width="45">\r\n<p class="western" style="text-align: center;" align="LEFT"><span style="font-size: medium;">3600</span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p><span style="color: #00a3cc;"><strong>Стоимость пошива пробных образцов</strong></span></p>\r\n<p>1.отшив до трех образцов продукции с учетом наличия лекал &mdash; 1000 руб. (цена приведена за майку, поло и любое простое изделие)</p>\r\n<p>2.разработка и построение новых лекал &mdash; от 1000 рублей</p>\r\n<p>3.разработка новой модели, ее пошив и составление технической документации для дальнейшего массового производства &mdash; от 3000 руб.</p>\r\n<p><br /> Мы знаем, что очень важно видеть готовое изделие до его запуска в массовое производство, оценить, как смотрится принт на изделии, его расположение, размер и т. д. Именно поэтому мы разработали услугу по изготовлению пробного образца продукции независимо от технологии печати и сложности оригинал макета, конструирования модели, ее выкройки и пошива.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', 'purl'),
(6, '2012-11-27 10:25:17', '2014-10-22 06:53:16', 1, 1, 1, 6, 56, 0, 'Дизайн и разработка', 'В отделе дизайна и подготовки макетов к печати мы предлагаем услуги по:\r\n• цветоделению файлов, выводу пленок и составлению тех.карт;\r\n• разработке коллекций принтов, моделей, технических особенностей печати и т. д.\r\n• обрисовке макетов, предпечатная подготовка макетов;\r\n• печати пробного экземпляра продукции после проведения дизайнерских работ и предоставления образца клиенту на утверждение;\r\n• разработке вышивки в специальных программах по техническим требованиям заказчика, работа с эффектами (пайетки, стразы, шнур) и разными способами вышивки;\r\n• предоставление пробного образца вышивки вместе с макетом по требованию клиента;', '301', '<table style="width: 100%;" border="0" cellspacing="5" cellpadding="5">\r\n<tbody>\r\n<tr>\r\n<td style="width: 170px;" valign="top"><a href="/files/ophen/02.jpg" rel="lightbox[rks]"><img src="/files/ophen/02.jpg" border="0" width="150" /></a> <a href="/files/ophen/03.jpg" rel="lightbox[rks]"><img src="/files/ophen/03.jpg" border="0" width="150" /></a> <a href="/files/ophen/04.jpg" rel="lightbox[rks]"><img src="/files/ophen/04.jpg" border="0" width="150" /></a> <a href="/files/ophen/05.jpg" rel="lightbox[rks]"><img src="/files/ophen/05.jpg" border="0" width="150" /></a></td>\r\n<td>\r\n<p>В отделе дизайна и подготовки макетов к печати мы предлагаем услуги по:<br />&bull; цветоделению файлов, выводу пленок и составлению тех.карт;<br />&bull; разработке коллекций принтов, моделей, технических особенностей печати и т. д.<br />&bull; обрисовке макетов, предпечатная подготовка макетов;<br />&bull; печати пробного экземпляра продукции после проведения дизайнерских работ и предоставления образца клиенту на утверждение;<br />&bull; разработки вышивки в специальных программах по техническим требованиям заказчика, работа с эффектами (пайетки, стразы, шнур) и разными способами вышивки;<br />&bull; предоставлению пробного образца вышивки вместе с макетом по требованию клиента;</p>\r\n<p>В 90% качество получаемого изделия, его яркость и насыщенность, тонкость слоя печати, а так же четкость изображения зависит от грамотности подготовки файла и его цветоделения. Мы предлагаем услуги по цветоделению файлов, их подготовки к печати, а так же изготовлению пробного образца продукции в нескольких технологиях. <br />Услуги по цветоделению, разработке макетов и технологии печати.</p>\r\n<p>&bull; подготовка файла к печати (до 3 цветов) &mdash; 1500 руб.</p>\r\n<p>&bull; подготовка файла к печати (до 7 цветов) &mdash; 2500 руб.</p>\r\n<p>&bull; подготовка файла к печати (свыше 7 цветов) &mdash; 3500 руб.</p>\r\n<p>&bull; услуги по цветоделению &mdash; 800 руб. за один цвет (полная подготовка файлов для вывода пленок с указанием Pantone и формул их печати)</p>\r\n<p>Каждая работа по подготовке файлов к печати и их обработке занимает в среднем от 3 часов до 2-3 дней в зависимости от сложности изображения, количества цветов и технологии печати! Наши специалисты смогу сделать расчеты в максимально короткие сроки по ценам на подготовку файлов, а так же определить сроки всех процессов от сдачи макета до получения всего тиража продукции.<br />За более подробной информацией обращайтесь к нашим специалистам.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', 'design'),
(7, '2013-02-25 08:33:40', '2014-11-08 09:28:48', 1, 1, 1, 1, 56, 0, 'Цифровая печать', 'Xerox 700i обеспечивает работу с носителями формата от А6 (100x148мм) до SRA3+ (330x488мм) из всех внутренних лотков. Аппарат рассчитан на немелованную бумагу весом 64-300 г/м2, мелованную – 106-300 г/м2. Автоматическая дуплексная печать возможна на материалах до 300 г/м2;', '652', '<p>Цифровая печать является неотъемлемым атрибутом современного рекламного производства. Она позволяет изготовить высококачественную &nbsp;печатную продукции в самые короткие сроки, в том числе малыми тиражами.<strong> </strong></p>\r\n<p><strong>Мы печатаем на XEROX 700i&nbsp; Pro</strong></p>\r\n<p><img src="/files/ophen/n_Xerox_700_Digital_Color_Press.jpg" border="0" width="800" height="355" /><br />- Xerox 700i обеспечивает работу с носителями формата от А6 (100x148мм) до SRA3+ (330x488мм) из всех внутренних лотков. Аппарат рассчитан на немелованную бумагу весом 64-300 г/м2, мелованную &ndash; 106-300 г/м2. Автоматическая дуплексная печать возможна на материалах до 300 г/м2;<br />- Максимальное разрешение печати 2400 x 2400 DPI обеспечивает уникальное качество печати, а производительность до 71 стр./мин. (в режимах печати и копирования) обеспечивает непревзойденные характеристики модели в своем сегменте;<br />- Встроенный сканер обеспечивает работу на скорости 50 страниц в минуту в цветном режиме и 80 страниц в минуту в черно-белом режиме. Емкость листов сканера составляет 250 листов, для которых с помощью дуплексного автоподатчика оригиналов (DADF) обеспечивается двухстороннее сканирование оригиналов формата до A3;<br />- Использование усовершенствованной технологии на печатном производстве позволяет регистрировать бумагу в диапазоне +/- 0.5 мм. Кроме того, в аппарате встроен декелер, который обеспечивает активное устранение скручивания плотного материала для печати;</p>', '');
INSERT INTO `k2_block27` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `NAME`, `TEXT`, `PHOTO`, `TEXT_FULL`, `CLASS`) VALUES
(8, '2013-04-09 17:12:02', '2014-11-26 19:44:39', 1, 1, 0, 80, 56, 0, 'Продажа промо трикотажа и готовых изделий', 'Наш склад регулярно пополняется новыми видами промо-одежды из трикотажа. Всегда в наличии футболки мужские и женские из 100% хлопка и хлопка с лайкрой.', '668', '<p>Компания "Аваль-Принт" предлагает большой ассортимент трикотажной продукции для рекламного рынка. В настоящее время сформирован склад мужских, женских и даже детских футболок, а также рубашек-поло, силуэтных футболок, маек без рукавов, борцовок, толстовок и даже таких нестандартных позиций, как тельняжки и пижамы. Мы можем изготовить партию любой трикотажной продукцию с учетом всех Ваших пожеланий: модель, ткань, цвет, фурнитура и т.д.</p>\r\n<p>При индивидуальном пошиве подбирается полотно необходимой Вам плотности, а цвет согласовывается по пантону TCX или TPX. Минимальный заказ на 1 цвет одной модели - 1000 шт.</p>\r\n<table style="width: 100%; border: 1px solid #ffffff;" border="1" cellspacing="0" cellpadding="5">\r\n<tbody>\r\n<tr>\r\n<td style="width: 50%;" valign="top">\r\n<p><a href="/files/ophen/belaya.jpg" rel="lightbox[1]"><img src="/files/ophen/belaya.jpg" border="0" width="220" height="331" style="margin-right: 10px; float: left; margin-bottom: 210px;" /></a><strong>Футблока мужская стандарт</strong></p>\r\n<p>Состав ткани: Хлопок 100%<br />Плотность: 150 г / м2<br />Воротник: Рибана<br />Доступные размеры: 44-56</p>\r\n<p><br />Наличие цветов:<br /><img src="/files/ophen/white.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/grey.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/red.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/blue.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/green.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/yellow.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/black.gif" border="0" width="16" height="16" />&nbsp;<br />Итого: 35 365 шт.</p>\r\n<p>Стоимость за единицу:<br />От 1 до 500 &mdash; 90 руб.;<br />От 500 до 1000 шт &mdash; 85 руб.;<br />Свыше 1000 шт &mdash; 80 руб.;<br />Свыше 10000 шт &mdash; индивидуально.</p>\r\n<p><a href="/files/ophen/zheltaya.jpg" rel="lightbox[1]"><img src="/files/ophen/zheltaya.jpg" border="0" width="50" /></a> <a href="/files/ophen/zel.jpg" rel="lightbox[1]"><img src="/files/ophen/zel.jpg" border="0" width="50" /></a> <a href="/files/ophen/Krassnaya.jpg" rel="lightbox[1]"><img src="/files/ophen/Krassnaya.jpg" border="0" width="50" /></a> <a href="/files/ophen/seraya.jpg" rel="lightbox[1]"><img src="/files/ophen/seraya.jpg" border="0" width="50" /></a> <a href="/files/ophen/sinyaya.jpg" rel="lightbox[1]"><img src="/files/ophen/sinyaya.jpg" border="0" width="50" /></a> <a href="/files/ophen/chern.jpg" rel="lightbox[1]"><img src="/files/ophen/chern.jpg" border="0" width="50" /></a></p>\r\n</td>\r\n<td style="width: 50%;" valign="top">\r\n<p><a href="/files/ophen/zh.jpg" rel="lightbox[6]"><img src="/files/ophen/zh.jpg" border="0" width="220" height="331" style="margin-right: 10px; float: left; margin-bottom: 30px;" /></a><strong>Футболка женская</strong></p>\r\n<p>Состав ткани: Хлопок 100%<br />Плотность: 150 г / м2<br />Воротник: Рибана<br />Доступные размеры: 42-52<br />Наличие цветов:<br /><img src="/files/ophen/black.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/orange.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/yellow.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/violet.gif" border="0" width="16" height="16" />&nbsp;<br />Итого: 2550 шт.</p>\r\n<p>Ожидается поступление<br />Стоимость за единицу:<br />110 руб.</p>\r\n<p><a href="/files/ophen/k(1).jpg" rel="lightbox[6]"><img src="/files/ophen/k(1).jpg" border="0" width="50" /></a> <a href="/files/ophen/o.jpg" rel="lightbox[6]"><img src="/files/ophen/o.jpg" border="0" width="50" /></a> <a href="/files/ophen/or.jpg" rel="lightbox[6]"><img src="/files/ophen/or.jpg" border="0" width="50" /></a> <a href="/files/ophen/sin.jpg" rel="lightbox[6]"><img src="/files/ophen/sin.jpg" border="0" width="50" /></a> <a href="/files/ophen/chernaya(2).jpg" rel="lightbox[6]"><img src="/files/ophen/chernaya(2).jpg" border="0" width="50" /></a></p>\r\n<p><strong><br /></strong></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style="width: 50%;" valign="top"><a href="/files/ophen/Chernyy.jpg" rel="lightbox[3]"><img src="/files/ophen/Chernyy.jpg" border="0" width="220" height="331" style="float: left; margin-right: 10px;" /></a>\r\n<p><strong>Футблока мужская с окантовкой</strong></p>\r\n<p>Состав ткани: Хлопок 100%<br />Плотность: 150 г / м2<br />Воротник: Окантовка<br />Доступные размеры: 44-56<br />Наличие цветов:<br /><img src="/files/ophen/yellow.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/black.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/red.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/grey.gif" border="0" width="16" height="16" />&nbsp;<br />Итого: 2000 шт.</p>\r\n<p>Стоимость за единицу:<br />110 руб.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="/files/ophen/B.jpg" rel="lightbox[3]"><img src="/files/ophen/B.jpg" border="0" width="50" height="75" /></a>&nbsp;<a href="/files/ophen/k.jpg" rel="lightbox[3]"><img src="/files/ophen/k.jpg" border="0" width="50" height="75" /></a>&nbsp;</p>\r\n</td>\r\n<td style="width: 50%;" valign="top">\r\n<p><a href="/files/ophen/belaya(3).jpg" rel="lightbox[9]"><img src="/files/ophen/belaya(3).jpg" border="0" width="220" height="331" style="float: left; margin-right: 10px;" /></a><strong>Футблока женская стрейтч</strong></p>\r\n<p>Состав ткани: Хлопок 92% / Эластан 8%</p>\r\n<p>Воротник: Окантовка<br />Доступные размеры: 40.<br />Наличие цветов:<br /><img src="/files/ophen/grey.gif" border="0" width="16" height="16" />&nbsp;<br />Итого: 350 шт.</p>\r\n<p>Стоимость за единицу:<br />145 руб.</p>\r\n<p><strong><br /></strong></p>\r\n<p><strong><br /></strong></p>\r\n<p><strong> <a href="/files/ophen/seryy.jpg" rel="lightbox[9]"><img src="/files/ophen/seryy.jpg" border="0" width="50" height="75" /></a> <a href="/files/ophen/chernaya(3).jpg" rel="lightbox[9]"><img src="/files/ophen/chernaya(3).jpg" border="0" width="50" height="75" /></a></strong></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style="width: 50%;" valign="top"><a href="/files/ophen/belaya(1).jpg" rel="lightbox[2]"><img src="/files/ophen/belaya(1).jpg" border="0" height="331" style="margin-right: 10px; float: left; margin-bottom: 50px;" /></a><strong>Поло мужское</strong>\r\n<p>Состав ткани: Хлопок 100%, пике.<br />Плотность: 230 г / м2<br />Воротник: Вязанный<br />Доступные размеры: 44-56.<br />Наличие цветов:<br /><img src="/files/ophen/white.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/blue.gif" border="0" width="16" height="16" /><br />На складе - 14 600 шт.</p>\r\n<p>Стоимость за единицу:<br />От 1 до 500 &mdash; 250 руб.;<br />От 500 до 1000 шт &mdash; 240 руб.;<br />Свыше 1000 шт &mdash; 230 руб.;<br />Свыше 10000 шт &mdash; индивидуально.</p>\r\n<p><a href="/files/ophen/chernaya.jpg" rel="lightbox[2]"><img src="/files/ophen/chernaya.jpg" border="0" width="50" height="75" /></a>&nbsp;<a href="/files/ophen/sinyaya(1).jpg" rel="lightbox[2]"><img src="/files/ophen/sinyaya(1).jpg" border="0" width="50" height="75" /></a>&nbsp;<a href="/files/ophen/krassnaya.jpg" rel="lightbox[2]"><img src="/files/ophen/krasnaya.jpg" border="0" width="50" height="81" /></a></p>\r\n</td>\r\n<td style="width: 50%;" valign="top"><a href="/files/ophen/krasnaya(1).jpg" rel="lightbox[4]"><img src="/files/ophen/krasnaya(1).jpg" border="0" width="220" height="331" style="float: left; margin-right: 10px;" /></a><strong>Поло женское</strong>\r\n<p>Состав ткани: Хлопок 100%, пике.<br />Воротник: Вязанный<br />Доступные размеры: 46.<br />Наличие цветов.<br /><img src="/files/ophen/black.gif" border="0" width="16" height="16" />&nbsp;<br />На складе - 7 846 шт.</p>\r\n<p>Стоимость за единицу:<br />От 1 до 500 &mdash; 245 руб.;<br />От 500 до 1000 шт &mdash; 235 руб.;<br />Свыше 1000 шт &mdash; 225 руб.;<br />Свыше 10000 шт &mdash; индивидуально.&nbsp;</p>\r\n<p><a href="/files/ophen/belaya(2).jpg" rel="lightbox[8]"><img src="/files/ophen/belaya(2).jpg" border="0" width="50" height="75" /></a>&nbsp; <a href="/files/ophen/chernaya(1).jpg" rel="lightbox[8]"><img src="/files/ophen/chernaya(1).jpg" border="0" width="50" height="75" /></a></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style="width: 50%;" valign="top"><strong>Майка мужская<br /></strong>\r\n<p><a href="/files/ophen/12.jpg" rel="lightbox[16]"><img src="/files/ophen/12.jpg" border="0" width="220" height="331" style="margin-right: 10px; float: left; margin-bottom: 30px;" /></a>Состав ткани: Хлопок 100%.<br />Воротник: Окантовка<br />Доступные размеры: 48-56.<br />Наличие цветов:<br /><img src="/files/ophen/white.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/black.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/blue.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/green.gif" border="0" width="16" height="16" />&nbsp;</p>\r\n<p>Итого: 3 090 шт.</p>\r\n<p>Стоимость за единицу:<br />От 1 до 500 &mdash; 78 руб.;<br />От 500 до 1000 шт &mdash; 72 руб.;<br />Свыше 1000 шт &mdash; 69 руб.;<br />Свыше 10000 шт &mdash; индивидуально.</p>\r\n<p><a href="/files/ophen/KOS_7643kopiya.jpg" rel="lightbox[16]"><img src="/files/ophen/KOS_7643kopiya.jpg" border="0" width="50" height="75" /></a>&nbsp; &nbsp;</p>\r\n</td>\r\n<td style="width: 50%;" valign="top">&nbsp;<strong><a href="/files/ophen/gol.jpg" rel="lightbox[11]"><img src="/files/ophen/gol.jpg" border="0" width="220" height="331" style="margin-right: 10px; float: left; margin-bottom: 30px;" /></a></strong><strong>Футболка женская глубокий вырез</strong>\r\n<p>Состав ткани: Хлопок 95% / Эластан 5%<br />Воротник: Окантовка<br />Доступные размеры: 42-52.<br />Наличие цветов:<br /><img src="/files/ophen/fistash.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/orange.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/yellow.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/violet.gif" border="0" width="16" height="16" />&nbsp;&nbsp;<br />Итого: 3420 шт.</p>\r\n<p>Стоимость за единицу:<br />145 руб.</p>\r\n<p>&nbsp;&nbsp;<a href="/files/ophen/zelenaya.jpg" rel="lightbox[11]"><img src="/files/ophen/zelenaya.jpg" border="0" width="50" /></a>&nbsp;<a href="/files/ophen/oranzh.jpg" rel="lightbox[11]"><img src="/files/ophen/oranzh.jpg" border="0" width="50" /></a>&nbsp;<a href="/files/ophen/roz.jpg" rel="lightbox[11]"><img src="/files/ophen/roz.jpg" border="0" width="50" /></a></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style="width: 50%;" valign="top">\r\n<p><a href="/files/ophen/KOS_7685kopiya.jpg" rel="lightbox[12]"><img src="/files/ophen/KOS_7685kopiya.jpg" border="0" width="220" height="331" style="margin-right: 10px; float: left; margin-bottom: 30px;" /></a><strong>Майка мужская камуфляж и тельняшка</strong><br />Состав ткани: Хлопок 100%.<br />Воротник: Окантовка<br />Доступные размеры: 48-56.<br />Наличие цветов:<br /><img src="/files/ophen/camufla.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/teln.gif" border="0" width="16" height="16" />&nbsp;<br />Итого: 1 129 шт.</p>\r\n<p>Стоимость за единицу:<br />От 1 до 500 &mdash; 102 руб.;<br />От 500 до 1000 шт &mdash; 95 руб.;<br />Свыше 1000 шт &mdash; 87 руб.;<br />Свыше 10000 шт &mdash; индивидуально.</p>\r\n<p><a href="/files/ophen/KOS_7653kopiya.jpg" rel="lightbox[12]"><img src="/files/ophen/KOS_7653kopiya.jpg" border="0" width="50" height="75" /></a></p>\r\n</td>\r\n<td style="width: 50%;" valign="top">\r\n<p><strong><a href="/files/ophen/telnyashka.jpg" rel="lightbox[13]"><img src="/files/ophen/telnyashka.jpg" border="0" width="220" height="331" style="margin-right: 10px; float: left; margin-bottom: 30px;" /></a>Тельняшка мужская</strong> <br />Состав ткани: Хлопок 100%.<br />Воротник: Окантовка<br />Рукав: Длинный<br />Доступные размеры: 48-56.<br />Наличие цветов:<br /><img src="/files/ophen/blue.gif" border="0" width="16" height="16" />&nbsp;</p>\r\n<p>Итого: 1540 шт.</p>\r\n<p>Стоимость за единицу:<br />От 1 до 500 &mdash; 168 руб.;<br />От 500 до 1000 шт &mdash; 160 руб.;<br />Свыше 1000 шт &mdash; 152 руб.;<br />Свыше 10000 шт &mdash; индивидуально.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style="width: 50%;" valign="top">\r\n<p><a href="/files/ophen/KOS_8396kopiya.jpg" rel="lightbox[14]"><img src="/files/ophen/KOS_8396kopiya.jpg" border="0" width="220" height="331" style="margin-right: 10px; float: left; margin-bottom: 30px;" /></a><strong>Футболка детская для мальчиков</strong><br />Состав ткани: Хлопок 100%.<br />Доступные размеры: 28-34.<br />Наличие цветов:<br /><img src="/files/ophen/white.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/red.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/yellow.gif" border="0" width="16" height="16" />&nbsp;</p>\r\n<p>Итого: 2270 шт.</p>\r\n<p>Стоимость за единицу:<br />От 1 до 500 &mdash; 72 руб.;<br />От 500 до 1000 шт &mdash; 68 руб.;<br />Свыше 1000 шт &mdash; 66 руб.;<br />Свыше 10000 шт &mdash; индивидуально.</p>\r\n<p><a href="/files/ophen/KOS_8404kopiya.jpg" rel="lightbox[14]"><img src="/files/ophen/KOS_8404kopiya.jpg" border="0" width="50" height="75" /></a>&nbsp;<a href="/files/ophen/KOS_8433kopiya.jpg" rel="lightbox[14]"><img src="/files/ophen/KOS_8433kopiya.jpg" border="0" width="50" height="75" /></a></p>\r\n</td>\r\n<td style="width: 50%;" valign="top">\r\n<p><a href="/files/ophen/KOS_8420kopiya.jpg" rel="lightbox[15]"><img src="/files/ophen/KOS_8420kopiya.jpg" border="0" width="220" height="331" style="margin-right: 10px; float: left; margin-bottom: 80px;" /></a><strong>Футболка детская для девочек</strong><br />Состав ткани: Хлопок 100%.<br />Доступные размеры: 28-34.<br />Наличие цветов:<br /><img src="/files/ophen/violet.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/grey.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/red.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/malina.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/yellow.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/orange.gif" border="0" width="16" height="16" />&nbsp;<img src="/files/ophen/blue.gif" border="0" width="16" height="16" />&nbsp;</p>\r\n<p>Итого: 9970 шт.</p>\r\n<p>Стоимость за единицу:<br />От 1 до 500 &mdash; 72 руб.;<br />От 500 до 1000 шт &mdash; 68 руб.;<br />Свыше 1000 шт &mdash; 66 руб.;<br />Свыше 10000 шт &mdash; индивидуально.</p>\r\n<p><a href="/files/ophen/KOS_8446kopiya.jpg" rel="lightbox[15]"><img src="/files/ophen/KOS_8446kopiya.jpg" border="0" width="50" height="75" /></a></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>', ''),
(9, '2013-06-13 10:28:27', '2014-11-14 16:23:10', 1, 1, 1, 5, 56, 0, 'Рекламное производство', 'Компания Победа - это молодое быстроразвивающееся объединение, которое предлагает следующие услуги:\r\n- полиграфическое производство (оперативная, офсетная, флексографическая и трафаретная печати на различных видах продукции);', '677', '<table border="0">\r\n<tbody>\r\n<tr>\r\n<td><a href="/files/ophen/reklama(1).JPG" rel="lightbox[mhm]"><img src="/files/ophen/reklama(1).JPG" border="0" width="150" height="98" style="margin: 10px;" /></a><br /> <a href="/files/ophen/reklama(2).JPG" rel="lightbox[mhm]"><img src="/files/ophen/reklama(2).JPG" border="0" width="150" height="98" style="margin: 10px;" /></a><br /> <a href="/files/ophen/reklama(3).JPG" rel="lightbox[mhm]"><img src="/files/ophen/reklama(3).JPG" border="0" width="150" height="98" style="margin: 10px;" /></a><br /> <a href="/files/ophen/reklama(4).JPG" rel="lightbox[mhm]"><img src="/files/ophen/reklama(4).JPG" border="0" width="150" height="98" style="margin: 10px;" /></a><br />&nbsp;</td>\r\n<td valign="top">\r\n<p>Группа компаний &laquo;Победа&raquo; предоставляет профессиональные услуги в создании торгового оборудования, применяя при этом самые новейшие технологии. Мы производим стеллажи, полки, информационные стенды, дополнительные аксессуары и многое другое. Помимо элементов внутреннего оформления, компания Победа изготавливает и устанавливает оборудование для наружной рекламы: короба, лайтбоксы, натяжные баннерные металлоконструкции.<br />Так же, мы предлагаем широчайший спектр качественных монтажных работ любой сложности.</p>\r\n<p><a href="http://www.pobedarf.com/" target="_blank">http://www.pobedarf.com/</a></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', ''),
(11, '2014-10-15 04:14:50', '2014-11-25 14:04:54', 1, 1, 1, 2, 56, 0, 'Широкоформатная печать и УФ-печать', 'Печать производится на широкоформатных принтерах с шириной печатного поля до 3200 мм. Качество печати от 360 до 1440dpi. Печатные чернила на основе сольвента не требуют ламинирования и устойчивы к погодным условиям и ультрафиолетовым лучам.', '810', '<p>Печать производится на широкоформатных принтерах с шириной печатного поля до 3200 мм. Качество печати от 360 до 1440dpi. Печатные чернила на основе сольвента не требуют ламинирования и устойчивы к погодным условиям и ультрафиолетовым лучам.</p>\r\n<p><br /><strong>Печать осуществляется на:</strong></p>\r\n<p>- баннере;<br />- самоклеящейся пленке (матовая, глянцевая, прозрачная);<br />- постерной бумаге;<br />- ткани (полиэстере).</p>\r\n<p><strong>Послепечатная обработка:</strong><br />- Прикатка на пластик<br />- Проварка карманов<br />- Установка люверсов<br />- Установка шнуровки<br />- Сварка баннеров<br />- Точная порезка<br />- Усиление краев<br />- Ламинация</p>', ''),
(10, '2013-06-13 10:37:16', '2014-10-22 10:41:30', 1, 1, 1, 7, 56, 0, 'Дополнительные услуги', 'В компании «Победа» есть собственная служба логистики. Мы осуществляем доставку собственным автотранспортом по г.Ростову-на-Дону и области.\r\nМы осуществляем доставку по городу при заказе от 200 единиц продукции - бесплатно.\r\nДо 200 единиц - 300 руб', '679', '<p>В компании &laquo;Победа&raquo; есть собственная служба логистики. Мы осуществляем доставку собственным автотранспортом по г.Ростову-на-Дону и области.<br /><br />Мы осуществляем доставку по городу при заказе от 200 единиц продукции - бесплатно.<br />До 200 единиц - 300 руб.<br /><br />Для заказчиков из других регионов России - доставка до указанных транспортных компаний БЕСПЛАТНАЯ:<br /><br />Транспортная компания "Деловые линии" - <a href="http://www.dellin.ru/" target="_blank">http://www.dellin.ru/</a><br />Транспортная компания "Первая Экспедиционная компания"- <a href="http://www.pecom.ru/ru/" target="_blank">http://www.pecom.ru/ru/</a><br />Транспортная компания "Байкал Сервис" - <a href="http://www.baikalsr.ru/" target="_blank">http://www.baikalsr.ru/</a><br />Курьерская служба "Курьер Сервис Экспресс" - <a href="http://www.cse.ru/" target="_blank">http://www.cse.ru/</a></p>', '');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block27category`
--

DROP TABLE IF EXISTS `k2_block27category`;
CREATE TABLE IF NOT EXISTS `k2_block27category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block28`
--

DROP TABLE IF EXISTS `k2_block28`;
CREATE TABLE IF NOT EXISTS `k2_block28` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `PHOTO` varchar(255) NOT NULL,
  `TEXT` mediumtext NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block28`
--

INSERT INTO `k2_block28` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `NAME`, `PHOTO`, `TEXT`) VALUES
(1, '2012-11-27 10:55:20', '2013-03-13 08:29:36', 1, 1, 1, 10, 57, 1, 'МНМ Synchroprint S-type 12-14', '391', '<p>Высокоскоростная печатная машина &laquo;МНМ Synchroprint S-type 12-14&raquo; с площадью печати 60 на 80 см. (Австрия)</p>\r\n<p><span style="color: #000000;"><span>&bull;&nbsp;</span>формат печати до 600 на 800 мм.</span><br /><span style="color: #000000;">&bull;&nbsp;количество цветов &mdash; до 11</span><br /><span style="color: #000000;">&bull;&nbsp;две промежуточные сушки</span><br /><span style="color: #000000;">&bull;&nbsp;скорость печати до 1300 циклов в час</span><br /><span style="color: #000000;">&bull;&nbsp;возможность работы с кроем и готовыми изделиями</span><br /><span style="color: #000000;">&bull;&nbsp;</span>три комплекта столов для работы с детским ассортиментом продукции, кроем и готовыми изделиями</p>\r\n<p>&nbsp;</p>\r\n<p><a href="/files/ophen/KOS_8825.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8825.jpg" border="0" width="150" style="margin-right: 10px;" /> </a><a href="/files/ophen/KOS_8846.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8846.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8874.jpg" rel="lightbox[mhm]"><img src="/files/ophen/KOS_8874.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p><span style="color: #000000;"><br /></span></p>\r\n<p><span style="color: #000000;"><br /></span></p>\r\n<p><span style="color: #000000;"><br /></span></p>'),
(6, '2012-11-28 09:55:36', '2013-03-13 08:40:11', 1, 1, 1, 60, 57, 4, 'Туннельная сушка комбинированного типа «МНМ» (Австрия)', '419', '<p>конвенция + лампы, с шириной транспортера 150 см и длинной сушильной камеры 400 см &laquo;МНМ&raquo;(Австрия);<br /> сушка изделий в линию двумя способами: лампы 150 см + конвенция воздуха 250 см.<br /> автоматическая регулирвока температуры от 15 до 450 С<sup>0</sup>!<br /> возможность регулировки потока воздуха.</p>\r\n<p><a title="Туннельная сушка комбинированного типа &laquo;МНМ&raquo; (Австрия)" href="/files/ophen/KOS_8816.jpg" rel="lightbox[mhm2]"><img src="/files/ophen/KOS_8816.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a title="Туннельная сушка комбинированного типа &laquo;МНМ&raquo; (Австрия)" href="/files/ophen/KOS_8823.jpg" rel="lightbox[mhm2]"><img src="/files/ophen/KOS_8823.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a title="Туннельная сушка комбинированного типа &laquo;МНМ&raquo; (Австрия)" href="/files/ophen/KOS_8817.jpg" rel="lightbox[mhm2]"><img src="/files/ophen/KOS_8817.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a title="Туннельная сушка комбинированного типа &laquo;МНМ&raquo; (Австрия)" href="/files/ophen/KOS_8819.jpg" rel="lightbox[mhm2]"><img src="/files/ophen/KOS_8819.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a title="Туннельная сушка комбинированного типа &laquo;МНМ&raquo; (Австрия)" href="/files/ophen/KOS_8821.jpg" rel="lightbox[mhm2]"><img src="/files/ophen/KOS_8821.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(2, '2012-11-27 10:56:10', '2013-03-11 10:32:34', 1, 1, 1, 20, 57, 1, 'Ручной карусельный станок', '392', '<p>Ручной карусельный станок для изготовления образцов и мелких тиражей 6-6 с площадью печати 35 на 40 см. (Россия);<br /> &bull; формат печати до 350 на 400 мм.<br /> &bull; колличество цветов &mdash; до 6<br /> &bull; промежуточная сушка<br /> &bull; система точности приводок изображения до 0,01 мм!<br /> &bull; работа с водными красками!<br /> &bull; промежуточная сушка с ИК лампами (Россия);<br /> &bull; промежуточная сушка ИК МНМ (Австрия);</p>\r\n<p><a title="Ручной карусельный станок для изготовления образцов и мелких тиражей 6-6 с площадью печати 35 на 40 см" href="/files/ophen/KOS_8927.jpg" rel="lightbox[rks]"><img src="/files/ophen/KOS_8927.jpg" border="0" width="150" style="margin-right: 10px;" /> </a> <a title="Ручной карусельный станок для изготовления образцов и мелких тиражей 6-6 с площадью печати 35 на 40 см" href="/files/ophen/KOS_8929.jpg" rel="lightbox[rks]"><img src="/files/ophen/KOS_8929.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p><span><br /></span></p>\r\n<p><span><br /></span></p>\r\n<p><span><br /></span></p>'),
(7, '2012-11-30 08:14:35', '2013-03-13 08:38:12', 1, 1, 1, 70, 57, 2, 'Фотонаборный аппарат «Gеndelberg Praimssetter» 102 формата (Германия)', '394', '<p>Наличие собственного фотонаборного аппарата по выводу пленок дает производству оперативность в работе на самом первом этапе производства &mdash; выводе пленок! Аппарат имеет возможность работы с любой линиатурой и плотностью, необходимой клиенту для достижения поставленных задач.</p>\r\n<p><a href="/files/ophen/primes.JPG" rel="lightbox[pr]"><img src="/files/ophen/primes.JPG" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/primesetter_74.jpg" rel="lightbox[pr]"><img src="/files/ophen/primesetter_74.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p>&nbsp;</p>'),
(8, '2012-11-30 08:19:39', '2013-03-11 10:45:08', 1, 1, 1, 80, 57, 2, 'Засветочная камера «Tri-Laght ST M&R» 6 кв (США)', '395', '<p>&mdash; возможность засветки одновременно двух рам размером до 700 на 950 мм!&nbsp;</p>\r\n<p>&mdash; максимальное время засветки даже при самом толстом слое эмульсии не более трех минут!</p>\r\n<p>&mdash; экспонирование до 200 рам за рабочую смену!</p>\r\n<p><a href="/files/ophen/KOS_8760.jpg" rel="lightbox[pr]"><img src="/files/ophen/KOS_8760.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8766.jpg" rel="lightbox[pr]"><img src="/files/ophen/KOS_8766.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(3, '2012-11-27 10:56:43', '2012-12-03 04:40:37', 1, 1, 0, 30, 57, 4, 'Промежуточные сушки ИК лампами (Россия)', '309', '<p>Инфракрасные сушки применяются для быстрой сушки шпатлёванных и окрашенных поверхностей.</p>\r\n<p>Для сушки используется коротковолновое (с длиной волны от 2 до 0.76 мкм) излучение инфракрасного диапазона. Преимущество коротковолнового излучения по сравнению со средне- и длинноволновым в том, что оно проникает через все слои лакокрасочного материала и, отражаясь от металла, производит сушку этого материала также изнутри.</p>'),
(14, '2012-11-30 10:46:13', '2013-03-11 10:42:19', 1, 1, 1, 140, 57, 3, 'Вышивальная машина «YONTHIN» 1-а головочная с площадью 360 на 480 мм (Китай)', '649', '<p>&mdash; 15 нитей;</p>\r\n<p>&mdash; работа с пайетками, шнуром, выкладка кроя и т. д.;</p>\r\n<p>&mdash; Память до 2000000 стежков;</p>\r\n<p>&mdash; Машина так же имеет возможность вышивать как на крое, так и на готовых изделиях, в комплекте есть различные пяльца и крепления;</p>\r\n<p>&mdash; Эта машина позволяет изготавливать тиражи от одного изделия до нескольких сотен.</p>\r\n<p><a href="/files/ophen/1788866.jpg" rel="lightbox"><img src="/files/ophen/1788866.jpg" border="0" width="200" height="200" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(4, '2012-11-27 10:57:15', '2013-03-13 08:38:55', 1, 1, 1, 40, 57, 4, 'Промежуточная сушка ИК «МНМ» 2 шт. (Австрия)', '421', '<p>Промежуточные сушки (подсушки) MSI используются для промежуточной сушки слоя краски при многоцветной трафаретной печати, на автоматических карусельных станках производства MHM (Австрия), а также на карусельных станках других производителей.</p>\r\n<p><a title="Промежуточная сушка ИК &laquo;МНМ&raquo; (Австрия)" href="/files/ophen/KOS_8838.jpg" rel="lightbox[sushka]"><img src="/files/ophen/KOS_8838.jpg" border="0" width="150" /></a>&nbsp;&nbsp;<a title="Промежуточная сушка ИК &laquo;МНМ&raquo; (Австрия)" href="/files/ophen/KOS_8837.jpg" rel="lightbox[sushka]"><img src="/files/ophen/KOS_8837.jpg" border="0" width="150" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(10, '2012-11-30 08:33:47', '2013-03-11 10:47:12', 1, 1, 1, 100, 57, 2, 'Автомат нанесения эмульсии марки «GRUNIC G-COAT 404» (Швейцария)', '397', '<p>&mdash; возможность нанесения эмульсии идеально ровным и тонким слоем на трафаретные рамы размером до 1500 мм в ширину и 2000 мм в высоту.</p>\r\n<p>В комплект входят несколько видов кювет с различной толщиной кромки для прохождения эмульсии, что позволяет изготавливать трафареты как с очень тонкими слоями, так и с толстыми слоями эмульсии для специальных эффектов при печати.&nbsp;</p>\r\n<p>&mdash; аппарат имеет регулировки задержки кюветки, количество проходов по сетке, угол наклона и поворота.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><a href="/files/ophen/KOS_8795.jpg" rel="lightbox[pr]"><img src="/files/ophen/KOS_8795.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8799.jpg" rel="lightbox[pr]"><img src="/files/ophen/KOS_8799.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8807.jpg" rel="lightbox[pr]"><img src="/files/ophen/KOS_8807.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(11, '2012-11-30 08:35:17', '2013-03-11 10:49:09', 1, 1, 1, 110, 57, 2, 'Участок промывки и установки пленок в позицию «0»', '398', '<p>На участке промывки рам установлен шкаф с матовым оргстеклом размером 250 см на 200 см для одновременной промывки сразу трех рам! В помещении создано специальное приглушенное освещение, что позволяет добиваться максимально точного уровня экспонирования эмульсии и промывки рам. Устройство марки МНМ для приводки пленок на трафаретные рамы, позволяет сразу совмещать все изображения по крестам в позицию ноль, что максимально экономит время при работе с изображением на автоматической карусели.</p>\r\n<p><a href="/files/ophen/KOS_8773.jpg" rel="lightbox[pr2]"><img src="/files/ophen/KOS_8773.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8775.jpg" rel="lightbox[pr2]"><img src="/files/ophen/KOS_8775.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8776.jpg" rel="lightbox[pr2]"><img src="/files/ophen/KOS_8776.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8786.jpg" rel="lightbox[pr2]"><img src="/files/ophen/KOS_8786.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8787.jpg" rel="lightbox[pr2]"><img src="/files/ophen/KOS_8787.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(12, '2012-11-30 10:33:22', '2013-03-11 10:40:22', 1, 1, 1, 120, 57, 3, 'Термотрансферный пресс с площадью 350 на 450 мм. (Германия)', '648', '<p>Пресс предназначен для переноса фольги или печатных изображений на различного рода ткани и готовые изделия, таких как: бейсболки, куртки, фартуки, поло, костюмы и т.д., а также для переноса специальных видов изображений (светоотражающих материалов) и пр.</p>'),
(13, '2012-11-30 10:38:50', '2013-03-13 08:32:45', 1, 1, 1, 130, 57, 3, 'Вышивальная машина на 6 голов по 12 нитей в каждой «YONTHIN»', '642', '<p lang="ru-RU" align="LEFT">Вышивальная машина на 6 голов по 12 нитей в каждой с возможностью пришивания пайеток, шнуров, выкладки аппликаций на изделия, возможностью вышивки, как на крое, так и на готовых изделиях, а также на кепках, рукавах, воротниках и т.д. &laquo;YONTHIN&raquo; (Китай) с площадью 360 на 480 мм предназначена для:</p>\r\n<p lang="ru-RU" align="LEFT">&mdash; вышивки на готовых изделиях, рукавах и карманах</p>\r\n<p lang="ru-RU" align="LEFT">&mdash; вышивки на крое и полотне.</p>\r\n<p lang="ru-RU" align="LEFT">&mdash; в комплекте имеются пяльца различных размеров и форм, а также рамы для крепления полотна и рулонов ткани.</p>\r\n<p lang="ru-RU" align="LEFT">При изготовлении программы вышивки можно учитывать также бесперебойную вышивку по всей длине машины, а именно 360 на 2300 мм.</p>\r\n<p><a href="/files/ophen/1788395.jpg" rel="lightbox"><img src="/files/ophen/1788395.jpg" border="0" width="200" height="200" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(5, '2012-11-27 10:57:32', '2013-03-13 08:39:11', 1, 1, 1, 50, 57, 4, 'Туннельная сушка «FUSION M&R»', '311', '<p>Высокоэффективные туннельные сушильные устройства Fusion предназначены для финишной сушки оттисков, выполненных на текстильных изделиях. Легкие и удобные в эксплуатации, Fusion выпускаются с шириной транспортера 91, 122, 152 см и размерами сушильной камеры 183 и 305 см.</p>\r\n<p>Сушка оттисков выполняется под воздействием ИК-излучения. Камеры устройства выполнены из термостойкой листовой стали. Внутренние полости облицованы специальным теплозвукоизоляционным покрытием. Это обеспечивает быстрый выход на оптимальные рабочие режимы, стабильность работы и исключает нагрев воздуха в цехе.</p>\r\n<p><a title=" Туннельная сушка &laquo;FUSION M&amp;R&raquo;" href="/files/ophen/Fusion_panel.jpg" rel="lightbox[fusion]"><img src="/files/ophen/Fusion_panel.jpg" border="0" width="150" style="margin-right: 10px;" /></a><a title=" Туннельная сушка &laquo;FUSION M&amp;R&raquo;" href="/files/ophen/2a.jpg" rel="lightbox[fusion]"><img src="/files/ophen/2a.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(9, '2012-11-30 08:25:40', '2013-06-19 06:34:52', 1, 1, 1, 90, 57, 2, 'Система натяжки для трафаретных сеток «SEFAR 2» на 12 клупов (Швейцария);', '396', '<p>&mdash; возможность натяжки сеток на рамы размером до 800 на 1200 мм!</p>\r\n<p>&mdash; натяжка сеток осуществляется с двух голов, что позволяет максимально точно натягивать сетки на рамы в направлениях Х и Y</p>\r\n<p>&mdash; возможность натяжки сетки до 40 ньютонов на см2.</p>\r\n<p><a href="/files/ophen/KOS_8749.jpg" rel="lightbox[pr1]"><img src="/files/ophen/KOS_8749.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8752.jpg" rel="lightbox[pr1]"><img src="/files/ophen/KOS_8752.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8756.jpg" rel="lightbox[pr1]"><img src="/files/ophen/KOS_8756.jpg" border="0" width="150" style="margin-right: 10px;" /></a> <a href="/files/ophen/KOS_8833.jpg" rel="lightbox[pr1]"><img src="/files/ophen/KOS_8833.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(15, '2012-11-30 10:47:07', '2013-03-11 10:43:04', 1, 1, 1, 150, 57, 3, 'Лазерная машина для резки любого рода изделий с площадью стола 700 на 900 мм. «Laser Boat» (Китай)', '493', '<p>&mdash; возможность раскроя сложных фигурных изделий размером до 900 на 700 мм;</p>\r\n<p>&mdash; машина оснащена камерой и идеально подходит для вырезки готовых шевронов и других рисунков на ткани;</p>\r\n<p>&mdash; самостоятельно может распознавать контуры реза и площадь реза;</p>\r\n<p>&mdash; скорость резки изделий до 20 метров в минуту.</p>\r\n<p><span style="color: #000000;">&nbsp;</span></p>\r\n<p><a href="/files/ophen/yhlasercut.jpg" rel="lightbox[mhm]"><img src="/files/ophen/yhlasercut.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(16, '2012-12-04 12:04:48', '2013-03-11 10:49:52', 1, 1, 1, 160, 57, 2, 'Сушильный шкаф для трафаретных рам на 16 позиций марки «M&R» (США)', '497', '<p>&mdash; автоматическая регулировка потока воздуха как по мощности, так и по температуре (от 20 до 80 С<sup>0</sup>);</p>\r\n<p>&mdash; шкаф предназначен для одновременной сушки сразу 16 рам;</p>\r\n<p>&mdash; оснащен автоматическими лотками для погрузки рам и датчиком температуры и потока воздуха.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="/files/ophen/7-4-1-1b.jpg" rel="lightbox[mhm]"><img src="/files/ophen/7-4-1-1b.jpg" border="0" width="150" style="margin-right: 10px;" /></a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),
(17, '2014-10-22 06:29:37', '2014-10-22 08:11:41', 1, 1, 1, 170, 57, 7, 'AGFA Anapurna M 2050', '823', '<div>НОВИНКА! Первый на Юге УФ-плоттер с размером запечатаемого поля 2,05х3,00м!</div>\r\n<div>&nbsp;</div>\r\n<div>\r\n<div align="justify">AGFA Anapurna M 2050 &mdash; высокопроизводительный широкоформатный гибридный УФ-плоттер промышленного класса.</div>\r\n<div align="justify">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</div>\r\n<strong>Применение</strong>\r\n<div><span>Шестицветная палитра CMYKLcLm дополнена чернилами белого цвета, что позволяет существенно расширить область применения устройства, используя для печати прозрачные, полупрозрачные и цветные, в том числе темные основы.&nbsp;</span><span>Чернила AGFA Anapurna отличаются широким цветовым охватом и хорошей адгезией к самым разнообразным материалам без покрытия</span><strong><br /></strong></div>\r\n<div>\r\n<ul>\r\n<li>\r\n<div align="justify">бумага,</div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>самоклеящаяся ПВХ-пленка</span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>пленка для внутренней подсветки<br /></span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>армированный виниловый баннер<br /></span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>холст<br /></span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>сетка</span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>пенокартон</span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>гофрированный картон</span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>плитка</span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>гипсокартон</span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>стекло</span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>листовой металл</span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>пластик</span></div>\r\n</li>\r\n<li>\r\n<div align="justify"><span>дерево</span></div>\r\n</li>\r\n</ul>\r\n<span>Устройство является удобным инструментом для печати плакатов, щитовой рекламы, автомобильной графики, баннеров, художественных репродукций, производства выставочных стендов, POS-материалов, театральных декораций, персонализированных изделий (ковриков для мыши, например), элементов интерьерного дизайна.&nbsp;</span></div>\r\n<div>\r\n<div><span style="color: #2f2a2b; font-family: ''trebuchet MS'', ''Times New Roman'', Times, serif;"><span>&nbsp;</span></span></div>\r\n<strong>Особенности AGFA Anapurna M 2050</strong>\r\n<ul>\r\n<li>\r\n<div align="justify">Производительность: скоростной режим Express - 53 м&sup2;/чаc, производительный режим Production - 32 м&sup2;/час, режим плакатной печати Poster - 18 м&sup2;/час, режим фотографического качества Photo &mdash; 9 м&sup2;/час.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Максимальны размер запечатаемого поля 2,05х3,00м</div>\r\n</li>\r\n<li>\r\n<div align="justify">Высокое качество изображений как с большими участками сплошной заливки, так и с мелкими графическими деталями в режиме печати в восемь проходов.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Восемь высокоскоростных печатающих головок Konica Minolta: 6 головок 1024М (12&nbsp;<em>пл</em>) для основных цветов, 2 головки 1024 L (42&nbsp;<em>пл</em>) для белого цвета.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Разрешение печати AGFA Anapurna M 2050 &mdash; до 1440 dpi.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Возможность печати без полей, край в край.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">УФ-чернила характеризуются широким цветовым охватом и стабильным поведением в режимах высокоскоростной печати.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Чернила белого цвета позволяют использовать для печати прозрачные и цветные основы. &nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Высокая четкость изображения (в том числе позитивных текстов высотой 4 пункта и негативных высотой 6 пунктов), плавные цветовые переходы без градиентной ступенчатости, яркие и насыщенные цвета.</div>\r\n</li>\r\n<li>\r\n<div align="justify">Мгновенное отверждение чернил на поверхности носителя.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Регулируемый секционный (4 зоны) вакуумный прижим носителя в области печати дает возможность избежать образования складок и безошибочно работать на высоких скоростях. Помимо этого, вакуумный прижим позволяет предотвратить возникновение перекосов при печати на тяжелых материалах.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Высокоточная система подачи гарантирует равномерное перемещение без проскальзывания и перекосов как гибких рулонных, так и жестких листовых материалов.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Возможность печати на материалах с гладкой и неровной поверхностью.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Регулировка мощности УФ-ламп позволяет подбирать оптимальные режимы для печати на различных материалах.&nbsp;</div>\r\n</li>\r\n<li>\r\n<div align="justify">Долговечность отпечатков.<br />&nbsp;</div>\r\n</li>\r\n</ul>\r\n<p><em>&nbsp;материалы предоставлены компанией AGFA</em></p>\r\n<p><em><br /></em></p>\r\n<p><em><br /></em></p>\r\n</div>\r\n</div>');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block28category`
--

DROP TABLE IF EXISTS `k2_block28category`;
CREATE TABLE IF NOT EXISTS `k2_block28category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `PHOTO` varchar(255) NOT NULL,
  `TEXT` mediumtext NOT NULL,
  `PHOTO_` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block28category`
--

INSERT INTO `k2_block28category` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `SECTION_BLOCK`, `PARENT`, `ACTIVE`, `SORT`, `NAME`, `PHOTO`, `TEXT`, `PHOTO_`) VALUES
(1, '2012-11-27 14:51:49', '2012-12-18 13:58:22', 1, 1, 57, 0, 1, 10, 'Карусельное оборудование', '303', '<p>Высокоскоростная печатная машина &laquo;МНМ Synchroprint S-type 12-14&raquo; с площадью печати 50 на 60 см. (Австрия)</p>', '647'),
(2, '2012-11-27 14:52:12', '2012-12-18 13:50:51', 1, 1, 57, 0, 1, 20, 'Подготовка форм сеток', '304', '<p>Ручной карусельный станок для изготовления образцов и мелких тиражей 6-6 с площадью печати 35 на 40 см. (Россия)</p>', '646'),
(3, '2012-11-27 14:52:21', '2012-12-18 09:03:31', 1, 1, 57, 0, 1, 30, 'Вышивальные машины и лазеры', '305', '<p>Вышивальная машина &laquo;YONTHIN&raquo; 1-а головочная с площадью 360 на 480 мм</p>\r\n<p>Вышивальная машина на 6 голов по 12 нитей в каждой &laquo;YONTHN&raquo;</p>', '643'),
(4, '2012-11-27 14:52:31', '2012-12-18 13:44:42', 1, 1, 57, 0, 1, 40, 'Оборудование для сушки', '306', '<p>Туннельная сушка комбинированного типа &laquo;МНМ&raquo; (Австрия)</p>\r\n<p>Туннельная сушка &laquo;FUSION M&amp;R&raquo; c длинной камеры 183 см</p>', '644'),
(5, '2012-12-04 16:01:47', '2012-12-04 16:02:10', 1, 0, 57, 0, 0, 50, 'Швейное производство', '436', '<p>Швейное производство</p>', '437'),
(7, '2014-10-22 10:25:38', '2014-11-25 16:43:54', 1, 1, 57, 0, 0, 60, 'Широкоформатная УФ-печать', '822', '<div>НОВИНКА! Первый на Юге УФ-плоттер с размером запечатаемого поля 2,05х3,00м!&nbsp;</div>', '821');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block29`
--

DROP TABLE IF EXISTS `k2_block29`;
CREATE TABLE IF NOT EXISTS `k2_block29` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block29category`
--

DROP TABLE IF EXISTS `k2_block29category`;
CREATE TABLE IF NOT EXISTS `k2_block29category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block30`
--

DROP TABLE IF EXISTS `k2_block30`;
CREATE TABLE IF NOT EXISTS `k2_block30` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `PHOTO` varchar(255) NOT NULL,
  `LINK` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block30`
--

INSERT INTO `k2_block30` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `PHOTO`, `LINK`) VALUES
(39, '2014-10-06 14:55:32', '0000-00-00 00:00:00', 1, 0, 1, 340, 59, 0, '802', ''),
(2, '2012-11-27 12:06:01', '2012-12-10 13:07:06', 1, 1, 1, 20, 59, 0, '464', ''),
(36, '2014-10-03 09:50:13', '0000-00-00 00:00:00', 1, 0, 1, 320, 59, 0, '799', ''),
(35, '2014-10-03 09:50:08', '0000-00-00 00:00:00', 1, 0, 1, 310, 59, 0, '798', ''),
(38, '2014-10-03 09:50:44', '0000-00-00 00:00:00', 1, 0, 1, 330, 59, 0, '801', ''),
(33, '2014-10-03 09:49:43', '0000-00-00 00:00:00', 1, 0, 1, 290, 59, 0, '796', ''),
(32, '2014-10-03 09:49:37', '0000-00-00 00:00:00', 1, 0, 1, 280, 59, 0, '795', ''),
(12, '2012-12-10 13:02:20', '2012-12-10 13:08:16', 1, 1, 1, 80, 59, 0, '471', ''),
(13, '2012-12-10 13:02:24', '2012-12-10 13:08:22', 1, 1, 1, 90, 59, 0, '472', ''),
(31, '2014-10-03 09:39:00', '2014-10-03 09:49:31', 1, 1, 1, 270, 59, 0, '794', ''),
(15, '2012-12-10 13:02:38', '2012-12-10 13:08:38', 1, 1, 1, 110, 59, 0, '474', ''),
(16, '2012-12-10 13:02:43', '2012-12-10 13:08:57', 1, 1, 1, 120, 59, 0, '475', ''),
(17, '2012-12-10 13:02:48', '2012-12-10 13:09:03', 1, 1, 1, 130, 59, 0, '476', ''),
(18, '2012-12-10 13:02:52', '2012-12-10 13:09:10', 1, 1, 1, 140, 59, 0, '477', ''),
(19, '2012-12-10 13:02:57', '2012-12-10 13:09:14', 1, 1, 1, 150, 59, 0, '478', ''),
(20, '2012-12-10 13:03:03', '2012-12-10 13:09:19', 1, 1, 1, 160, 59, 0, '479', ''),
(21, '2012-12-10 13:03:06', '2012-12-10 13:09:25', 1, 1, 1, 170, 59, 0, '480', ''),
(22, '2012-12-10 13:03:12', '2012-12-10 13:09:36', 1, 1, 1, 180, 59, 0, '481', ''),
(23, '2012-12-10 13:03:17', '2012-12-10 13:09:41', 1, 1, 1, 190, 59, 0, '482', ''),
(24, '2012-12-10 13:03:21', '2012-12-10 13:09:47', 1, 1, 1, 200, 59, 0, '483', ''),
(25, '2012-12-10 13:09:53', '0000-00-00 00:00:00', 1, 0, 1, 210, 59, 0, '484', ''),
(26, '2013-05-30 12:53:53', '0000-00-00 00:00:00', 1, 0, 1, 220, 59, 0, '672', ''),
(27, '2013-05-30 12:53:57', '0000-00-00 00:00:00', 1, 0, 1, 230, 59, 0, '673', ''),
(28, '2013-05-30 12:54:01', '0000-00-00 00:00:00', 1, 0, 1, 240, 59, 0, '674', ''),
(29, '2013-05-30 12:54:07', '0000-00-00 00:00:00', 1, 0, 1, 250, 59, 0, '675', ''),
(30, '2013-05-30 12:54:12', '0000-00-00 00:00:00', 1, 0, 1, 260, 59, 0, '676', ''),
(40, '2014-10-06 14:55:38', '0000-00-00 00:00:00', 1, 0, 1, 350, 59, 0, '803', ''),
(41, '2014-10-06 14:55:43', '0000-00-00 00:00:00', 1, 0, 1, 360, 59, 0, '804', ''),
(42, '2014-10-06 14:55:47', '0000-00-00 00:00:00', 1, 0, 1, 370, 59, 0, '805', ''),
(43, '2014-10-06 14:55:54', '0000-00-00 00:00:00', 1, 0, 1, 380, 59, 0, '806', ''),
(44, '2014-10-06 14:56:00', '0000-00-00 00:00:00', 1, 0, 1, 390, 59, 0, '807', ''),
(45, '2014-10-06 14:56:05', '0000-00-00 00:00:00', 1, 0, 1, 400, 59, 0, '808', ''),
(46, '2014-10-06 14:56:10', '0000-00-00 00:00:00', 1, 0, 1, 410, 59, 0, '809', '');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block30category`
--

DROP TABLE IF EXISTS `k2_block30category`;
CREATE TABLE IF NOT EXISTS `k2_block30category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block31`
--

DROP TABLE IF EXISTS `k2_block31`;
CREATE TABLE IF NOT EXISTS `k2_block31` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `PHOTO` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block31`
--

INSERT INTO `k2_block31` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `PHOTO`) VALUES
(6, '2012-11-29 11:10:09', '0000-00-00 00:00:00', 1, 0, 1, 30, 61, 0, '386'),
(5, '2012-11-29 11:10:04', '0000-00-00 00:00:00', 1, 0, 1, 20, 61, 0, '385'),
(4, '2012-11-29 11:09:44', '0000-00-00 00:00:00', 1, 0, 1, 10, 61, 0, '384'),
(7, '2012-11-29 11:10:13', '0000-00-00 00:00:00', 1, 0, 1, 40, 61, 0, '387'),
(8, '2012-11-29 11:10:17', '0000-00-00 00:00:00', 1, 0, 1, 50, 61, 0, '388');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block31category`
--

DROP TABLE IF EXISTS `k2_block31category`;
CREATE TABLE IF NOT EXISTS `k2_block31category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block32`
--

DROP TABLE IF EXISTS `k2_block32`;
CREATE TABLE IF NOT EXISTS `k2_block32` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `PHOTO` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block32`
--

INSERT INTO `k2_block32` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `PHOTO`, `NAME`) VALUES
(1, '2012-11-27 12:40:15', '2012-12-17 13:40:22', 1, 1, 1, 10, 62, 0, ',346,347,348,349,350,351,352,353,399,400,401,402,403,547,548,549,550,551,552,553,554,555,556,', 'Трафаретная печать по текстилю'),
(2, '2012-11-27 12:40:43', '2014-10-22 06:08:52', 1, 1, 0, 20, 62, 0, ',354,355,356,357,358,359,557,558,559,560,561,562,563,564,565,566,567,568,569,570,571,', 'Трикотаж и изделия'),
(3, '2012-11-27 12:40:56', '2014-10-22 06:08:57', 1, 1, 0, 30, 62, 0, ',572,573,574,575,576,577,578,579,580,581,', 'Собственные марки ОПТ'),
(4, '2012-11-27 12:41:08', '2014-10-22 06:09:01', 1, 1, 0, 40, 62, 0, ',371,372,373,582,583,584,585,', 'Услуги вышивки'),
(7, '2012-12-17 14:10:47', '2014-10-22 06:09:06', 1, 1, 0, 50, 62, 0, ',588,589,590,591,', 'Дизайн'),
(8, '2012-12-17 14:13:02', '2014-10-22 06:09:09', 1, 1, 0, 60, 62, 0, ',592,593,594,595,596,597,598,599,600,601,602,', 'Эксперементальный цех'),
(9, '2012-12-17 14:19:07', '2014-11-14 16:50:00', 1, 1, 1, 70, 62, 0, ',680,681,682,683,684,685,686,687,688,689,690,691,692,693,694,695,696,697,847,848,849,850,851,852,853,854,855,856,857,858,859,', 'Наши работы - текстиль'),
(10, '2012-12-17 14:22:18', '2014-10-22 06:09:18', 1, 1, 0, 80, 62, 0, ',612,613,614,615,616,617,618,619,620,621,622,623,624,625,626,627,628,629,630,631,632,', 'Производственные возможности'),
(11, '2013-07-02 13:41:54', '2013-07-02 13:44:13', 1, 1, 1, 90, 62, 0, ',732,733,734,735,736,737,738,739,740,741,742,743,744,745,746,747,748,749,750,751,752,753,754,755,756,757,758,', 'Принты'),
(14, '2014-11-14 16:30:26', '2014-11-14 16:38:37', 1, 1, 1, 100, 62, 0, ',901,902,903,904,905,906,907,908,', 'Флаеры, буклеты, листовки'),
(15, '2014-11-14 16:44:29', '2014-11-14 16:47:15', 1, 1, 1, 110, 62, 0, ',911,912,913,914,915,916,917,918,920,921,922,', 'Открытки, приглашения, конверты'),
(16, '2014-11-14 16:52:49', '0000-00-00 00:00:00', 1, 0, 1, 120, 62, 0, ',923,924,925,926,927,928,929,930,931,932,933,', 'Пакеты бумажные'),
(17, '2014-11-14 16:56:11', '2014-11-17 09:36:16', 1, 1, 1, 130, 62, 0, ',934,935,936,937,943,944,945,946,947,948,949,', 'Рекламное производство');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block32category`
--

DROP TABLE IF EXISTS `k2_block32category`;
CREATE TABLE IF NOT EXISTS `k2_block32category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block33`
--

DROP TABLE IF EXISTS `k2_block33`;
CREATE TABLE IF NOT EXISTS `k2_block33` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `MATRIX` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block33`
--

INSERT INTO `k2_block33` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `NAME`, `MATRIX`) VALUES
(1, '2012-11-27 13:45:47', '2012-12-11 14:00:24', 1, 1, 1, 10, 64, 0, 'Общий тариф', 'a:2:{i:0;a:9:{i:50;a:10:{i:1;s:2:"36";i:2;s:4:"43,2";i:3;s:4:"57,6";i:4;s:4:"61,2";i:5;s:4:"68,4";i:6;s:2:"72";i:7;s:4:"75,6";i:8;s:4:"82,8";i:9;s:2:"90";i:10;s:4:"97,2";}i:100;a:10:{i:1;s:4:"28,8";i:2;s:2:"36";i:3;s:4:"41,4";i:4;s:2:"54";i:5;s:4:"57,6";i:6;s:4:"61,2";i:7;s:4:"64,8";i:8;s:4:"68,4";i:9;s:2:"72";i:10;s:4:"75,6";}i:200;a:10:{i:1;s:4:"17,3";i:2;s:4:"23,7";i:3;s:4:"30,2";i:4;s:4:"34,6";i:5;s:4:"43,9";i:6;s:4:"47,2";i:7;s:4:"50,4";i:8;s:4:"59,4";i:9;s:4:"64,8";i:10;s:2:"72";}i:300;a:10:{i:1;s:4:"15,9";i:2;s:4:"22,9";i:3;s:4:"28,8";i:4;s:4:"33,9";i:5;s:4:"43,2";i:6;s:4:"46,2";i:7;s:4:"48,2";i:8;s:4:"57,6";i:9;s:2:"63";i:10;s:4:"70,2";}i:500;a:10:{i:1;s:4:"13,9";i:2;s:4:"19,5";i:3;s:4:"25,4";i:4;s:4:"30,8";i:5;s:4:"34,7";i:6;s:4:"36,9";i:7;s:4:"41,9";i:8;s:4:"45,8";i:9;s:4:"54,5";i:10;s:5:"65,52";}i:700;a:10:{i:1;s:4:"13,2";i:2;s:4:"18,4";i:3;s:4:"22,4";i:4;s:4:"26,7";i:5;s:2:"31";i:6;s:2:"35";i:7;s:2:"39";i:8;s:4:"42,9";i:9;s:4:"48,4";i:10;s:2:"55";}i:1000;a:10:{i:1;s:3:"9,9";i:2;s:4:"14,4";i:3;s:4:"19,2";i:4;s:4:"22,8";i:5;s:4:"26,7";i:6;s:4:"29,1";i:7;s:4:"33,6";i:8;s:4:"38,4";i:9;s:4:"41,7";i:10;s:4:"46,2";}i:2000;a:10:{i:1;s:3:"9,3";i:2;s:4:"13,8";i:3;s:4:"16,5";i:4;s:4:"20,1";i:5;s:4:"25,5";i:6;s:4:"27,3";i:7;s:4:"32,7";i:8;s:4:"36,6";i:9;s:2:"39";i:10;s:4:"43,5";}i:5000;a:10:{i:1;s:3:"8,4";i:2;s:4:"11,1";i:3;s:4:"14,7";i:4;s:4:"17,1";i:5;s:4:"22,5";i:6;s:4:"25,8";i:7;s:4:"30,9";i:8;s:4:"33,9";i:9;s:4:"36,3";i:10;s:4:"41,4";}}i:1;a:9:{i:50;s:2:"40";i:100;s:2:"32";i:200;s:2:"25";i:300;s:2:"17";i:500;s:2:"15";i:700;s:2:"14";i:1000;s:2:"11";i:2000;s:2:"10";i:5000;s:1:"9";}}');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block33category`
--

DROP TABLE IF EXISTS `k2_block33category`;
CREATE TABLE IF NOT EXISTS `k2_block33category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block34`
--

DROP TABLE IF EXISTS `k2_block34`;
CREATE TABLE IF NOT EXISTS `k2_block34` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `COMPANY` varchar(255) NOT NULL,
  `PHONE` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `PAR` mediumtext NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block34`
--

INSERT INTO `k2_block34` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `NAME`, `COMPANY`, `PHONE`, `EMAIL`, `PAR`) VALUES
(10, '2013-04-29 09:39:05', '0000-00-00 00:00:00', 0, 0, 1, 0, 65, 0, 'Гетманская Людмила Анатольевна', 'ип Гетманский Алексей Николаевич', '89282960107', 'sirlanies@rambler.ru', 'тираж - 700, цветов - 4, формат - А4, эффект - 0, стоимость за ед. - 26.7 руб. стоимость тиража - 18690 руб.'),
(12, '2013-07-31 07:39:39', '0000-00-00 00:00:00', 0, 0, 1, 0, 65, 0, 'Иваненко Ольга Валентиновна', 'АКСИОМА', '89014962100', '2072100@mail.ru', 'тираж - 1000, цветов - 1, формат - Меньше А4, эффект - 0, стоимость за ед. - 8.42 руб. стоимость тиража - 8420 руб.');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block34category`
--

DROP TABLE IF EXISTS `k2_block34category`;
CREATE TABLE IF NOT EXISTS `k2_block34category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block35`
--

DROP TABLE IF EXISTS `k2_block35`;
CREATE TABLE IF NOT EXISTS `k2_block35` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `PHOTO` varchar(255) NOT NULL,
  `LINK` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block35`
--

INSERT INTO `k2_block35` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `PHOTO`, `LINK`) VALUES
(1, '2013-07-02 14:46:56', '2013-07-02 16:00:15', 1, 0, 0, 10, 79, 0, '761', '');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block35category`
--

DROP TABLE IF EXISTS `k2_block35category`;
CREATE TABLE IF NOT EXISTS `k2_block35category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block36`
--

DROP TABLE IF EXISTS `k2_block36`;
CREATE TABLE IF NOT EXISTS `k2_block36` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `PHOTO` varchar(255) NOT NULL,
  `LINK` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block36`
--

INSERT INTO `k2_block36` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `SORT`, `SECTION_BLOCK`, `CATEGORY`, `PHOTO`, `LINK`) VALUES
(1, '2013-07-02 14:44:42', '2013-07-16 12:15:55', 1, 1, 1, 10, 80, 0, '777', 'http://printtextil.ru/service/56/8/'),
(2, '2013-07-11 12:09:14', '2013-07-16 12:17:04', 1, 1, 1, 20, 80, 0, '778', 'http://printtextil.ru/service/56/8/'),
(3, '2013-07-11 12:09:19', '0000-00-00 00:00:00', 1, 0, 1, 30, 80, 0, '774', 'http://printtextil.ru/service/56/8/'),
(4, '2013-07-11 12:09:24', '0000-00-00 00:00:00', 1, 0, 1, 40, 80, 0, '775', 'http://printtextil.ru/service/56/8/');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block36category`
--

DROP TABLE IF EXISTS `k2_block36category`;
CREATE TABLE IF NOT EXISTS `k2_block36category` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `SECTION_BLOCK` int(11) NOT NULL,
  `PARENT` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_block_group`
--

DROP TABLE IF EXISTS `k2_block_group`;
CREATE TABLE IF NOT EXISTS `k2_block_group` (
`ID` smallint(6) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_block_group`
--

INSERT INTO `k2_block_group` (`ID`, `NAME`) VALUES
(4, 'Основное'),
(9, 'Главная');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_component`
--

DROP TABLE IF EXISTS `k2_component`;
CREATE TABLE IF NOT EXISTS `k2_component` (
`ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL DEFAULT '',
  `COMPONENT_GROUP` smallint(6) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `ICON` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_component_field`
--

DROP TABLE IF EXISTS `k2_component_field`;
CREATE TABLE IF NOT EXISTS `k2_component_field` (
  `COMPONENT` smallint(6) NOT NULL,
  `FIELD` int(11) NOT NULL,
  `COLLECTION` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_component_field`
--

INSERT INTO `k2_component_field` (`COMPONENT`, `FIELD`, `COLLECTION`) VALUES
(1, 28, 4),
(1, 106, 7),
(1, 106, 8),
(12, 28, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `k2_component_group`
--

DROP TABLE IF EXISTS `k2_component_group`;
CREATE TABLE IF NOT EXISTS `k2_component_group` (
`ID` smallint(6) NOT NULL,
  `NAME` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_design`
--

DROP TABLE IF EXISTS `k2_design`;
CREATE TABLE IF NOT EXISTS `k2_design` (
`ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_design`
--

INSERT INTO `k2_design` (`ID`, `NAME`) VALUES
(1, 'Главный макет'),
(6, 'Внутренний макет'),
(7, 'Портфолио');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_field`
--

DROP TABLE IF EXISTS `k2_field`;
CREATE TABLE IF NOT EXISTS `k2_field` (
`ID` int(11) NOT NULL,
  `TABLE` varchar(50) NOT NULL,
  `NAME` varchar(255) NOT NULL DEFAULT '',
  `FIELD` varchar(255) NOT NULL DEFAULT '',
  `SORT` int(11) NOT NULL DEFAULT '0',
  `TYPE` int(11) NOT NULL DEFAULT '0',
  `REQUIRED` tinyint(4) NOT NULL DEFAULT '0',
  `MULTIPLE` tinyint(1) NOT NULL DEFAULT '0',
  `SETTING` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=193 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_field`
--

INSERT INTO `k2_field` (`ID`, `TABLE`, `NAME`, `FIELD`, `SORT`, `TYPE`, `REQUIRED`, `MULTIPLE`, `SETTING`) VALUES
(4, 'k2_block1', 'Текст', 'TEXT', 10, 1, 1, 0, 'a:2:{s:4:"TYPE";s:1:"1";s:7:"WYSIWYG";s:1:"1";}'),
(69, 'k2_component25category', 'sadddddddddddddddddddddddddddddddddddddddd asdasssssssssssssssssssssssssssssssssssssssss asdasdas d asd as d as daaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasdasd', 'sss', 10, 0, 0, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(160, 'k2_block26', 'Тест', 'TEXT', 10, 1, 1, 0, 'a:1:{s:7:"WYSIWYG";s:1:"1";}'),
(161, 'k2_block27', 'Название', 'NAME', 10, 0, 1, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(162, 'k2_block27', 'Краткое описание', 'TEXT', 30, 1, 0, 0, 'a:1:{s:7:"WYSIWYG";s:1:"0";}'),
(163, 'k2_block27', 'Картинка', 'PHOTO', 20, 4, 1, 0, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";s:3:"FIX";s:1:"0";}}'),
(151, 'k2_block7', 'Хочу продать дом/земельный участок ', 'CH1', 50, 2, 0, 0, 'a:2:{s:7:"DEFAULT";s:1:"0";s:4:"VIEW";s:1:"0";}'),
(153, 'k2_block7', 'Нужна помощь в оформлении сделки ', 'CH3', 70, 2, 0, 0, 'a:2:{s:7:"DEFAULT";s:1:"0";s:4:"VIEW";s:1:"0";}'),
(154, 'k2_block7', 'Пока не знаю, чем вы мне поможете!', 'CH4', 80, 2, 0, 0, 'a:2:{s:7:"DEFAULT";s:1:"0";s:4:"VIEW";s:1:"0";}'),
(34, 'k2_block7', 'ФИО', 'NAME', 10, 0, 1, 0, 'N;'),
(35, 'k2_block7', 'Контактный телефон', 'PHONE', 20, 0, 0, 0, 'N;'),
(36, 'k2_block7', 'E-mail', 'EMAIL', 30, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"4";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(152, 'k2_block7', 'Хочу купить дом/земельный участок ', 'CH2', 60, 2, 0, 0, 'a:2:{s:7:"DEFAULT";s:1:"0";s:4:"VIEW";s:1:"0";}'),
(38, 'k2_site', 'Эл. почта', 'EMAIL', 40, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"4";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(164, 'k2_block27', 'Подробное описание', 'TEXT_FULL', 40, 1, 1, 0, 'a:1:{s:7:"WYSIWYG";s:1:"1";}'),
(165, 'k2_block27', 'CSS Класс', 'CLASS', 50, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(166, 'k2_block28category', 'Картинка', 'PHOTO', 10, 4, 1, 0, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";s:3:"FIX";s:1:"0";}}'),
(44, 'k2_block6', 'Название', 'NAME', 10, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(167, 'k2_block28', 'Название', 'NAME', 10, 0, 1, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(168, 'k2_block28', 'Картинка', 'PHOTO', 20, 4, 1, 0, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";s:3:"FIX";s:1:"0";}}'),
(136, 'k2_block6', 'Картинка цветная', 'PHOTO', 20, 4, 1, 0, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";s:3:"FIX";s:1:"0";}}'),
(110, 'k2_mod_shop_payer4', 'Название4', 'NAME', 10, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(111, 'k2_mod_shop_payer1', 'Имя, фамилия', 'NAME', 10, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(112, 'k2_mod_shop_payer1', 'Телефон', 'PHONE', 20, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(113, 'k2_mod_shop_payer1', 'E-mail', 'EMAIL', 30, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"4";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(114, 'k2_mod_shop_payer1', 'Адрес доставки (с индексом)', 'ADRESS', 40, 1, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:7:"WYSIWYG";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(115, 'k2_mod_shop_payer2', 'Наименование организации', 'NAME', 10, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(116, 'k2_mod_shop_payer2', 'Юридический адрес', 'UR_ADRES', 20, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(117, 'k2_mod_shop_payer2', 'Фактический адрес', 'FACT_ADRES', 30, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(118, 'k2_mod_shop_payer2', 'Наименование банка', 'BANK', 40, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(119, 'k2_mod_shop_payer2', 'БИК', 'BIK', 50, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(120, 'k2_mod_shop_payer2', 'Корреспондентский счет', 'KOR_SCHET', 60, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(121, 'k2_mod_shop_payer2', 'Расчетный счет', 'RAS_SCHET', 70, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(122, 'k2_mod_shop_payer2', 'ОКПО', 'OKPO', 80, 0, 0, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(123, 'k2_mod_shop_payer2', 'ИНН', 'INN', 90, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(124, 'k2_mod_shop_payer2', 'КПП', 'KPP', 100, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(125, 'k2_mod_shop_payer2', 'Ф.И.О. руководителя', 'FIO_RUK', 110, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(126, 'k2_mod_shop_payer2', 'Должность руководителя', 'DOLZ_RUK', 120, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(127, 'k2_mod_shop_payer2', 'Контактный телефон', 'PHONE', 130, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(128, 'k2_mod_shop_payer2', 'E-mail', 'EMAIL', 140, 0, 1, 0, 'a:3:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";s:7:"DEFAULT";s:0:"";}'),
(129, 'k2_mod_shop_payer4', 'ssdfsd55555555qwd', 'sdff', 20, 0, 1, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(158, 'k2_block6', 'CSS Класс', 'CLASS', 50, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(169, 'k2_block28', 'Описание', 'TEXT', 30, 1, 1, 0, 'a:1:{s:7:"WYSIWYG";s:1:"1";}'),
(159, 'k2_block6', 'Картинка блеклая', 'PHOTO_', 30, 4, 1, 0, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";s:3:"FIX";s:1:"0";}}'),
(157, 'k2_block6', 'Ссылка', 'LINK', 40, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(155, 'k2_site', 'Адрес', 'ADDRESS', 50, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(156, 'k2_site', 'Телефоны', 'PHONE', 60, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(172, 'k2_block28category', 'Краткое описание', 'TEXT', 20, 1, 0, 0, 'a:1:{s:7:"WYSIWYG";s:1:"1";}'),
(173, 'k2_block28category', 'Иконка на главной', 'PHOTO_', 30, 4, 1, 0, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";s:3:"FIX";s:1:"0";}}'),
(174, 'k2_block30', 'Картинка', 'PHOTO', 10, 4, 1, 0, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";s:3:"FIX";s:1:"0";}}'),
(175, 'k2_block30', 'Ссылка', 'LINK', 20, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(176, 'k2_block31', 'Картинка', 'PHOTO', 10, 4, 1, 0, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:3:"676";s:6:"HEIGHT";s:3:"400";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:3:"676";s:6:"HEIGHT";s:3:"400";s:3:"FIX";s:1:"1";}}'),
(177, 'k2_block32', 'Картинки', 'PHOTO', 20, 4, 1, 1, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:3:"448";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";s:3:"FIX";s:1:"0";}}'),
(178, 'k2_block32', 'Название', 'NAME', 10, 0, 1, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(179, 'k2_section', 'Альтернативный заголовок', 'H1', 10, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(180, 'k2_block33', 'Название', 'NAME', 10, 0, 1, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(181, 'k2_block33', 'Матрица', 'MATRIX', 20, 6, 0, 0, 'N;'),
(182, 'k2_block34', 'ФИО', 'NAME', 10, 0, 1, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(183, 'k2_block34', 'Компания', 'COMPANY', 20, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(184, 'k2_block34', 'Телефон', 'PHONE', 30, 0, 1, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(185, 'k2_block34', 'Email', 'EMAIL', 40, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"4";s:12:"DEFAULT_DATE";s:1:"0";}'),
(188, 'k2_block34', 'Параметры заказа', 'PAR', 50, 1, 0, 0, 'a:1:{s:7:"WYSIWYG";s:1:"0";}'),
(189, 'k2_block35', 'Картинка', 'PHOTO', 10, 4, 1, 0, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";s:3:"FIX";s:1:"0";}}'),
(190, 'k2_block35', 'Ссылка', 'LINK', 20, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}'),
(191, 'k2_block36', 'Картинка', 'PHOTO', 10, 4, 1, 0, 'a:6:{s:11:"TRANSLATION";s:1:"0";s:8:"FILESIZE";s:0:"";s:4:"TYPE";s:1:"1";s:8:"FILE_EXT";s:19:"jpg, jpeg, gif, png";s:3:"MIN";a:2:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";}s:6:"RESIZE";a:3:{s:5:"WIDTH";s:0:"";s:6:"HEIGHT";s:0:"";s:3:"FIX";s:1:"0";}}'),
(192, 'k2_block36', 'Ссылка', 'LINK', 20, 0, 0, 0, 'a:2:{s:4:"TYPE";s:1:"0";s:12:"DEFAULT_DATE";s:1:"0";}');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_field_separator`
--

DROP TABLE IF EXISTS `k2_field_separator`;
CREATE TABLE IF NOT EXISTS `k2_field_separator` (
`ID` smallint(6) NOT NULL,
  `TABLE` varchar(50) NOT NULL DEFAULT '0',
  `OBJECT` int(11) NOT NULL DEFAULT '0',
  `SORT` tinyint(4) NOT NULL DEFAULT '0',
  `NAME` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_field_separator`
--

INSERT INTO `k2_field_separator` (`ID`, `TABLE`, `OBJECT`, `SORT`, `NAME`) VALUES
(19, '', 0, 10, 'qwdqw');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_file`
--

DROP TABLE IF EXISTS `k2_file`;
CREATE TABLE IF NOT EXISTS `k2_file` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `USER` int(11) NOT NULL DEFAULT '0',
  `NAME` varchar(255) NOT NULL DEFAULT '',
  `PATH` varchar(255) NOT NULL DEFAULT '',
  `TYPE` varchar(50) NOT NULL DEFAULT '',
  `SIZE` varchar(20) NOT NULL DEFAULT '',
  `WIDTH` smallint(6) NOT NULL DEFAULT '0',
  `HEIGHT` smallint(6) NOT NULL DEFAULT '0',
  `DIR` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=951 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_file`
--

INSERT INTO `k2_file` (`ID`, `DATE_CREATED`, `USER`, `NAME`, `PATH`, `TYPE`, `SIZE`, `WIDTH`, `HEIGHT`, `DIR`) VALUES
(305, '2012-11-27 10:52:21', 1, '13.png', 'section/66/57/b3c7c5c821d8b22effbd21e0149e4b4f.png', 'image/png', '16642', 77, 101, 0),
(287, '2012-11-27 09:34:15', 1, 'service-print-products-gray.png', 'section/1/54/b9a5e72b416289435ff04e5e93de9241.png', 'image/png', '33711', 132, 134, 0),
(288, '2012-11-27 09:34:39', 1, 'service-print-tailor-color.png', 'section/1/54/033647f8c0fed29fdbc349a357a059c8.png', 'image/png', '28968', 131, 92, 0),
(289, '2012-11-27 09:34:39', 1, 'service-print-tailor-gray.png', 'section/1/54/2b79bb85dee8e3eb172fa283610afdbc.png', 'image/png', '30006', 131, 92, 0),
(290, '2012-11-27 09:35:05', 1, 'service-purl-color.png', 'section/1/54/18496b6d7135d513ea6d5b41ff43da78.png', 'image/png', '24641', 134, 144, 0),
(291, '2012-11-27 09:35:05', 1, 'service-purl-gray.png', 'section/1/54/fb37e90f6b17da969405fd9b6f078f2d.png', 'image/png', '24376', 134, 144, 0),
(659, '2013-03-11 12:21:45', 1, 'digital_color.png', 'section/1/54/aa5946407b7abfbfe02830ca4fa2afb8.png', 'image/png', '26490', 150, 134, 0),
(658, '2013-03-11 12:13:27', 1, 'digital.png', 'section/1/54/6c89546692b4d8938953c664b55fd9da.png', 'image/png', '25417', 150, 134, 0),
(294, '2012-11-27 09:36:00', 1, 'service-design-color.png', 'section/1/54/218db23f1f8eb075fb0581b35575452c.png', 'image/png', '19949', 206, 131, 0),
(295, '2012-11-27 09:36:00', 1, 'service-design-gray.png', 'section/1/54/764116bf05552984a61f6848f0565bd4.png', 'image/png', '19156', 206, 131, 0),
(296, '2012-11-27 10:19:52', 1, 'service-textile-color.png', 'section/65/56/e31aff33be28f76019274552aab4afed.png', 'image/png', '35693', 176, 114, 0),
(940, '2014-11-14 17:01:02', 1, 'эмблема.png', 'ophen/emblema(1).png', 'image/png', '437718', 600, 600, 26),
(302, '2012-11-27 10:30:31', 1, 'service-print-tailor-color.png', 'section/65/56/75f439daa83c76fac5351ea2eff88b1c.png', 'image/png', '28968', 131, 92, 0),
(299, '2012-11-27 10:24:29', 1, 'service-purl-color.png', 'section/65/56/87b67e19da2a3c8a918926160d7a3ec4.png', 'image/png', '24641', 134, 144, 0),
(391, '2012-11-30 08:10:18', 1, '01.jpg', 'section/66/57/590cf17f10dccd92c93a6029d87df633.jpg', 'image/jpeg', '19772', 215, 143, 0),
(301, '2012-11-27 10:25:17', 1, 'service-design-color.png', 'section/65/56/ebb83dd6f07f03aa652a0351b94e7897.png', 'image/png', '19949', 206, 131, 0),
(303, '2012-11-27 10:51:49', 1, '11.png', 'section/66/57/194b32e9888543a4dbe7e2cba0681c1b.png', 'image/png', '23572', 135, 65, 0),
(304, '2012-11-27 10:52:12', 1, '12.png', 'section/66/57/1539425a4280ce8429c457ce0d9bfda9.png', 'image/png', '8809', 42, 89, 0),
(284, '2012-11-27 09:33:22', 1, 'service-textile-color.png', 'section/1/54/b917be6515fec67e82a9eabe019244a7.png', 'image/png', '35693', 176, 114, 0),
(285, '2012-11-27 09:33:22', 1, 'service-textile-gray.png', 'section/1/54/8154078fa5e51271deefb50e16152db5.png', 'image/png', '37041', 176, 114, 0),
(286, '2012-11-27 09:34:15', 1, 'service-print-products-color.png', 'section/1/54/2d7c552a02a7ce097dc45e3ff28c9e17.png', 'image/png', '32747', 132, 134, 0),
(306, '2012-11-27 10:52:31', 1, '14.png', 'section/66/57/b22a1542c05a97da631e91e2ad16465c.png', 'image/png', '13143', 100, 72, 0),
(394, '2012-11-30 08:15:53', 1, '01.jpg', 'section/66/57/98ec43484b7efbab0fbf80a161ab7fb3.jpg', 'image/jpeg', '16998', 215, 161, 0),
(392, '2012-11-30 08:11:33', 1, '02.jpg', 'section/66/57/988df9f66a101ccc57eb89cc59e294a1.jpg', 'image/jpeg', '22304', 215, 143, 0),
(309, '2012-11-27 10:56:43', 1, '3.png', 'section/66/57/870f45872bd95e8eda8984f505c6d690.png', 'image/png', '20175', 99, 127, 0),
(421, '2012-12-03 04:49:55', 1, '02.jpg', 'section/66/57/29d9262df0f9360c67b7787ebf9bbbba.jpg', 'image/jpeg', '11699', 215, 143, 0),
(311, '2012-11-27 10:57:32', 1, '10.png', 'section/66/57/6d22cb5a5adb9c7ab5c84b5f3e2b9ce8.png', 'image/png', '24441', 156, 111, 0),
(646, '2012-12-18 09:50:51', 1, 'karusel.png', 'section/66/57/660a33edbadd7cce7cf1b8a8433a76e5.png', 'image/png', '34984', 189, 123, 0),
(643, '2012-12-18 05:03:10', 1, 'yonthin.png', 'section/66/57/b8659181de7ac92801873516fbd69656.png', 'image/png', '21726', 99, 127, 0),
(644, '2012-12-18 09:44:42', 1, '6d22cb5a5adb9c7ab5c84b5f3e2b9ce8.png', 'section/66/57/43cf9e32d23c50bebb1af851425a5a67.png', 'image/png', '24441', 156, 111, 0),
(386, '2012-11-29 11:10:10', 1, 'KOS_8741.jpg', 'section/67/61/ff2615406396d50a81f1ced9b31a8b81.jpg', 'image/jpeg', '27408', 676, 400, 0),
(385, '2012-11-29 11:10:05', 1, 'KOS_8737.jpg', 'section/67/61/b16661a0c70aed610cfe588afeeeb91c.jpg', 'image/jpeg', '38775', 676, 400, 0),
(384, '2012-11-29 11:09:44', 1, 'KOS_8719.jpg', 'section/67/61/c4577bd1680fe60bf515671ed84a0a6c.jpg', 'image/jpeg', '41372', 676, 400, 0),
(401, '2012-11-30 08:46:22', 1, 'IMG_2049.JPG', 'section/68/62/a08b66065c36dbfef640eca1952c0e53.JPG', 'image/jpeg', '61735', 299, 448, 0),
(402, '2012-11-30 08:46:22', 1, 'IMG_2050.JPG', 'section/68/62/5af041c98793f14eecbd1c28aa2b1990.JPG', 'image/jpeg', '75795', 299, 448, 0),
(403, '2012-11-30 08:46:22', 1, 'IMG_2051.JPG', 'section/68/62/c61b42fcaf01906e7a2419c0d972bc22.JPG', 'image/jpeg', '85708', 297, 448, 0),
(399, '2012-11-30 08:40:16', 1, 'IMG_2046.JPG', 'section/68/62/6e4c2f2a8283dac5d3805bb49f7dece5.JPG', 'image/jpeg', '63040', 299, 448, 0),
(355, '2012-11-28 09:11:43', 1, '3109033.jpg', 'section/68/62/baa7f261b62f358f0f11fe3d1a52a1f9.jpg', 'image/jpeg', '52990', 597, 448, 0),
(354, '2012-11-28 09:11:43', 1, '3100962_a.jpg', 'section/68/62/2a58c5eaf073509535bd02d01d457e98.jpg', 'image/jpeg', '53891', 597, 448, 0),
(581, '2012-12-17 14:03:45', 1, 'KOS_8897.jpg', 'section/68/62/1b8aa4086d574da1dc499dd0574b7c6a.jpg', 'image/jpeg', '207279', 1154, 768, 0),
(371, '2012-11-28 09:22:12', 1, 'muster4-xl.jpg', 'section/68/62/0696a002537ebbfc7fb26217d4125638.jpg', 'image/jpeg', '311607', 800, 600, 0),
(372, '2012-11-28 09:22:12', 1, 'clock_02-2_640x480.jpg', 'section/68/62/fa884d22776671091b8b1d57043af174.jpg', 'image/jpeg', '155204', 800, 600, 0),
(373, '2012-11-28 09:22:12', 1, '4291114_f520.jpg', 'section/68/62/6f7395e09ba0ccb26a64d617b2afc2fe.jpg', 'image/jpeg', '72067', 800, 600, 0),
(594, '2012-12-17 14:13:02', 1, 'KOS_8735.jpg', 'section/68/62/8e10d3dc159b1d69450d862932531ed4.jpg', 'image/jpeg', '185949', 1154, 768, 0),
(593, '2012-12-17 14:13:02', 1, 'KOS_8728.jpg', 'section/68/62/e94527c004d7ab120b35e6c24f2cc1b4.jpg', 'image/jpeg', '135194', 1154, 768, 0),
(592, '2012-12-17 14:13:02', 1, 'KOS_8719.jpg', 'section/68/62/3e6c8c40020ee6bf91af6a98f070ad62.jpg', 'image/jpeg', '139550', 1154, 768, 0),
(400, '2012-11-30 08:46:22', 1, 'IMG_2048.JPG', 'section/68/62/500ce8bf17c5cd2864bd804480979d7f.JPG', 'image/jpeg', '51615', 299, 448, 0),
(346, '2012-11-28 09:03:22', 1, 'IMG_2058.JPG', 'section/68/62/2bb9f4a206dd659e3090a937beee99cd.JPG', 'image/jpeg', '73584', 597, 448, 0),
(347, '2012-11-28 09:03:22', 1, 'IMG_2059.JPG', 'section/68/62/c669fbb15ab1ddd8921e9c8d0e57270f.JPG', 'image/jpeg', '71033', 597, 448, 0),
(348, '2012-11-28 09:03:22', 1, 'IMG_9845.jpg', 'section/68/62/17eed507d861d359a4f1f43485c255f6.jpg', 'image/jpeg', '78992', 597, 448, 0),
(349, '2012-11-28 09:03:22', 1, 'IMG_9849.jpg', 'section/68/62/62287c3293effc713d5ff0e70ac7417f.jpg', 'image/jpeg', '33143', 597, 448, 0),
(350, '2012-11-28 09:03:22', 1, 'IMG_9852.jpg', 'section/68/62/242c036dfcc0f9851bce32ce5404a2ab.jpg', 'image/jpeg', '46400', 597, 448, 0),
(351, '2012-11-28 09:03:22', 1, 'IMG_9863.jpg', 'section/68/62/9e088c90494241abcc0e47440e5bfab1.jpg', 'image/jpeg', '70634', 597, 448, 0),
(352, '2012-11-28 09:03:22', 1, 'IMG_9884.jpg', 'section/68/62/864bbae47c23d582eff0178dfce199cf.jpg', 'image/jpeg', '51986', 597, 448, 0),
(353, '2012-11-28 09:03:22', 1, 'IMG_9886.jpg', 'section/68/62/a85f7c04d03e584ca2e0834211859275.jpg', 'image/jpeg', '45502', 597, 448, 0),
(356, '2012-11-28 09:11:43', 1, '623-973-thickbox.jpg', 'section/68/62/e1a06557358e3eeae8cdd7727e700025.jpg', 'image/jpeg', '50559', 597, 448, 0),
(357, '2012-11-28 09:11:43', 1, '3177M471_1.jpg', 'section/68/62/932ac79cc76f18855d04aaf074cddcfd.jpg', 'image/jpeg', '49795', 597, 448, 0),
(358, '2012-11-28 09:11:43', 1, '31200_big.jpg', 'section/68/62/a517a7c58c5482bbb62f469eae2f5458.jpg', 'image/jpeg', '54915', 597, 448, 0),
(359, '2012-11-28 09:11:43', 1, '3100016_1.jpg', 'section/68/62/76379de6416371616d9fd9b3c670c8ad.jpg', 'image/jpeg', '49179', 597, 448, 0),
(580, '2012-12-17 14:03:45', 1, 'KOS_8895.jpg', 'section/68/62/ef356b04b95fe8ae92723bb2567599a6.jpg', 'image/jpeg', '205758', 1154, 768, 0),
(579, '2012-12-17 14:03:45', 1, 'KOS_8892.jpg', 'section/68/62/64ad23b15874e799c0c23007c5b68099.jpg', 'image/jpeg', '209800', 1154, 768, 0),
(578, '2012-12-17 14:03:45', 1, 'KOS_8884.jpg', 'section/68/62/e2f663266e3a929e6451c88c945b39cd.jpg', 'image/jpeg', '213518', 1154, 768, 0),
(577, '2012-12-17 14:03:45', 1, 'KOS_8883.jpg', 'section/68/62/00ae2978998e78fc4a617fbde8fb6ab8.jpg', 'image/jpeg', '223321', 1154, 768, 0),
(576, '2012-12-17 14:03:45', 1, 'KOS_5067.jpg', 'section/68/62/472ab08cc305c20a29eaf880472aa5c6.jpg', 'image/jpeg', '53336', 326, 768, 0),
(575, '2012-12-17 14:03:45', 1, 'KOS_5040.jpg', 'section/68/62/80a89a67969432d2c26f8a2bd2272e43.jpg', 'image/jpeg', '47213', 322, 768, 0),
(574, '2012-12-17 14:03:45', 1, 'KOS_5025.jpg', 'section/68/62/4c8c5c9ce0edcfb8132692416a582661.jpg', 'image/jpeg', '46424', 310, 768, 0),
(573, '2012-12-17 14:03:45', 1, 'KOS_5008.jpg', 'section/68/62/00c1547a7aad5c40a22de8933f0b6445.jpg', 'image/jpeg', '79993', 428, 768, 0),
(572, '2012-12-17 14:03:45', 1, 'IMG_9871.JPG', 'section/68/62/626ae1964658050793462f94eb28cd8c.JPG', 'image/jpeg', '104151', 1154, 768, 0),
(419, '2012-12-03 04:46:38', 1, '01.jpg', 'section/66/57/4ed57bd07f2858f9064fd8bb1ec0271a.jpg', 'image/jpeg', '8560', 215, 143, 0),
(416, '2012-12-02 19:31:56', 1, 'KOS_8929.jpg', 'ophen/KOS_8929.jpg', 'image/jpeg', '108225', 900, 599, 10),
(415, '2012-12-02 19:31:36', 1, 'KOS_8927.jpg', 'ophen/KOS_8927.jpg', 'image/jpeg', '107104', 900, 599, 10),
(414, '2012-12-02 19:23:56', 1, 'KOS_8874.jpg', 'ophen/KOS_8874.jpg', 'image/jpeg', '114329', 900, 599, 10),
(413, '2012-12-02 19:22:37', 1, 'KOS_8846.jpg', 'ophen/KOS_8846.jpg', 'image/jpeg', '75951', 900, 599, 10),
(412, '2012-12-02 18:20:48', 1, 'KOS_8825.jpg', 'ophen/KOS_8825.jpg', 'image/jpeg', '81781', 900, 599, 10),
(387, '2012-11-29 11:10:14', 1, 'KOS_8746.jpg', 'section/67/61/7fa3e123cffefe01ed7aece17eb27590.jpg', 'image/jpeg', '29084', 676, 400, 0),
(388, '2012-11-29 11:10:17', 1, 'KOS_8883.jpg', 'section/67/61/713b129e0650dc506b6689de507d658e.jpg', 'image/jpeg', '63697', 676, 400, 0),
(395, '2012-11-30 08:19:39', 1, '02.jpg', 'section/66/57/b12a78f1c93c162c92ff8b82c14a6c96.jpg', 'image/jpeg', '16904', 215, 143, 0),
(396, '2012-11-30 08:25:40', 1, '03.jpg', 'section/66/57/1e8165f2cde8a130463140ebed08d296.jpg', 'image/jpeg', '18777', 215, 143, 0),
(397, '2012-11-30 08:33:47', 1, '04.jpg', 'section/66/57/5d95807dae268d5fb294572dbd5064ac.jpg', 'image/jpeg', '8698', 215, 171, 0),
(398, '2012-11-30 08:35:17', 1, '05.jpg', 'section/66/57/c77d75e02fee96bf77a4df7abcc32da7.jpg', 'image/jpeg', '13855', 215, 143, 0),
(648, '2012-12-18 10:53:08', 1, 'press.jpg', 'section/66/57/1e634cbfa35c39646dad63228ab82f05.jpg', 'image/jpeg', '5753', 215, 143, 0),
(642, '2012-12-17 14:56:37', 1, '1788395(1).jpg', 'section/66/57/cc73377b3227e115d4078b4b615c3532.jpg', 'image/jpeg', '15325', 215, 143, 0),
(408, '2012-12-02 06:51:24', 1, 'KOS_8944.jpg', 'ophen/KOS_8944.jpg', 'image/jpeg', '73276', 900, 599, 9),
(409, '2012-12-02 06:55:17', 1, '01.jpg', 'ophen/01.jpg', 'image/jpeg', '71779', 600, 399, 9),
(410, '2012-12-02 06:56:33', 1, 'KOS_8931.jpg', 'ophen/KOS_8931.jpg', 'image/jpeg', '64524', 900, 599, 9),
(411, '2012-12-02 06:58:25', 1, 'KOS_8957.jpg', 'ophen/KOS_8957.jpg', 'image/jpeg', '86419', 900, 599, 9),
(417, '2012-12-03 04:44:31', 1, 'KOS_8816.jpg', 'ophen/KOS_8816.jpg', 'image/jpeg', '69444', 900, 599, 10),
(418, '2012-12-03 04:44:37', 1, 'KOS_8823.jpg', 'ophen/KOS_8823.jpg', 'image/jpeg', '61345', 900, 599, 10),
(420, '2012-12-03 04:49:23', 1, 'KOS_8838.jpg', 'ophen/KOS_8838.jpg', 'image/jpeg', '77594', 900, 599, 10),
(422, '2012-12-03 11:17:49', 1, 'KOS_8943.jpg', 'ophen/KOS_8943.jpg', 'image/jpeg', '80501', 900, 599, 11),
(423, '2012-12-03 11:20:14', 1, 'KOS_8940.jpg', 'ophen/KOS_8940.jpg', 'image/jpeg', '78536', 900, 599, 11),
(424, '2012-12-03 11:20:35', 1, 'KOS_8896.jpg', 'ophen/KOS_8896.jpg', 'image/jpeg', '102649', 900, 599, 11),
(425, '2012-12-03 11:26:33', 1, 'KOS_8883.jpg', 'ophen/KOS_8883.jpg', 'image/jpeg', '113857', 900, 599, 12),
(426, '2012-12-03 11:29:52', 1, 'KOS_8719.jpg', 'ophen/KOS_8719.jpg', 'image/jpeg', '72961', 900, 599, 13),
(427, '2012-12-03 11:29:55', 1, 'KOS_8737.jpg', 'ophen/KOS_8737.jpg', 'image/jpeg', '70097', 900, 599, 13),
(428, '2012-12-03 11:29:58', 1, 'KOS_8741.jpg', 'ophen/KOS_8741.jpg', 'image/jpeg', '49697', 900, 599, 13),
(429, '2012-12-03 11:30:00', 1, 'KOS_8746.jpg', 'ophen/KOS_8746.jpg', 'image/jpeg', '54118', 900, 599, 13),
(430, '2012-12-03 11:30:03', 1, 'KOS_8883.jpg', 'ophen/KOS_8883(1).jpg', 'image/jpeg', '113857', 900, 599, 13),
(432, '2012-12-03 11:35:56', 1, '02.jpg', 'ophen/02.jpg', 'image/jpeg', '274076', 900, 696, 14),
(433, '2012-12-03 11:35:58', 1, '03.jpg', 'ophen/03.jpg', 'image/jpeg', '271622', 900, 599, 14),
(434, '2012-12-03 11:36:00', 1, '04.jpg', 'ophen/04.jpg', 'image/jpeg', '232151', 900, 599, 14),
(435, '2012-12-03 11:36:03', 1, '05.jpg', 'ophen/05.jpg', 'image/jpeg', '244397', 900, 600, 14),
(436, '2012-12-04 12:01:47', 1, '01.jpg', 'section/66/57/e1802795feaaf06e53a7a46e23cbbb75.jpg', 'image/jpeg', '17089', 215, 143, 0),
(437, '2012-12-04 12:01:47', 1, '01.jpg', 'section/66/57/e1802795feaaf06e53a7a46e23cbbb75.jpg', 'image/jpeg', '17089', 215, 143, 0),
(799, '2014-10-03 09:50:13', 1, 'роснефть.jpg', 'section/1/59/d8292e56821c3d58ed5a9b9df7b0b553.jpg', 'image/jpeg', '20211', 160, 70, 0),
(464, '2012-12-10 13:07:06', 1, 'орандж.jpg', 'section/1/59/d34c33d4d49ea55647563334a2032792.jpg', 'image/jpeg', '5174', 160, 70, 0),
(798, '2014-10-03 09:50:08', 1, 'осака.jpg', 'section/1/59/ccff012f4f5f052b626e9f0efc33280f.jpg', 'image/jpeg', '3499', 160, 70, 0),
(796, '2014-10-03 09:49:43', 1, 'нс.jpg', 'section/1/59/ec911355dfeaa067391ea29c102912d2.jpg', 'image/jpeg', '20813', 160, 70, 0),
(471, '2012-12-10 13:08:16', 1, 'атдесигн.jpg', 'section/1/59/d27a3b5a255f39ab22d8f6eaa1f12986.jpg', 'image/jpeg', '5749', 160, 70, 0),
(472, '2012-12-10 13:08:22', 1, 'васаби.jpg', 'section/1/59/07a90950a091a8298126ac4724cb99bf.jpg', 'image/jpeg', '5208', 160, 70, 0),
(795, '2014-10-03 09:49:37', 1, 'кератон.jpg', 'section/1/59/713a6b744e5fd43a8d5b44942b5b4f88.jpg', 'image/jpeg', '26190', 160, 70, 0),
(474, '2012-12-10 13:08:38', 1, 'мираторг.jpg', 'section/1/59/fc1884fbb13e5b85e333a768ed82e9b6.jpg', 'image/jpeg', '4604', 160, 70, 0),
(475, '2012-12-10 13:08:57', 1, 'мхм.jpg', 'section/1/59/d9164a1f18c7dd39dfd3a98d2f77e778.jpg', 'image/jpeg', '5250', 160, 70, 0),
(476, '2012-12-10 13:09:03', 1, 'мьюзик-стар.jpg', 'section/1/59/ad1c3bffa9080336cf1bcd8573b71939.jpg', 'image/jpeg', '6577', 160, 70, 0),
(477, '2012-12-10 13:09:10', 1, 'окей.jpg', 'section/1/59/e3db21a5a47dc33353736e78dc93e061.jpg', 'image/jpeg', '7724', 160, 70, 0),
(478, '2012-12-10 13:09:14', 1, 'олджин.jpg', 'section/1/59/f11693b98efa53ca8a8103e04e0afb58.jpg', 'image/jpeg', '5543', 160, 70, 0),
(479, '2012-12-10 13:09:19', 1, 'осака.jpg', 'section/1/59/a01049e2adce2e7742b10f9afea1b5b0.jpg', 'image/jpeg', '4113', 160, 70, 0),
(480, '2012-12-10 13:09:25', 1, 'пинта.jpg', 'section/1/59/ef94067297edc0bb080b5f5ae30e45da.jpg', 'image/jpeg', '4131', 160, 70, 0),
(481, '2012-12-10 13:09:36', 1, 'русмедиа.jpg', 'section/1/59/5370f215029daa02ccf5872e36f1ce72.jpg', 'image/jpeg', '5423', 160, 70, 0),
(482, '2012-12-10 13:09:41', 1, 'седьмой-континент.jpg', 'section/1/59/143997862a4e1c395a91f2cf3b028477.jpg', 'image/jpeg', '5993', 160, 70, 0),
(483, '2012-12-10 13:09:47', 1, 'хобби-центр.jpg', 'section/1/59/3b224ff2ec585c90835cf28f99feeddd.jpg', 'image/jpeg', '4607', 160, 70, 0),
(794, '2014-10-03 09:49:31', 1, 'балтика.jpg', 'section/1/59/eb4aa63ff6b2067e42a22554bd7ecfad.jpg', 'image/jpeg', '5485', 140, 70, 0),
(484, '2012-12-10 13:09:53', 1, 'дигл-дизайн.jpg', 'section/1/59/ea4e51e2375bd9d62cb746b39d0ec36a.jpg', 'image/jpeg', '4376', 160, 70, 0),
(485, '2012-12-17 11:37:16', 1, 'KOS_8838.jpg', 'ophen/KOS_8838(1).jpg', 'image/jpeg', '143072', 1154, 768, 10),
(486, '2012-12-17 11:38:24', 1, 'KOS_8837.jpg', 'ophen/KOS_8837.jpg', 'image/jpeg', '142671', 1154, 768, 10),
(487, '2012-12-17 11:41:29', 1, '2a.jpg', 'ophen/2a.jpg', 'image/jpeg', '10227', 222, 148, 10),
(488, '2012-12-17 11:41:37', 1, 'Fusion_panel.jpg', 'ophen/Fusion_panel.jpg', 'image/jpeg', '58176', 400, 211, 10),
(489, '2012-12-17 11:44:27', 1, 'KOS_8817.jpg', 'ophen/KOS_8817.jpg', 'image/jpeg', '130401', 1154, 768, 10),
(490, '2012-12-17 11:44:33', 1, 'KOS_8819.jpg', 'ophen/KOS_8819.jpg', 'image/jpeg', '138096', 1154, 768, 10),
(491, '2012-12-17 11:44:46', 1, 'KOS_8821.jpg', 'ophen/KOS_8821.jpg', 'image/jpeg', '104490', 1154, 768, 10),
(493, '2012-12-17 11:50:28', 1, 'lasercut.jpg', 'section/66/57/e54f0c171fbc7e47efc8ba45dd0daa06.jpg', 'image/jpeg', '14491', 215, 143, 0),
(494, '2012-12-17 11:51:01', 1, 'yhlasercut.jpg', 'ophen/yhlasercut.jpg', 'image/jpeg', '99229', 755, 600, 10),
(497, '2012-12-17 12:03:27', 1, 'shkaf.jpg', 'section/66/57/67693cff71a3f739a5682b5f0449ab32.jpg', 'image/jpeg', '7834', 215, 143, 0),
(496, '2012-12-17 12:03:06', 1, '7-4-1-1b.jpg', 'ophen/7-4-1-1b.jpg', 'image/jpeg', '19950', 577, 472, 10),
(498, '2012-12-17 12:04:47', 1, 'primesetter_74.jpg', 'ophen/primesetter_74.jpg', 'image/jpeg', '9995', 300, 225, 10),
(499, '2012-12-17 12:06:09', 1, 'primes.JPG', 'ophen/primes.JPG', 'image/jpeg', '111713', 1024, 768, 10),
(500, '2012-12-17 12:09:09', 1, 'KOS_8760.jpg', 'ophen/KOS_8760.jpg', 'image/jpeg', '117861', 1154, 768, 10),
(501, '2012-12-17 12:10:23', 1, 'KOS_8766.jpg', 'ophen/KOS_8766.jpg', 'image/jpeg', '95892', 1154, 768, 10),
(502, '2012-12-17 12:16:17', 1, 'KOS_8749.jpg', 'ophen/KOS_8749.jpg', 'image/jpeg', '126052', 1154, 768, 10),
(503, '2012-12-17 12:16:22', 1, 'KOS_8752.jpg', 'ophen/KOS_8752.jpg', 'image/jpeg', '123275', 1154, 768, 10),
(504, '2012-12-17 12:16:26', 1, 'KOS_8756.jpg', 'ophen/KOS_8756.jpg', 'image/jpeg', '110467', 1154, 768, 10),
(505, '2012-12-17 12:16:32', 1, 'KOS_8833.jpg', 'ophen/KOS_8833.jpg', 'image/jpeg', '144779', 1154, 768, 10),
(506, '2012-12-17 12:18:37', 1, 'KOS_8795.jpg', 'ophen/KOS_8795.jpg', 'image/jpeg', '56291', 511, 768, 10),
(507, '2012-12-17 12:18:44', 1, 'KOS_8799.jpg', 'ophen/KOS_8799.jpg', 'image/jpeg', '92978', 1154, 768, 10),
(508, '2012-12-17 12:18:48', 1, 'KOS_8807.jpg', 'ophen/KOS_8807.jpg', 'image/jpeg', '61476', 511, 768, 10),
(509, '2012-12-17 12:28:12', 1, 'KOS_8773.jpg', 'ophen/KOS_8773.jpg', 'image/jpeg', '63419', 1154, 768, 10),
(510, '2012-12-17 12:28:16', 1, 'KOS_8775.jpg', 'ophen/KOS_8775.jpg', 'image/jpeg', '130693', 1154, 768, 10),
(511, '2012-12-17 12:28:21', 1, 'KOS_8776.jpg', 'ophen/KOS_8776.jpg', 'image/jpeg', '136755', 1154, 768, 10),
(512, '2012-12-17 12:28:26', 1, 'KOS_8786.jpg', 'ophen/KOS_8786.jpg', 'image/jpeg', '105037', 1154, 768, 10),
(513, '2012-12-17 12:28:31', 1, 'KOS_8787.jpg', 'ophen/KOS_8787.jpg', 'image/jpeg', '127968', 1154, 768, 10),
(514, '2012-12-17 12:37:11', 1, 'KOS_8843.jpg', 'ophen/KOS_8843.jpg', 'image/jpeg', '167291', 1154, 768, 10),
(515, '2012-12-17 12:37:20', 1, 'KOS_8859.jpg', 'ophen/KOS_8859.jpg', 'image/jpeg', '185905', 1154, 768, 10),
(516, '2012-12-17 12:37:29', 1, 'KOS_8866.jpg', 'ophen/KOS_8866.jpg', 'image/jpeg', '127707', 1154, 768, 10),
(517, '2012-12-17 12:37:38', 1, 'KOS_8911.jpg', 'ophen/KOS_8911.jpg', 'image/jpeg', '152682', 1154, 768, 10),
(518, '2012-12-17 12:37:45', 1, 'KOS_8917.jpg', 'ophen/KOS_8917.jpg', 'image/jpeg', '199758', 1154, 768, 10),
(519, '2012-12-17 12:40:28', 1, 'tex01.jpg', 'ophen/tex01.jpg', 'image/jpeg', '99957', 683, 768, 10),
(520, '2012-12-17 12:40:33', 1, 'tex02.jpg', 'ophen/tex02.jpg', 'image/jpeg', '35513', 360, 360, 10),
(521, '2012-12-17 12:44:04', 1, 'tex03.jpg', 'ophen/tex03.jpg', 'image/jpeg', '68123', 625, 768, 10),
(522, '2012-12-17 12:44:09', 1, 'tex04.jpg', 'ophen/tex04.jpg', 'image/jpeg', '80669', 683, 768, 10),
(523, '2012-12-17 12:44:15', 1, 'tex05.jpg', 'ophen/tex05.jpg', 'image/jpeg', '77994', 744, 768, 10),
(524, '2012-12-17 12:44:19', 1, 'tex06.jpg', 'ophen/tex06.jpg', 'image/jpeg', '102638', 732, 768, 10),
(525, '2012-12-17 12:44:23', 1, 'tex07.jpg', 'ophen/tex07.jpg', 'image/jpeg', '93125', 805, 747, 10),
(526, '2012-12-17 12:55:57', 1, 'kepka.jpg', 'ophen/kepka.jpg', 'image/jpeg', '54915', 597, 448, 11),
(527, '2012-12-17 12:56:02', 1, 'man.jpg', 'ophen/man.jpg', 'image/jpeg', '49179', 597, 448, 11),
(528, '2012-12-17 12:56:08', 1, 'polo.jpg', 'ophen/polo.jpg', 'image/jpeg', '52990', 597, 448, 11),
(529, '2012-12-17 12:56:14', 1, 'woman.jpg', 'ophen/woman.jpg', 'image/jpeg', '50559', 597, 448, 11),
(530, '2012-12-17 13:10:16', 1, 'IMG_9845.JPG', 'ophen/IMG_9845.JPG', 'image/jpeg', '177919', 1152, 768, 11),
(531, '2012-12-17 13:10:21', 1, 'IMG_9848.JPG', 'ophen/IMG_9848.JPG', 'image/jpeg', '92696', 1152, 768, 11),
(532, '2012-12-17 13:10:26', 1, 'IMG_9863.JPG', 'ophen/IMG_9863.JPG', 'image/jpeg', '135835', 1154, 768, 11),
(533, '2012-12-17 13:10:31', 1, 'IMG_9871.JPG', 'ophen/IMG_9871.JPG', 'image/jpeg', '104151', 1154, 768, 11),
(534, '2012-12-17 13:10:36', 1, 'IMG_9882.JPG', 'ophen/IMG_9882.JPG', 'image/jpeg', '149501', 1154, 768, 11),
(535, '2012-12-17 13:10:40', 1, 'KOS_5008.jpg', 'ophen/KOS_5008.jpg', 'image/jpeg', '79993', 428, 768, 11),
(536, '2012-12-17 13:10:45', 1, 'KOS_5025.jpg', 'ophen/KOS_5025.jpg', 'image/jpeg', '46424', 310, 768, 11),
(537, '2012-12-17 13:11:13', 1, 'KOS_5040.jpg', 'ophen/KOS_5040.jpg', 'image/jpeg', '47213', 322, 768, 11),
(538, '2012-12-17 13:11:17', 1, 'KOS_5067.jpg', 'ophen/KOS_5067.jpg', 'image/jpeg', '53336', 326, 768, 11),
(539, '2012-12-17 13:30:49', 1, 'KOS_8728.jpg', 'ophen/KOS_8728.jpg', 'image/jpeg', '135194', 1154, 768, 13),
(540, '2012-12-17 13:31:04', 1, 'KOS_8735.jpg', 'ophen/KOS_8735.jpg', 'image/jpeg', '185949', 1154, 768, 13),
(541, '2012-12-17 13:31:09', 1, 'KOS_8737.jpg', 'ophen/KOS_8737(1).jpg', 'image/jpeg', '146369', 1154, 768, 13),
(542, '2012-12-17 13:31:14', 1, 'KOS_8740.jpg', 'ophen/KOS_8740.jpg', 'image/jpeg', '100968', 1154, 768, 13),
(543, '2012-12-17 13:31:18', 1, 'KOS_8746.jpg', 'ophen/KOS_8746(1).jpg', 'image/jpeg', '109476', 1154, 768, 13),
(544, '2012-12-17 13:31:25', 1, 'KOS_8883.jpg', 'ophen/KOS_8883(2).jpg', 'image/jpeg', '223321', 1154, 768, 13),
(545, '2012-12-17 13:31:33', 1, 'KOS_8883.jpg', 'ophen/KOS_8883(3).jpg', 'image/jpeg', '223321', 1154, 768, 13),
(546, '2012-12-17 13:31:39', 1, 'KOS_8886.jpg', 'ophen/KOS_8886.jpg', 'image/jpeg', '222950', 1154, 768, 13),
(547, '2012-12-17 13:35:03', 1, '28108.jpg', 'section/68/62/9de85a0b32a5e4496f606dd1a157359d.jpg', 'image/jpeg', '27689', 550, 550, 0),
(548, '2012-12-17 13:35:22', 1, '27384183.jpg', 'section/68/62/5a29aadd0d58804ceb1a86b092551c59.jpg', 'image/jpeg', '61578', 700, 700, 0),
(549, '2012-12-17 13:35:22', 1, '1326294269_white_500.png', 'section/68/62/c1d3d0c63904bde873ac4fc6b03eed16.png', 'image/png', '113446', 500, 500, 0),
(550, '2012-12-17 13:35:22', 1, '1094642345350_futbolka_1.jpg', 'section/68/62/84807a84959a695acad038ad5a34e4b4.jpg', 'image/jpeg', '42091', 550, 531, 0),
(551, '2012-12-17 13:35:22', 1, '20111274491373.jpg', 'section/68/62/e51a5b55489bcc71f81916772bfcb954.jpg', 'image/jpeg', '32643', 480, 480, 0),
(552, '2012-12-17 13:40:22', 1, 'kurtka_mikos.png', 'section/68/62/2c4e27a4968f9bc2c80bc6f962619298.png', 'image/png', '71069', 200, 450, 0),
(553, '2012-12-17 13:40:22', 1, 'R66500-large1.jpg', 'section/68/62/ded0fd136b9407b863044b02dd75d5cc.jpg', 'image/jpeg', '22629', 450, 450, 0),
(554, '2012-12-17 13:40:22', 1, 'городской стиль 1.jpg', 'section/68/62/6274b8df02086036fb3ce6ab2ff0cd26.jpg', 'image/jpeg', '696634', 2778, 3125, 0),
(555, '2012-12-17 13:40:22', 1, 'городской стиль 3 - копия.jpg', 'section/68/62/a5c60607f56389b77741c3b55204c99d.jpg', 'image/jpeg', '820919', 2800, 3125, 0),
(556, '2012-12-17 13:40:22', 1, 'лето 1 - копия.jpg', 'section/68/62/81b3f1d64432e7fe53316624cec8c9c6.jpg', 'image/jpeg', '784287', 2778, 3125, 0),
(557, '2012-12-17 13:58:21', 1, '932_3175558.jpg', 'section/68/62/7bf31468a196a5697a586f0c1880bf45.jpg', 'image/jpeg', '80337', 600, 600, 0),
(558, '2012-12-17 13:58:21', 1, '1630.jpg', 'section/68/62/b449d89467c0362a7246d908a9acbf44.jpg', 'image/jpeg', '169729', 595, 693, 0),
(559, '2012-12-17 13:58:21', 1, '1832.20.jpg', 'section/68/62/795c43d939b6762f84c6d0b0bfaa74f0.jpg', 'image/jpeg', '15122', 500, 500, 0),
(560, '2012-12-17 13:58:21', 1, '012433_000025_744002sol_145.jpg', 'section/68/62/325e6da0c398c87f1ab481581a2791ab.jpg', 'image/jpeg', '12433', 500, 500, 0),
(561, '2012-12-17 13:58:21', 1, '657311417.jpg', 'section/68/62/7ecb2f5c226466411a4399d99e5eeaa9.jpg', 'image/jpeg', '13636', 500, 500, 0),
(562, '2012-12-17 13:58:21', 1, '1287768487.jpg', 'section/68/62/6dc6b530fab499d86fb89c3d3d9799b2.jpg', 'image/jpeg', '162829', 2048, 1365, 0),
(563, '2012-12-17 13:58:21', 1, '1303362165_948131.jpg', 'section/68/62/29ccee0713f679760ae706f53349cb63.jpg', 'image/jpeg', '17076', 500, 500, 0),
(564, '2012-12-17 13:58:21', 1, 'e5d601c66712b0ffc28d4480dddfac88.jpg', 'section/68/62/36a13848cf12f5aaa36d6a27526f730e.jpg', 'image/jpeg', '17982', 500, 500, 0),
(565, '2012-12-17 13:58:21', 1, 'kr3142825.jpg', 'section/68/62/6d77944d85d53d66f85f5c3c28e30a64.jpg', 'image/jpeg', '17287', 500, 500, 0),
(566, '2012-12-17 13:58:21', 1, 'name_10_1_8.jpg', 'section/68/62/60fe0da420f7d6c4cddd593962959382.jpg', 'image/jpeg', '25868', 500, 500, 0),
(567, '2012-12-17 13:58:21', 1, 'ST3000_WHI.jpg', 'section/68/62/5dad46815c93fa7932ee77faada21c52.jpg', 'image/jpeg', '205357', 800, 1200, 0),
(568, '2012-12-17 13:58:21', 1, 'sunflower.jpg', 'section/68/62/b13a1ebd07988b51954a94790023109c.jpg', 'image/jpeg', '79616', 600, 600, 0),
(569, '2012-12-17 13:58:21', 1, '137.jpg', 'section/68/62/c2690e6fa08bee8e0b3ed286e870bbe7.jpg', 'image/jpeg', '32914', 1251, 978, 0),
(570, '2012-12-17 13:58:21', 1, '394.jpg', 'section/68/62/d8feb9737613636f9f486e865633eb51.jpg', 'image/jpeg', '14491', 500, 500, 0),
(571, '2012-12-17 13:58:21', 1, '495_9910808.jpg', 'section/68/62/caca33c822d6cd016718417751f5554f.jpg', 'image/jpeg', '78286', 751, 751, 0),
(582, '2012-12-17 14:09:34', 1, '0_1614c_f2370be9_XL.jpg', 'section/68/62/0152e31d85e10e14e2a4f7fd36bc1d00.jpg', 'image/jpeg', '164348', 800, 758, 0),
(583, '2012-12-17 14:09:34', 1, '3.jpg', 'section/68/62/61448a433c0a95ac00b6a3da4cc57fbf.jpg', 'image/jpeg', '36709', 500, 500, 0),
(584, '2012-12-17 14:09:34', 1, '11.jpg', 'section/68/62/900b31359b468376458ded8edd0b66e5.jpg', 'image/jpeg', '155771', 1024, 768, 0),
(585, '2012-12-17 14:09:34', 1, '000458b.jpg', 'section/68/62/9cb6f6c1b0d98d25d2fedf429d420adf.jpg', 'image/jpeg', '13184', 500, 500, 0),
(666, '2013-04-09 17:08:01', 1, '2м.jpg', 'ophen/2m.jpg', 'image/jpeg', '96655', 768, 768, 11),
(664, '2013-04-09 17:05:07', 1, '2.jpg', 'ophen/2.jpg', 'image/jpeg', '48782', 768, 768, 11),
(665, '2013-04-09 17:07:14', 1, '1.jpg', 'ophen/1.jpg', 'image/jpeg', '70111', 768, 768, 11),
(588, '2012-12-17 14:10:47', 1, 'IMG_2069.JPG', 'section/68/62/31cc9a0a0fab7536eea86c62a155191d.JPG', 'image/jpeg', '170540', 1153, 768, 0),
(589, '2012-12-17 14:10:47', 1, 'IMG_2079.JPG', 'section/68/62/7b72aff796fab01bb5c33cf854291987.JPG', 'image/jpeg', '184227', 1152, 768, 0),
(590, '2012-12-17 14:10:47', 1, 'IMG_2080.JPG', 'section/68/62/0be650fd2d70ac69b29291d1295444ed.JPG', 'image/jpeg', '168116', 994, 768, 0),
(591, '2012-12-17 14:10:47', 1, 'IMG_2084.JPG', 'section/68/62/dc78ba5ff4ac34632f2dbc8c792eb02b.JPG', 'image/jpeg', '171418', 1152, 768, 0),
(595, '2012-12-17 14:13:02', 1, 'KOS_8737.jpg', 'section/68/62/681456047b3730ba49bf7be5e58f5acd.jpg', 'image/jpeg', '146369', 1154, 768, 0),
(596, '2012-12-17 14:13:02', 1, 'KOS_8740.jpg', 'section/68/62/425077e956df1b3eac5e9d1519e27925.jpg', 'image/jpeg', '100968', 1154, 768, 0),
(597, '2012-12-17 14:13:02', 1, 'KOS_8746.jpg', 'section/68/62/62baf5e7fa23ea01d4e26c5a5414a95f.jpg', 'image/jpeg', '109476', 1154, 768, 0),
(598, '2012-12-17 14:13:02', 1, 'KOS_8883.jpg', 'section/68/62/1d3a88c4a1c66d0ab5a0663eab8a5a88.jpg', 'image/jpeg', '223321', 1154, 768, 0),
(599, '2012-12-17 14:13:02', 1, 'KOS_8884.jpg', 'section/68/62/1b3b12871bde9a1525f02e810471c1b1.jpg', 'image/jpeg', '213518', 1154, 768, 0),
(600, '2012-12-17 14:13:02', 1, 'KOS_8892.jpg', 'section/68/62/03a557c5ebd2e5c0b9333ebd57ca8f3a.jpg', 'image/jpeg', '209800', 1154, 768, 0),
(601, '2012-12-17 14:13:02', 1, 'KOS_8895.jpg', 'section/68/62/1256f341d944664ac964cd1f0aa5985d.jpg', 'image/jpeg', '205758', 1154, 768, 0),
(602, '2012-12-17 14:13:02', 1, 'KOS_8897.jpg', 'section/68/62/9ca5d773730a578c0869cca72aeb67bf.jpg', 'image/jpeg', '207279', 1154, 768, 0),
(687, '2013-06-19 06:40:12', 1, 'Галактика.jpg', 'section/68/62/e6ae576b452e4db2ad68997d38066274.jpg', 'image/jpeg', '262791', 800, 600, 0),
(686, '2013-06-19 06:40:12', 1, 'Без имени-3 копия.jpg', 'section/68/62/45d86a955c350d7cf5cc5513926f7b37.jpg', 'image/jpeg', '218916', 800, 600, 0),
(685, '2013-06-19 06:40:12', 1, 'Атоман.jpg', 'section/68/62/4196324bdf59c1460c0f67f96c8251e7.jpg', 'image/jpeg', '243294', 800, 600, 0),
(684, '2013-06-19 06:40:12', 1, 'Автозвук.jpg', 'section/68/62/b6fdbfe1fc21191b3a28de7600461612.jpg', 'image/jpeg', '245994', 800, 600, 0),
(683, '2013-06-19 06:40:12', 1, 'аврора.jpg', 'section/68/62/96c7eddf27bae885e0a0e14077a75ea3.jpg', 'image/jpeg', '207268', 800, 600, 0),
(682, '2013-06-19 06:40:12', 1, 'АВАЛ.jpg', 'section/68/62/9a77d421feaf386772f59565abc84346.jpg', 'image/jpeg', '260443', 800, 600, 0),
(681, '2013-06-19 06:40:12', 1, '24.jpg', 'section/68/62/6dd12425fe0c1ee1c0a1cc5ea3ae0abf.jpg', 'image/jpeg', '202551', 800, 600, 0),
(680, '2013-06-19 06:40:12', 1, '3.jpg', 'section/68/62/06ca42c4fc2c62ff467cb0c8a2124ac8.jpg', 'image/jpeg', '206498', 800, 600, 0),
(612, '2012-12-17 14:22:18', 1, 'KOS_8662.jpg', 'section/68/62/4e5d0ab99feb10207225cc5b509bb6be.jpg', 'image/jpeg', '164085', 1154, 768, 0),
(613, '2012-12-17 14:22:18', 1, 'KOS_8668.jpg', 'section/68/62/924c32e57e530cd4ac28f9d128ec5e2c.jpg', 'image/jpeg', '148158', 1154, 768, 0),
(614, '2012-12-17 14:22:18', 1, 'KOS_8671.jpg', 'section/68/62/1be006ba22e8dd6cd70326bb817f5065.jpg', 'image/jpeg', '129953', 1154, 768, 0),
(615, '2012-12-17 14:22:18', 1, 'KOS_8684.jpg', 'section/68/62/6335f9d84d8a735307b4986f57acc88b.jpg', 'image/jpeg', '117191', 1154, 768, 0),
(616, '2012-12-17 14:22:18', 1, 'KOS_8685.jpg', 'section/68/62/d20d4d568ba69a114cd1bbf68b9522cb.jpg', 'image/jpeg', '117584', 1154, 768, 0),
(617, '2012-12-17 14:22:18', 1, 'KOS_8688.jpg', 'section/68/62/cdea35ce3206322a055ed18ab06c80c8.jpg', 'image/jpeg', '226895', 1154, 768, 0),
(618, '2012-12-17 14:22:18', 1, 'KOS_8691.jpg', 'section/68/62/dccdf4fc29b6b96c7dc7b6d80c321c9d.jpg', 'image/jpeg', '200078', 1154, 768, 0),
(619, '2012-12-17 14:22:18', 1, 'KOS_8694.jpg', 'section/68/62/a31e985acaef7548a50d2f30a143663a.jpg', 'image/jpeg', '143450', 1154, 768, 0),
(620, '2012-12-17 14:22:18', 1, 'KOS_8697.jpg', 'section/68/62/a34dcd677d0e9e86ace6d0e796c40281.jpg', 'image/jpeg', '224241', 1154, 768, 0),
(621, '2012-12-17 14:22:18', 1, 'KOS_8700.jpg', 'section/68/62/2ac5bc8f9ea059e1c4d7fbfb27ad834f.jpg', 'image/jpeg', '160163', 1154, 768, 0),
(622, '2012-12-17 14:22:18', 1, 'KOS_8709.jpg', 'section/68/62/1e7844755659b66e8be873cfbf5dba6b.jpg', 'image/jpeg', '181523', 1154, 768, 0),
(623, '2012-12-17 14:22:18', 1, 'KOS_8712.jpg', 'section/68/62/2356ed92a98f40ca1cbbf1a323a62096.jpg', 'image/jpeg', '184640', 1154, 768, 0),
(624, '2012-12-17 14:22:18', 1, 'KOS_8737.jpg', 'section/68/62/9cf0c282225d54609d6ac9a2f914b229.jpg', 'image/jpeg', '146369', 1154, 768, 0),
(625, '2012-12-17 14:22:18', 1, 'KOS_8746.jpg', 'section/68/62/73a96b36c810190df004397d45b2b150.jpg', 'image/jpeg', '109476', 1154, 768, 0),
(626, '2012-12-17 14:22:18', 1, 'KOS_8753.jpg', 'section/68/62/c52f303e5340cdf0cba198bc349b7263.jpg', 'image/jpeg', '128813', 1154, 768, 0),
(627, '2012-12-17 14:22:18', 1, 'KOS_8765.jpg', 'section/68/62/3016dabe5fb893535a89848e38c95f8f.jpg', 'image/jpeg', '98233', 1154, 768, 0),
(628, '2012-12-17 14:22:18', 1, 'KOS_8812.jpg', 'section/68/62/d582be903898b50ff66308d93f595673.jpg', 'image/jpeg', '168965', 1154, 768, 0),
(629, '2012-12-17 14:22:18', 1, 'KOS_8866.jpg', 'section/68/62/9b4712a9b90813a8311aa9add3f3ad45.jpg', 'image/jpeg', '127707', 1154, 768, 0),
(630, '2012-12-17 14:22:18', 1, 'KOS_8878.jpg', 'section/68/62/4f444b3f6c241b8c3c7bcd42d80a0b0e.jpg', 'image/jpeg', '223562', 1154, 768, 0),
(631, '2012-12-17 14:22:18', 1, 'KOS_8917.jpg', 'section/68/62/01e8441b4f6224bf8ffdf6ad2b83684d.jpg', 'image/jpeg', '199758', 1154, 768, 0),
(632, '2012-12-17 14:22:18', 1, 'KOS_8929.jpg', 'section/68/62/f13fd401c5769103c7e2f578e3cd8b54.jpg', 'image/jpeg', '235682', 1154, 768, 0),
(633, '2012-12-17 14:25:31', 1, 'atdq2-s.jpg', 'ophen/atdq2-s.jpg', 'image/jpeg', '68256', 600, 600, 15),
(634, '2012-12-17 14:25:40', 1, 'cerm5.jpg', 'ophen/cerm5.jpg', 'image/jpeg', '373516', 600, 600, 15),
(635, '2012-12-17 14:25:55', 1, 'gerbm3.jpg', 'ophen/gerbm3.jpg', 'image/jpeg', '90406', 310, 190, 15),
(636, '2012-12-17 14:25:58', 1, 'l04m.jpg', 'ophen/l04m.jpg', 'image/jpeg', '8233', 173, 130, 15),
(637, '2012-12-17 14:26:01', 1, 'l05.jpg', 'ophen/l05.jpg', 'image/jpeg', '63308', 800, 600, 15),
(638, '2012-12-17 14:50:35', 1, '1788395.jpg', 'ophen/1788395.jpg', 'image/jpeg', '71155', 400, 400, 10),
(649, '2012-12-18 10:54:27', 1, 'yonthin.png', 'section/66/57/48bdbcafe56d61f03357ab7c77467ba1.png', 'image/png', '21726', 99, 127, 0),
(640, '2012-12-17 14:56:10', 1, '1788866.jpg', 'ophen/1788866.jpg', 'image/jpeg', '63220', 360, 360, 10),
(647, '2012-12-18 09:58:22', 1, 'mhm.png', 'section/66/57/0d1d0efe39fba96eeb3e7363ce9e2feb.png', 'image/png', '29697', 189, 123, 0),
(650, '2012-12-24 13:40:57', 1, 'sitemap.xml', 'ophen/sitemap.xml', '', '1922', 0, 0, 1),
(652, '2013-03-11 12:08:02', 1, 'digital_color.png', 'section/65/56/f38eb73caf2de297d586610e17ea1112.png', 'image/png', '25966', 132, 134, 0),
(660, '2013-03-11 12:32:29', 1, 'P1000127.JPG', 'ophen/P1000127.JPG', 'image/jpeg', '158638', 1000, 750, 16),
(661, '2013-03-11 12:32:31', 1, 'P1000129.JPG', 'ophen/P1000129.JPG', 'image/jpeg', '117576', 1000, 750, 16),
(662, '2013-03-11 12:32:33', 1, 'P1000132.JPG', 'ophen/P1000132.JPG', 'image/jpeg', '141225', 750, 1000, 16),
(667, '2013-04-09 17:08:59', 1, '2ж.jpg', 'ophen/2zh.jpg', 'image/jpeg', '62044', 607, 768, 11),
(668, '2013-04-09 17:12:02', 1, 'c17aa929b086710757edb78d49f591b6.png', 'section/65/56/00a770c5b413e362530436ede521e6ef.png', 'image/png', '32747', 132, 134, 0),
(669, '2013-04-09 17:37:34', 1, 'colors.png', 'ophen/colors.png', 'image/png', '5454', 668, 110, 11),
(670, '2013-04-09 17:39:54', 1, 'sale08.04.13.xls', 'ophen/sale08.04.13.xls', '', '377856', 0, 0, 11),
(671, '2013-04-09 17:41:21', 1, 'Прайс на пошив трикотажных изделий.xls', 'ophen/Praysnaposhivtrikotazhnyhizdeliy.xls', '', '28160', 0, 0, 11),
(672, '2013-05-30 12:53:53', 1, 'business.png', 'section/1/59/ea94e71a35e055fa166bb2730d6762ad.png', 'image/png', '3407', 160, 70, 0),
(673, '2013-05-30 12:53:57', 1, 'detmir.png', 'section/1/59/4779b8d49795bea3ee22f6a9086342dd.png', 'image/png', '3353', 160, 70, 0),
(674, '2013-05-30 12:54:01', 1, 'magna.png', 'section/1/59/bae98a6b3693a9de2e4d3971521b319a.png', 'image/png', '3147', 160, 70, 0),
(675, '2013-05-30 12:54:07', 1, 'orbita.png', 'section/1/59/13b3fe16db659aca0676f5e0f4956a5f.png', 'image/png', '3870', 160, 70, 0),
(676, '2013-05-30 12:54:12', 1, 'white.png', 'section/1/59/8579b26d22e701a4974bc5748e48532a.png', 'image/png', '3840', 160, 70, 0),
(677, '2013-06-13 10:28:27', 1, 'pplenka.png', 'section/65/56/932531a1a104f1a4270d2b9558ef9528.png', 'image/png', '9633', 132, 134, 0),
(679, '2013-06-13 10:39:17', 1, 'truck.png', 'section/65/56/0518eef5ed5ad812763714cd913da63b.png', 'image/png', '13561', 132, 134, 0),
(688, '2013-06-19 06:40:12', 1, 'ДА(1).jpg', 'section/68/62/e90e8534ad2bf61f415d29ebb338e6b9.jpg', 'image/jpeg', '225738', 800, 600, 0),
(689, '2013-06-19 06:40:12', 1, 'ДА.jpg', 'section/68/62/4c4a5215db8e986583f054fc777186dc.jpg', 'image/jpeg', '225384', 800, 600, 0),
(690, '2013-06-19 06:40:12', 1, 'Казань.jpg', 'section/68/62/cbc6e491af035699ec1e86a9890d5ea1.jpg', 'image/jpeg', '224627', 800, 600, 0),
(691, '2013-06-19 06:40:12', 1, 'ок.jpg', 'section/68/62/a01153ed57c14493b82fd6ea31bd8f13.jpg', 'image/jpeg', '318338', 800, 600, 0),
(692, '2013-06-19 06:40:12', 1, 'Парк рока.jpg', 'section/68/62/812a0476a1ac142c6d3af205424d9ebf.jpg', 'image/jpeg', '254311', 800, 600, 0),
(693, '2013-06-19 06:40:12', 1, 'Ранхигс.jpg', 'section/68/62/4b84ba5eb6d201a17b59488565d32300.jpg', 'image/jpeg', '234086', 800, 600, 0),
(694, '2013-06-19 06:40:12', 1, 'такси.jpg', 'section/68/62/b7bf58d3fd3ca697c3e00e9f8b2c9003.jpg', 'image/jpeg', '227025', 800, 600, 0),
(695, '2013-06-19 06:40:12', 1, 'ШУ-ШУ.jpg', 'section/68/62/6dab5891518e58047600193675a9c996.jpg', 'image/jpeg', '226726', 800, 600, 0),
(696, '2013-06-19 06:40:12', 1, 'экомаг.jpg', 'section/68/62/593413c46ed9ba87071474285f2efebe.jpg', 'image/jpeg', '212857', 800, 600, 0),
(697, '2013-06-20 06:01:03', 1, 'оллин.jpg', 'section/68/62/44aa6bb45f9690b4a09463fe9a65adf8.jpg', 'image/jpeg', '210315', 800, 600, 0),
(700, '2013-07-01 08:01:36', 1, 'белая.jpg', 'ophen/belaya.jpg', 'image/jpeg', '237373', 531, 798, 18),
(701, '2013-07-01 08:01:44', 1, 'жёлтая.jpg', 'ophen/zheltaya.jpg', 'image/jpeg', '262992', 531, 798, 18),
(702, '2013-07-01 08:01:52', 1, 'зел.jpg', 'ophen/zel.jpg', 'image/jpeg', '298619', 531, 798, 18),
(703, '2013-07-01 08:01:59', 1, 'Крассная.jpg', 'ophen/Krassnaya.jpg', 'image/jpeg', '266307', 531, 798, 18),
(704, '2013-07-01 08:02:05', 1, 'серая.jpg', 'ophen/seraya.jpg', 'image/jpeg', '256475', 531, 798, 18),
(705, '2013-07-01 08:02:11', 1, 'синяя.jpg', 'ophen/sinyaya.jpg', 'image/jpeg', '257725', 531, 798, 18),
(706, '2013-07-01 08:02:17', 1, 'чёрн.jpg', 'ophen/chern.jpg', 'image/jpeg', '250123', 531, 798, 18),
(707, '2013-07-01 08:42:02', 1, 'белая.jpg', 'ophen/belaya(1).jpg', 'image/jpeg', '119531', 531, 798, 19),
(708, '2013-07-01 08:42:06', 1, 'красная.jpg', 'ophen/krasnaya.jpg', 'image/jpeg', '137653', 531, 856, 19),
(709, '2013-07-01 08:42:14', 1, 'синяя.jpg', 'ophen/sinyaya(1).jpg', 'image/jpeg', '126256', 531, 799, 19),
(710, '2013-07-01 08:42:18', 1, 'черная.jpg', 'ophen/chernaya.jpg', 'image/jpeg', '119393', 531, 799, 19),
(711, '2013-07-01 09:02:09', 1, 'Чёрный.jpg', 'ophen/Chernyy.jpg', 'image/jpeg', '106693', 531, 798, 20),
(712, '2013-07-01 09:02:15', 1, 'Б.jpg', 'ophen/B.jpg', 'image/jpeg', '116014', 531, 798, 20),
(713, '2013-07-01 09:02:22', 1, 'к.jpg', 'ophen/k.jpg', 'image/jpeg', '120744', 531, 798, 20),
(714, '2013-07-01 09:21:54', 1, 'красная.jpg', 'ophen/krasnaya(1).jpg', 'image/jpeg', '130315', 531, 799, 21),
(715, '2013-07-01 09:21:58', 1, 'белая.jpg', 'ophen/belaya(2).jpg', 'image/jpeg', '132381', 531, 798, 21),
(716, '2013-07-01 09:22:04', 1, 'черная.jpg', 'ophen/chernaya(1).jpg', 'image/jpeg', '124412', 531, 798, 21),
(717, '2013-07-01 10:33:16', 1, 'ж.jpg', 'ophen/zh.jpg', 'image/jpeg', '251523', 531, 798, 22),
(718, '2013-07-01 10:33:22', 1, 'к.jpg', 'ophen/k(1).jpg', 'image/jpeg', '258806', 531, 798, 22),
(719, '2013-07-01 10:33:27', 1, 'о.jpg', 'ophen/o.jpg', 'image/jpeg', '110754', 531, 798, 22),
(720, '2013-07-01 10:33:33', 1, 'ор.jpg', 'ophen/or.jpg', 'image/jpeg', '247821', 531, 798, 22),
(721, '2013-07-01 10:33:40', 1, 'син.jpg', 'ophen/sin.jpg', 'image/jpeg', '251540', 531, 798, 22),
(722, '2013-07-01 10:33:44', 1, 'чёрная.jpg', 'ophen/chernaya(2).jpg', 'image/jpeg', '109433', 531, 798, 22),
(723, '2013-07-01 11:16:36', 1, 'белая.jpg', 'ophen/belaya(3).jpg', 'image/jpeg', '129308', 531, 798, 23),
(724, '2013-07-01 11:16:41', 1, 'серый.jpg', 'ophen/seryy.jpg', 'image/jpeg', '106755', 531, 798, 23),
(725, '2013-07-01 11:16:45', 1, 'черная.jpg', 'ophen/chernaya(3).jpg', 'image/jpeg', '110484', 531, 798, 23),
(726, '2013-07-01 11:39:31', 1, '23.jpg', 'ophen/23.jpg', 'image/jpeg', '258360', 531, 798, 24),
(727, '2013-07-01 11:39:40', 1, 'гол.jpg', 'ophen/gol.jpg', 'image/jpeg', '249776', 531, 798, 24),
(728, '2013-07-01 11:39:47', 1, 'Жёлтая.jpg', 'ophen/Zheltaya.jpg', 'image/jpeg', '260433', 531, 798, 24),
(729, '2013-07-01 11:40:39', 1, 'зелёная.jpg', 'ophen/zelenaya.jpg', 'image/jpeg', '231854', 531, 798, 24),
(730, '2013-07-01 11:40:45', 1, 'оранж.jpg', 'ophen/oranzh.jpg', 'image/jpeg', '264437', 531, 798, 24),
(731, '2013-07-01 11:40:51', 1, 'роз.jpg', 'ophen/roz.jpg', 'image/jpeg', '262608', 531, 798, 24),
(732, '2013-07-02 13:41:54', 1, 'KOS_7752 копия.jpg', 'section/68/62/69e2c7a0476fa7113fa59fca6dc94193.jpg', 'image/jpeg', '83228', 531, 798, 0),
(733, '2013-07-02 13:42:17', 1, 'KOS_7759 копия.jpg', 'section/68/62/82733d8f5114604ee918d444990dc0c8.jpg', 'image/jpeg', '101176', 531, 798, 0),
(734, '2013-07-02 13:42:17', 1, 'KOS_7764 копия.jpg', 'section/68/62/3988e595a53a8816750427eaec361286.jpg', 'image/jpeg', '89903', 531, 798, 0),
(735, '2013-07-02 13:42:17', 1, 'KOS_7770 копия.jpg', 'section/68/62/2a35621b2e7ae9d4d27059e230b119dc.jpg', 'image/jpeg', '100142', 531, 798, 0),
(736, '2013-07-02 13:42:17', 1, 'KOS_7778 копия.jpg', 'section/68/62/82ddfe28c412ea3da0e4a8f5f4cbf3bc.jpg', 'image/jpeg', '91437', 531, 798, 0),
(737, '2013-07-02 13:42:17', 1, 'KOS_7792 копия.jpg', 'section/68/62/bead6937fba5faa0242ef5cfc7b977ab.jpg', 'image/jpeg', '98093', 531, 798, 0),
(738, '2013-07-02 13:42:17', 1, 'KOS_7794 копия.jpg', 'section/68/62/76b7be2a168cc8867fe1a168108a64be.jpg', 'image/jpeg', '77844', 531, 798, 0),
(739, '2013-07-02 13:42:17', 1, 'KOS_7807 копия.jpg', 'section/68/62/d5ed5caaeb82c18d0abbc7e9bfbe335f.jpg', 'image/jpeg', '88385', 531, 798, 0),
(740, '2013-07-02 13:42:17', 1, 'KOS_7814 копия.jpg', 'section/68/62/c5dfa55d9f222028c0f56acff7459407.jpg', 'image/jpeg', '101470', 531, 798, 0),
(741, '2013-07-02 13:43:39', 1, 'KOS_7848 копия.jpg', 'section/68/62/070ee13a6d50c7c86552c341311b6469.jpg', 'image/jpeg', '99962', 531, 798, 0),
(742, '2013-07-02 13:43:39', 1, 'KOS_7869 копия.jpg', 'section/68/62/edcf4c941100c076e68f4269fd6d642c.jpg', 'image/jpeg', '104526', 531, 798, 0),
(743, '2013-07-02 13:43:39', 1, 'KOS_7874 копия.jpg', 'section/68/62/e38b7254970a1115f9d85316f526644a.jpg', 'image/jpeg', '98405', 531, 798, 0),
(744, '2013-07-02 13:43:39', 1, 'KOS_7879 копия.jpg', 'section/68/62/2dd741c6c5f2a68378e1d8a6102bb79e.jpg', 'image/jpeg', '106031', 531, 798, 0),
(745, '2013-07-02 13:43:39', 1, 'KOS_7887 копия.jpg', 'section/68/62/afb158570b233229679b54d3132ee001.jpg', 'image/jpeg', '90463', 531, 798, 0),
(746, '2013-07-02 13:43:39', 1, 'KOS_7893 копия.jpg', 'section/68/62/33fd1f593be75d4757a53111ab3df3ee.jpg', 'image/jpeg', '97413', 531, 798, 0),
(747, '2013-07-02 13:43:39', 1, 'KOS_7899 копия.jpg', 'section/68/62/7ea1266f29cb7d1730be24dc86852fdd.jpg', 'image/jpeg', '95555', 531, 798, 0),
(748, '2013-07-02 13:43:39', 1, 'KOS_7902 копия.jpg', 'section/68/62/b58c296a58d65efe65da1027f87b3ff9.jpg', 'image/jpeg', '91514', 531, 798, 0),
(749, '2013-07-02 13:44:13', 1, 'KOS_8433 копия.jpg', 'section/68/62/2bcca272a2eb9926c9db9618ace977e9.jpg', 'image/jpeg', '82802', 531, 798, 0),
(750, '2013-07-02 13:44:13', 1, 'KOS_8439 копия.jpg', 'section/68/62/3f4634311a8b947dfab96c5c82d7b706.jpg', 'image/jpeg', '89783', 531, 798, 0),
(751, '2013-07-02 13:44:13', 1, 'KOS_8444 копия.jpg', 'section/68/62/b24db0c227f51808b5fa0d8c07084f8c.jpg', 'image/jpeg', '89791', 531, 798, 0),
(752, '2013-07-02 13:44:13', 1, 'KOS_8446 копия.jpg', 'section/68/62/5b07161e6ddab6c87935297a2e3c1906.jpg', 'image/jpeg', '100973', 531, 798, 0),
(753, '2013-07-02 13:44:13', 1, 'KOS_8464 копия.jpg', 'section/68/62/420223d08c61bb93dd213fd0a61fc038.jpg', 'image/jpeg', '71354', 531, 798, 0),
(754, '2013-07-02 13:44:13', 1, 'KOS_8534 копия.jpg', 'section/68/62/bc6b30dcb78465cb34602bb942861490.jpg', 'image/jpeg', '88085', 531, 798, 0),
(755, '2013-07-02 13:44:13', 1, 'KOS_8415 копия.jpg', 'section/68/62/0e87fbd11cba33300d6ca993a53df30b.jpg', 'image/jpeg', '92726', 531, 798, 0),
(756, '2013-07-02 13:44:13', 1, 'KOS_8420 копия.jpg', 'section/68/62/af068daf7432d47b709db86e161403d1.jpg', 'image/jpeg', '86589', 531, 798, 0),
(757, '2013-07-02 13:44:13', 1, 'KOS_8421 копия.jpg', 'section/68/62/afedeb6b1269314a54b2bad5a9d8b7e7.jpg', 'image/jpeg', '97393', 531, 798, 0),
(758, '2013-07-02 13:44:13', 1, 'KOS_8430 копия.jpg', 'section/68/62/20e616e1fc6a744612bdd242f685abde.jpg', 'image/jpeg', '99211', 531, 798, 0),
(777, '2013-07-16 12:15:55', 1, 'banner_printtextil_1-01.jpg', 'section/1/80/0359fbdd8b8caaaec2fafc1c741e9381.jpg', 'image/jpeg', '63178', 960, 320, 0),
(761, '2013-07-02 14:46:56', 1, 'ашан.jpg', 'section/1/79/35237e1d7a50918e95f70436592f9f54.jpg', 'image/jpeg', '7473', 160, 70, 0),
(762, '2013-07-09 04:15:22', 1, '12.jpg', 'ophen/12.jpg', 'image/jpeg', '78389', 531, 799, 17),
(763, '2013-07-09 04:16:06', 1, 'KOS_7643 копия.jpg', 'ophen/KOS_7643kopiya.jpg', 'image/jpeg', '81223', 531, 798, 17),
(764, '2013-07-09 04:18:40', 1, 'KOS_7653 копия.jpg', 'ophen/KOS_7653kopiya.jpg', 'image/jpeg', '109029', 531, 798, 17),
(765, '2013-07-09 04:18:44', 1, 'KOS_7685 копия.jpg', 'ophen/KOS_7685kopiya.jpg', 'image/jpeg', '94618', 531, 798, 17),
(766, '2013-07-09 04:20:55', 1, 'тельняшка.jpg', 'ophen/telnyashka.jpg', 'image/jpeg', '125936', 531, 798, 17),
(767, '2013-07-09 04:24:01', 1, 'KOS_8396 копия.jpg', 'ophen/KOS_8396kopiya.jpg', 'image/jpeg', '91779', 531, 798, 25),
(768, '2013-07-09 04:24:05', 1, 'KOS_8404 копия.jpg', 'ophen/KOS_8404kopiya.jpg', 'image/jpeg', '113981', 531, 798, 25),
(769, '2013-07-09 04:24:10', 1, 'KOS_8420 копия.jpg', 'ophen/KOS_8420kopiya.jpg', 'image/jpeg', '86589', 531, 798, 25),
(770, '2013-07-09 04:24:13', 1, 'KOS_8433 копия.jpg', 'ophen/KOS_8433kopiya.jpg', 'image/jpeg', '82802', 531, 798, 25),
(771, '2013-07-09 04:24:17', 1, 'KOS_8446 копия.jpg', 'ophen/KOS_8446kopiya.jpg', 'image/jpeg', '100973', 531, 798, 25),
(778, '2013-07-16 12:17:04', 1, 'banner_printtextil_2-01.jpg', 'section/1/80/87d0e19b0556affa3a8c1c7d15417725.jpg', 'image/jpeg', '59409', 960, 320, 0),
(774, '2013-07-11 12:09:19', 1, 'banner_printtextil_3-01.jpg', 'section/1/80/f41597fe66cb14b9fdbd408a45fba718.jpg', 'image/jpeg', '85760', 960, 320, 0),
(775, '2013-07-11 12:09:24', 1, 'banner_printtextil_4-01.jpg', 'section/1/80/622d8e05aa34c638b26e10afa3c19a51.jpg', 'image/jpeg', '112879', 960, 320, 0),
(779, '2013-07-16 13:33:11', 1, 'white.gif', 'ophen/white.gif', 'image/gif', '1125', 16, 16, 1),
(780, '2013-07-16 13:33:16', 1, 'black.gif', 'ophen/black.gif', 'image/gif', '1125', 16, 16, 1),
(781, '2013-07-16 13:33:18', 1, 'blue.gif', 'ophen/blue.gif', 'image/gif', '1125', 16, 16, 1),
(782, '2013-07-16 13:33:21', 1, 'green.gif', 'ophen/green.gif', 'image/gif', '1125', 16, 16, 1),
(783, '2013-07-16 13:33:24', 1, 'grey.gif', 'ophen/grey.gif', 'image/gif', '1125', 16, 16, 1),
(784, '2013-07-16 13:33:27', 1, 'red.gif', 'ophen/red.gif', 'image/gif', '1125', 16, 16, 1),
(785, '2013-07-16 13:33:34', 1, 'yellow.gif', 'ophen/yellow.gif', 'image/gif', '1125', 16, 16, 1),
(786, '2013-07-16 13:35:48', 1, 'violet.gif', 'ophen/violet.gif', 'image/gif', '1125', 16, 16, 1),
(787, '2013-07-16 13:35:51', 1, 'orange.gif', 'ophen/orange.gif', 'image/gif', '1125', 16, 16, 1),
(788, '2013-07-16 13:39:59', 1, 'fistash.gif', 'ophen/fistash.gif', 'image/gif', '1125', 16, 16, 1),
(790, '2013-07-16 13:44:20', 1, 'camufla.gif', 'ophen/camufla.gif', 'image/gif', '1398', 16, 16, 1),
(791, '2013-07-16 13:45:19', 1, 'teln.gif', 'ophen/teln.gif', 'image/gif', '1646', 16, 16, 1),
(792, '2013-07-16 13:52:08', 1, 'malina.gif', 'ophen/malina.gif', 'image/gif', '1125', 16, 16, 1),
(801, '2014-10-03 09:50:44', 1, 'шу-шу.jpg', 'section/1/59/860d87302a62b975aab2f035bda86496.jpg', 'image/jpeg', '23841', 160, 70, 0),
(802, '2014-10-06 14:55:32', 1, '220в.jpg', 'section/1/59/8a41eac55782c601138c544e28e729d0.jpg', 'image/jpeg', '28682', 160, 70, 0),
(803, '2014-10-06 14:55:38', 1, 'мвд.jpg', 'section/1/59/09199410cb4891272841d711b437ff00.jpg', 'image/jpeg', '34602', 160, 70, 0),
(804, '2014-10-06 14:55:43', 1, 'прокуратура.jpg', 'section/1/59/fa6c867998330661a68d027c31ae770e.jpg', 'image/jpeg', '33188', 160, 70, 0),
(805, '2014-10-06 14:55:47', 1, 'публик.jpg', 'section/1/59/8253cc4a2484df9550738e3c653ff3c7.jpg', 'image/jpeg', '30406', 160, 70, 0),
(806, '2014-10-06 14:55:54', 1, 'ранхигс.jpg', 'section/1/59/e881eb57f832ec3116d2c8921991ce6e.jpg', 'image/jpeg', '41963', 160, 70, 0),
(807, '2014-10-06 14:56:00', 1, 'техногрейд.jpg', 'section/1/59/c84f0dfcf67e079d2178a70e2dddf97c.jpg', 'image/jpeg', '32816', 160, 70, 0),
(808, '2014-10-06 14:56:05', 1, 'уно.jpg', 'section/1/59/d802662a64b6d902345b416dec0bb51e.jpg', 'image/jpeg', '31632', 160, 70, 0),
(809, '2014-10-06 14:56:10', 1, 'хк.jpg', 'section/1/59/c3fb68770b1b07504a0243d654f5f67e.jpg', 'image/jpeg', '32525', 160, 70, 0),
(810, '2014-10-15 04:14:50', 1, '932531a1a104f1a4270d2b9558ef9528.png', 'section/65/56/93871ca4dcbc678700a5795f10a8de98.png', 'image/png', '9633', 132, 134, 0),
(811, '2014-10-15 04:21:35', 1, 'n_Xerox_700_Digital_Color_Press.jpg', 'ophen/n_Xerox_700_Digital_Color_Press.jpg', 'image/jpeg', '90069', 1366, 607, 16),
(812, '2014-10-21 13:34:19', 1, 'unnamed.jpg', 'ophen/unnamed.jpg', 'image/jpeg', '119945', 781, 391, 1),
(813, '2014-10-21 14:00:06', 1, 'Календарь1 (Small).png', 'ophen/Kalendar1(Small).png', 'image/png', '309422', 480, 480, 1),
(814, '2014-10-21 14:00:09', 1, 'Календарь2 (Small).png', 'ophen/Kalendar2(Small).png', 'image/png', '337192', 480, 480, 1),
(851, '2014-10-22 10:34:00', 1, '5.png', 'section/68/62/bf19a0d97cfcc3dc84cc43269ff2f62b.png', 'image/png', '634233', 772, 768, 0);
INSERT INTO `k2_file` (`ID`, `DATE_CREATED`, `USER`, `NAME`, `PATH`, `TYPE`, `SIZE`, `WIDTH`, `HEIGHT`, `DIR`) VALUES
(850, '2014-10-22 10:34:00', 1, '4.png', 'section/68/62/aac26b35d217718f94801c96ef4e8d8d.png', 'image/png', '499336', 1304, 768, 0),
(849, '2014-10-22 10:34:00', 1, '3.png', 'section/68/62/310a81d23558e6e117f69c63b4684168.png', 'image/png', '1073419', 1297, 768, 0),
(848, '2014-10-22 10:34:00', 1, '2.png', 'section/68/62/57a7a598276c82b4aac77ad263fc5cf1.png', 'image/png', '608110', 774, 768, 0),
(847, '2014-10-22 10:34:00', 1, '1.png', 'section/68/62/b12df99e782d1b4b72f6de5509f7eabf.png', 'image/png', '929092', 1306, 768, 0),
(822, '2014-10-22 06:26:14', 1, 'uf.png', 'section/66/57/89b8c0cb361c5d7df9742b460a1c3803.png', 'image/png', '22195', 156, 111, 0),
(821, '2014-10-22 06:25:38', 1, 'uf.png', 'section/66/57/905feb3c0bb16414124279640c537dfd.png', 'image/png', '22195', 156, 111, 0),
(823, '2014-10-22 06:29:37', 1, 'uf2.jpg', 'section/66/57/1be1474e64585b26be52edfe4c24360f.jpg', 'image/jpeg', '8035', 215, 143, 0),
(825, '2014-10-22 06:42:42', 1, 'reklama (1).JPG', 'ophen/reklama(1).JPG', 'image/jpeg', '123711', 731, 480, 26),
(826, '2014-10-22 06:42:44', 1, 'reklama (2).JPG', 'ophen/reklama(2).JPG', 'image/jpeg', '128658', 722, 480, 26),
(827, '2014-10-22 06:42:47', 1, 'reklama (3).JPG', 'ophen/reklama(3).JPG', 'image/jpeg', '110349', 730, 480, 26),
(828, '2014-10-22 06:42:50', 1, 'reklama (4).JPG', 'ophen/reklama(4).JPG', 'image/jpeg', '149483', 720, 480, 26),
(829, '2014-10-22 06:42:53', 1, 'reklama (5).JPG', 'ophen/reklama(5).JPG', 'image/jpeg', '127462', 723, 480, 26),
(941, '2014-11-14 17:03:16', 1, 'лев.png', 'ophen/lev.png', 'image/png', '418582', 600, 600, 26),
(937, '2014-11-14 16:56:11', 1, 'IMG_6381 - копия.JPG', 'section/68/62/48966b8dd00dc3c6e4da8fd7a4c43bf8.JPG', 'image/jpeg', '20311968', 5616, 3737, 0),
(938, '2014-11-14 16:57:53', 1, 'Без имени-1.png', 'ophen/Bezimeni-1.png', 'image/png', '777117', 886, 800, 26),
(939, '2014-11-14 16:59:05', 1, 'эмблема.png', 'ophen/emblema.png', 'image/png', '14452607', 4000, 4000, 26),
(936, '2014-11-14 16:56:11', 1, 'IMG_6364 - копия - копия (2).JPG', 'section/68/62/5b034192ee99ce37fb1a52b5196f99a9.JPG', 'image/jpeg', '13400237', 4414, 2898, 0),
(935, '2014-11-14 16:56:11', 1, 'IMG_6390.JPG', 'section/68/62/e6e0c03c1771d4372a0b4f57449f8da2.JPG', 'image/jpeg', '20014989', 5616, 3744, 0),
(934, '2014-11-14 16:56:11', 1, 'IMG_6388 - копия.JPG', 'section/68/62/56bb9eafac77e3a452b41808358a1ba7.JPG', 'image/jpeg', '17575669', 5464, 3592, 0),
(852, '2014-10-22 10:34:00', 1, '6.png', 'section/68/62/aff6252d2fd9626974b82c31abc87173.png', 'image/png', '1079155', 1309, 768, 0),
(853, '2014-10-22 10:34:00', 1, '7.png', 'section/68/62/870fd5812168f54973685084229df33c.png', 'image/png', '630456', 770, 768, 0),
(854, '2014-10-22 10:34:00', 1, '8.png', 'section/68/62/802bcef16991546c056cc0e15c2f7fbd.png', 'image/png', '847587', 783, 768, 0),
(855, '2014-10-22 10:34:00', 1, '9.png', 'section/68/62/884d2393d952c277b842b25b6c7daa2c.png', 'image/png', '819427', 786, 768, 0),
(856, '2014-10-22 10:34:00', 1, '11.png', 'section/68/62/d4e96be9ffa817c79d55ec75bd101b2f.png', 'image/png', '874707', 1313, 768, 0),
(857, '2014-10-22 10:34:00', 1, '13.png', 'section/68/62/341e5e25a5dce281cc39fcd46fdb208b.png', 'image/png', '602534', 784, 768, 0),
(858, '2014-10-22 10:34:00', 1, '14.png', 'section/68/62/c159daa72322ab4124cb596380b5ad33.png', 'image/png', '823815', 1312, 768, 0),
(859, '2014-10-22 10:34:00', 1, '15.png', 'section/68/62/7389dd8982031679061e3253953c2dd8.png', 'image/png', '854641', 1332, 768, 0),
(864, '2014-11-05 08:48:58', 1, 'print.png', 'section/1/54/f365133c00b0db2b6c9c9a696a4a0a6f.png', 'image/png', '9764', 150, 134, 0),
(865, '2014-11-05 08:48:58', 1, 'print.png', 'section/1/54/f365133c00b0db2b6c9c9a696a4a0a6f.png', 'image/png', '9764', 150, 134, 0),
(866, '2014-11-07 08:59:46', 1, '1-03 - копия.png', 'ophen/1-03-kopiya.png', 'image/png', '210660', 421, 645, 26),
(867, '2014-11-07 10:30:53', 1, 'блокнот-01.png', 'ophen/bloknot-01.png', 'image/png', '236005', 438, 528, 26),
(868, '2014-11-07 10:44:09', 1, '1-01.png', 'ophen/1-01.png', 'image/png', '178430', 420, 596, 26),
(869, '2014-11-07 10:54:23', 1, '2.jpg', 'ophen/2(1).jpg', 'image/jpeg', '49483', 654, 228, 26),
(870, '2014-11-07 10:54:38', 1, '1.jpg', 'ophen/1(1).jpg', 'image/jpeg', '47193', 656, 189, 26),
(871, '2014-11-07 11:31:01', 1, 'победа-18-01.png', 'ophen/pobeda-18-01.png', 'image/png', '241594', 567, 567, 26),
(872, '2014-11-07 12:57:46', 1, 'победа-18.png1-01 - копия.png', 'ophen/pobeda-18.png1-01-kopiya.png', 'image/png', '214444', 567, 567, 26),
(873, '2014-11-07 13:04:29', 1, 'подготовка на сайт-05.png', 'ophen/podgotovkanasayt-05.png', 'image/png', '315122', 531, 543, 26),
(874, '2014-11-07 13:12:37', 1, 'подготовка на сайт-01 - копия.png', 'ophen/podgotovkanasayt-01-kopiya.png', 'image/png', '218741', 531, 543, 26),
(875, '2014-11-08 07:48:43', 1, '2-02 - копия.png', 'ophen/2-02-kopiya.png', 'image/png', '129703', 420, 597, 26),
(876, '2014-11-08 07:58:33', 1, 'симпл принт-02 - копия.png', 'ophen/simplprint-02-kopiya.png', 'image/png', '226312', 567, 568, 26),
(877, '2014-11-08 08:06:46', 1, '2-02.png', 'ophen/2-02.png', 'image/png', '131573', 420, 597, 26),
(878, '2014-11-08 08:15:45', 1, 'симпл принт-04 - копия.png', 'ophen/simplprint-04-kopiya.png', 'image/png', '210208', 567, 568, 26),
(879, '2014-11-08 08:16:59', 1, 'симпл принт-03 - копия.png', 'ophen/simplprint-03-kopiya.png', 'image/png', '244905', 567, 568, 26),
(880, '2014-11-08 08:22:29', 1, 'симпл принт-05 - копия.png', 'ophen/simplprint-05-kopiya.png', 'image/png', '184859', 567, 568, 26),
(881, '2014-11-08 08:33:41', 1, '1-06 - копия.png', 'ophen/1-06-kopiya.png', 'image/png', '147730', 568, 425, 26),
(882, '2014-11-08 08:40:32', 1, '1-05 - копия.png', 'ophen/1-05-kopiya.png', 'image/png', '191699', 568, 425, 26),
(883, '2014-11-08 08:57:59', 1, '1-08 - копия.png', 'ophen/1-08-kopiya.png', 'image/png', '156240', 568, 425, 26),
(884, '2014-11-08 09:04:09', 1, '1-07 - копия.png', 'ophen/1-07-kopiya.png', 'image/png', '135451', 568, 425, 26),
(885, '2014-11-08 09:09:30', 1, 'победа-04.png', 'ophen/pobeda-04.png', 'image/png', '310821', 597, 420, 26),
(889, '2014-11-08 09:39:16', 1, 'Без имени-1.jpg', 'ophen/Bezimeni-1.jpg', 'image/jpeg', '226302', 985, 586, 26),
(888, '2014-11-08 09:34:06', 1, 'Anapurna_M2050_rigid_(jpg).jpg', 'ophen/Anapurna_M2050_rigid_(jpg).jpg', 'image/jpeg', '112792', 1024, 503, 26),
(890, '2014-11-12 15:59:19', 1, 'на сайт3.jpg', 'ophen/nasayt3.jpg', 'image/png', '15581', 709, 429, 26),
(891, '2014-11-12 16:06:55', 1, 'Без имени-1.jpg', 'ophen/Bezimeni-1(1).jpg', 'image/jpeg', '153802', 855, 523, 26),
(892, '2014-11-12 16:07:41', 1, 'Без имени-1.jpg', 'ophen/Bezimeni-1(2).jpg', 'image/jpeg', '147552', 726, 442, 26),
(906, '2014-11-14 16:38:37', 1, '22.png', 'section/68/62/d0c5c00c453ebdbd874d8b772cf390d1.png', 'image/png', '773500', 783, 781, 0),
(905, '2014-11-14 16:38:37', 1, '7.png', 'section/68/62/5f8f6417ac47e9b162ca052bc5e6dafa.png', 'image/png', '7066370', 3000, 1783, 0),
(904, '2014-11-14 16:38:37', 1, '17.png', 'section/68/62/7bbada4cf6d2b2b2631a7075ba7f9979.png', 'image/png', '11747625', 3000, 3000, 0),
(901, '2014-11-14 16:35:19', 1, 'Без имени-1.jpg', 'section/68/62/a6abb9aeccb93fc93337ff76794c343f.jpg', 'image/jpeg', '310200', 780, 656, 0),
(902, '2014-11-14 16:38:37', 1, '15.png', 'section/68/62/325db0942b74cbd4c5a5c3797c74f844.png', 'image/png', '4854730', 3000, 3000, 0),
(903, '2014-11-14 16:38:37', 1, '16.png', 'section/68/62/bb277664d2f13a0abf3a25d2497dff12.png', 'image/png', '10479934', 3000, 3000, 0),
(907, '2014-11-14 16:38:37', 1, 'лемар.png', 'section/68/62/87d67f5d2c67e732162ad7c4aeb3ff6e.png', 'image/png', '34284442', 6221, 3265, 0),
(908, '2014-11-14 16:38:37', 1, 'нескучный сад2.png', 'section/68/62/7c64ce6dc2bde54ad639abe01ee28907.png', 'image/png', '17641142', 4327, 4350, 0),
(921, '2014-11-14 16:47:15', 1, 'ростовнефтепродукт2.png', 'section/68/62/72b3f0483b6b48b7e574769b58969f45.png', 'image/png', '23877237', 4160, 3959, 0),
(920, '2014-11-14 16:47:15', 1, 'ростовнефтепродукт3.png', 'section/68/62/5bb0a9ee495bb99a8c1a1ccc185ad198.png', 'image/png', '29338935', 4142, 6127, 0),
(911, '2014-11-14 16:44:29', 1, 'Гуэс.png', 'section/68/62/fdb90cd87f03a9912f4f2d7d20caa3c7.png', 'image/png', '18346033', 2781, 2982, 0),
(912, '2014-11-14 16:44:29', 1, 'ростовнефтепродукт - копия - копия.png', 'section/68/62/206a79391534b4645ff3d2e853ecf796.png', 'image/png', '760558', 1024, 478, 0),
(913, '2014-11-14 16:44:29', 1, 'приглашение.png', 'section/68/62/4d011b7e54af3b057a353dcbb802469a.png', 'image/png', '29135847', 5322, 2727, 0),
(914, '2014-11-14 16:44:29', 1, 'Приглашение2.png', 'section/68/62/b339aa999636e5ed01db70bcb24d36df.png', 'image/png', '11585640', 3602, 4070, 0),
(915, '2014-11-14 16:44:29', 1, 'Приглашение3.png', 'section/68/62/03324433d624ddb6268af5ba52426094.png', 'image/png', '18890543', 3500, 3375, 0),
(916, '2014-11-14 16:44:29', 1, 'проруктура.png', 'section/68/62/a2e5b777a756ee79dc4e4d48da020113.png', 'image/png', '9724377', 3500, 2176, 0),
(917, '2014-11-14 16:44:29', 1, 'ричезе.png', 'section/68/62/2a7232e9bf89e24a2c9a483c5df65972.png', 'image/png', '15138907', 3048, 3273, 0),
(918, '2014-11-14 16:44:29', 1, 'ростовнефтепродукт.png', 'section/68/62/00768377141c45d8c3b90f8609afc616.png', 'image/png', '29736192', 4928, 5783, 0),
(922, '2014-11-14 16:47:15', 1, '23 февраля.png', 'section/68/62/68ad9ece6b04f135bded64a0fc67fce8.png', 'image/png', '16302342', 3500, 3500, 0),
(923, '2014-11-14 16:52:49', 1, 'пакет хк ростов.png', 'section/68/62/657418fc4f0e07cb0e2d30a9ea46a838.png', 'image/png', '4789268', 2149, 1750, 0),
(924, '2014-11-14 16:52:49', 1, 'Пакет Кератон.png', 'section/68/62/a59104c73680018ddbe8b4aa892f4f4f.png', 'image/png', '4569550', 1881, 1872, 0),
(925, '2014-11-14 16:52:49', 1, 'Пакет парк.png', 'section/68/62/980c7a70e900112415fbb3822de295ea.png', 'image/png', '2207401', 1750, 1819, 0),
(926, '2014-11-14 16:52:49', 1, 'Пакет правый берег.png', 'section/68/62/a6c2010a18ef444ca3a5d6f07abb340a.png', 'image/png', '3783381', 1750, 1750, 0),
(927, '2014-11-14 16:52:49', 1, 'пакет ричезе.png', 'section/68/62/0848b6efdf861d2da413944cc8a57d3b.png', 'image/png', '3604575', 1888, 1921, 0),
(928, '2014-11-14 16:52:49', 1, 'Пакет РоссельхозБанк.png', 'section/68/62/1af60dd32f43f07d1f3eed136a5b7f8a.png', 'image/png', '3257748', 1918, 1921, 0),
(929, '2014-11-14 16:52:49', 1, 'Пакет Ростовагролизинг.png', 'section/68/62/f049b66e3751ff21f5ca4e04407d9a09.png', 'image/png', '3825012', 1500, 1827, 0),
(930, '2014-11-14 16:52:49', 1, 'пакет рубаи.png', 'section/68/62/9c4c672ac965861f5ff32c0afdc3ff1b.png', 'image/png', '3939130', 1819, 1837, 0),
(931, '2014-11-14 16:52:49', 1, 'пакет сушу.png', 'section/68/62/15cccffb848c012b09bbba474d332b76.png', 'image/png', '3700947', 1750, 1750, 0),
(932, '2014-11-14 16:52:49', 1, 'пакет югпродмаш.png', 'section/68/62/afe09a2f02c22cab8260eeb7ca803812.png', 'image/png', '4215938', 1750, 1750, 0),
(933, '2014-11-14 16:52:49', 1, 'пакет.png', 'section/68/62/8e410d0d232f0ef8dd2f9be5cdcc0709.png', 'image/png', '3345429', 1750, 1876, 0),
(942, '2014-11-14 17:04:32', 1, 'собачка.png', 'ophen/sobachka.png', 'image/png', '236117', 600, 600, 26),
(943, '2014-11-17 09:36:16', 1, 'IMG_9953.JPG', 'section/68/62/8f4eb15f1d5fe7f1abe0236ac860c43a.JPG', 'image/jpeg', '546739', 1024, 676, 0),
(944, '2014-11-17 09:36:16', 1, 'IMG_9955.JPG', 'section/68/62/ee423833d20d9306e405e88377f47b0b.JPG', 'image/jpeg', '491909', 1024, 683, 0),
(945, '2014-11-17 09:36:16', 1, 'IMG_9970.JPG', 'section/68/62/3e03979de3f8a3f5891bf6afbff86efd.JPG', 'image/jpeg', '469686', 1024, 667, 0),
(946, '2014-11-17 09:36:16', 1, 'IMG_9980.JPG', 'section/68/62/f4b674649e3f471783d706c4baa6c438.JPG', 'image/jpeg', '431089', 1024, 683, 0),
(947, '2014-11-17 09:36:16', 1, 'IMG_9968.JPG', 'section/68/62/4ae3fd34b3f73f60676194711bff9938.JPG', 'image/jpeg', '461585', 1024, 685, 0),
(948, '2014-11-17 09:36:16', 1, 'IMG_9969.JPG', 'section/68/62/38c85ae6b5353a3c5f9a0d0273571a9b.JPG', 'image/jpeg', '466205', 1024, 678, 0),
(949, '2014-11-17 09:36:16', 1, 'IMG_9965.JPG', 'section/68/62/af9842f028615dadaa3812be1dfc321a.JPG', 'image/jpeg', '469476', 1024, 670, 0),
(950, '2014-11-26 17:07:56', 1, 'Таблица 1.jpg', 'ophen/Tablica1.jpg', 'image/jpeg', '136789', 698, 343, 26);

-- --------------------------------------------------------

--
-- Структура таблицы `k2_file_dir`
--

DROP TABLE IF EXISTS `k2_file_dir`;
CREATE TABLE IF NOT EXISTS `k2_file_dir` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER` int(11) NOT NULL DEFAULT '0',
  `NAME` varchar(255) NOT NULL DEFAULT '',
  `PARENT` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_file_dir`
--

INSERT INTO `k2_file_dir` (`ID`, `DATE_CREATED`, `USER`, `NAME`, `PARENT`) VALUES
(2, '2011-07-08 17:03:37', 1, 'Фотки', 1),
(7, '2012-02-07 23:15:38', 1, 'gd', 2),
(9, '2012-12-02 06:51:01', 1, 'О компании', 1),
(10, '2012-12-02 18:07:43', 1, 'Оборудование', 1),
(11, '2012-12-03 11:16:00', 1, 'Продажа промотрикотажа', 1),
(12, '2012-12-03 11:24:48', 1, 'Печать по крою', 1),
(13, '2012-12-03 11:29:16', 1, 'Экспериментальный цех', 1),
(14, '2012-12-03 11:33:02', 1, 'Дизайн и разработка изделий', 1),
(15, '2012-12-17 14:25:16', 1, 'Прайс на вышивку', 1),
(16, '2013-03-11 12:32:16', 1, 'Цифровая печать', 1),
(17, '2013-07-01 08:00:29', 1, 'Каталог промотрикотажа', 1),
(18, '2013-07-01 08:01:16', 1, 'ФМ-рибана', 17),
(19, '2013-07-01 08:41:49', 1, 'ПИ-пике', 17),
(20, '2013-07-01 09:02:01', 1, 'ФМ-окантовка', 17),
(21, '2013-07-01 09:21:45', 1, 'ПЖ-пике', 17),
(22, '2013-07-01 10:33:04', 1, 'ФЖ-рибана', 17),
(23, '2013-07-01 11:16:25', 1, 'ФЖ-стрейтч', 17),
(24, '2013-07-01 11:38:22', 1, 'ФЖ-глубокий вырез остатки', 17),
(25, '2013-07-09 04:23:54', 1, 'Дети', 17),
(26, '2014-10-22 06:41:15', 1, 'Реклама', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `k2_module`
--

DROP TABLE IF EXISTS `k2_module`;
CREATE TABLE IF NOT EXISTS `k2_module` (
  `MODULE` varchar(20) NOT NULL DEFAULT '',
  `NAME` varchar(255) NOT NULL DEFAULT '',
  `TEXT` text NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL DEFAULT '0',
  `VERSION` varchar(5) NOT NULL,
  `SETTING` text NOT NULL,
  `PERMISSION` text NOT NULL,
  `SORT` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_module`
--

INSERT INTO `k2_module` (`MODULE`, `NAME`, `TEXT`, `ACTIVE`, `VERSION`, `SETTING`, `PERMISSION`, `SORT`) VALUES
('CURRENCY', 'Курс валют', 'Обеспечивает вывод курсов валют для Центрального банка Российской Федерации', 1, '3.0', 'a:1:{s:4:"CODE";a:2:{i:0;s:3:"USD";i:1;s:3:"EUR";}}', 'b:0;', 20),
('CACHE', 'Кэширование', 'Система кэширования значительно сокращают нагрузку на сервер, время генерации страницы, одновременно увеличивая скорость загрузки страниц.', 1, '3.0', '', '', 10),
('WEATHER', 'Прогноз погоды', 'Модуль для отображения прогнозов погоды', 1, '3.0', 'a:3:{s:4:"CITY";s:5:"34731";s:4:"CODE";s:5:"34731";s:9:"CITY_NAME";s:26:"Ростов-на-Дону";}', 'b:0;', 30),
('SHOP', 'Интернет-магазин', 'Модуль "Интернет-магазин" предназначен для организации системы продаж через Интернет', 1, '3.0', '', '', 40),
('EMAIL', 'Почта', 'Модуль для отправки почтовых сообщений', 1, '3.0', '', '', 50),
('SEO', 'SEO', 'SEO-инструменты', 1, '3.0', '', '', 60);

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_currency`
--

DROP TABLE IF EXISTS `k2_mod_currency`;
CREATE TABLE IF NOT EXISTS `k2_mod_currency` (
  `CODE` char(3) NOT NULL DEFAULT '',
  `NOMINAL` varchar(5) NOT NULL DEFAULT '',
  `NAME` varchar(100) NOT NULL DEFAULT '',
  `VALUE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `DATE` varchar(10) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_currency`
--

INSERT INTO `k2_mod_currency` (`CODE`, `NOMINAL`, `NAME`, `VALUE`, `DATE`) VALUES
('AUD', '1', 'Австралийский доллар', '32.3871', '24.11.2012'),
('AZN', '1', 'Азербайджанский манат', '39.7048', '24.11.2012'),
('GBP', '1', 'Фунт стерлингов Соединенного королевства', '49.6688', '24.11.2012'),
('AMD', '1000', 'Армянских драмов', '76.6810', '24.11.2012'),
('BYR', '10000', 'Белорусских рублей', '36.4123', '24.11.2012'),
('BGN', '1', 'Болгарский лев', '20.5211', '24.11.2012'),
('BRL', '1', 'Бразильский реал', '14.7912', '24.11.2012'),
('HUF', '100', 'Венгерских форинтов', '14.3580', '24.11.2012'),
('DKK', '10', 'Датских крон', '53.8168', '24.11.2012'),
('USD', '1', 'Доллар США', '31.1325', '24.11.2012'),
('EUR', '1', 'Евро', '40.1360', '24.11.2012'),
('INR', '100', 'Индийских рупий', '56.2009', '24.11.2012'),
('KZT', '100', 'Казахских тенге', '20.7529', '24.11.2012'),
('CAD', '1', 'Канадский доллар', '31.2262', '24.11.2012'),
('KGS', '100', 'Киргизских сомов', '65.8233', '24.11.2012'),
('CNY', '10', 'Китайских юаней', '49.9904', '24.11.2012'),
('LVL', '1', 'Латвийский лат', '57.6528', '24.11.2012'),
('LTL', '1', 'Литовский лит', '11.6240', '24.11.2012'),
('MDL', '10', 'Молдавских леев', '25.1627', '24.11.2012'),
('NOK', '10', 'Норвежских крон', '54.7712', '24.11.2012'),
('PLN', '10', 'Польских злотых', '97.6706', '24.11.2012'),
('RON', '10', 'Новых румынских леев', '88.5452', '24.11.2012'),
('XDR', '1', 'СДР (специальные права заимствования)', '47.4923', '24.11.2012'),
('SGD', '1', 'Сингапурский доллар', '25.4247', '24.11.2012'),
('TJS', '10', 'Таджикских сомони', '65.3481', '24.11.2012'),
('TRY', '1', 'Турецкая лира', '17.3141', '24.11.2012'),
('TMT', '1', 'Новый туркменский манат', '10.9237', '24.11.2012'),
('UZS', '1000', 'Узбекских сумов', '15.8326', '24.11.2012'),
('UAH', '10', 'Украинских гривен', '38.1877', '24.11.2012'),
('CZK', '10', 'Чешских крон', '15.7713', '24.11.2012'),
('SEK', '10', 'Шведских крон', '46.6335', '24.11.2012'),
('CHF', '1', 'Швейцарский франк', '33.3146', '24.11.2012'),
('ZAR', '10', 'Южноафриканских рэндов', '34.8894', '24.11.2012'),
('KRW', '1000', 'Вон Республики Корея', '28.6605', '24.11.2012'),
('JPY', '100', 'Японских иен', '37.8097', '24.11.2012');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_email`
--

DROP TABLE IF EXISTS `k2_mod_email`;
CREATE TABLE IF NOT EXISTS `k2_mod_email` (
`ID` int(11) NOT NULL,
  `TYPE` varchar(100) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `SUBJECT` varchar(255) NOT NULL,
  `FROM` varchar(100) NOT NULL,
  `TEMPLATE` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_email`
--

INSERT INTO `k2_mod_email` (`ID`, `TYPE`, `NAME`, `SUBJECT`, `FROM`, `TEMPLATE`) VALUES
(1, 'REGISTRATION_CONFIRM', 'Подтверждение регистрации', '%SITE_NAME%: Подтверждение регистрации', '%FROM_EMAIL%', 'Здравствуйте %USER_FULLNAME%\r\n\r\nВы успешно зарегистрировались на сайте %SERVER_NAME%\r\nВаш логин: %USER_LOGIN%\r\nВаш пароль: %USER_PASSWORD%\r\n\r\nЧтобы активировать Ваш аккаунт откройте, пожалуйста, данную ссылку:\r\n\r\n<a href="http://%SERVER_NAME%/user-account/?action=registration-confirm&code=%CODE%">http://%SERVER_NAME%/user-account/?action=registration-confirm&code=%CODE%</a>\r\n\r\nВы получили это сообщение, потому что Ваш e-mail адрес был зарегистрирован на сайте %SERVER_NAME%\r\nЕсли Вы не регистрировались на этом сайте, пожалуйста, проигнорируйте это письмо\r\n\r\nС наилучшими пожеланиями, администрация сайта %SERVER_NAME%'),
(6, 'PASSWORD_RECOVERY', 'Восстановление пароля', '%SITE_NAME%: Восстановление пароля', '%FROM_EMAIL%', 'Здравствуйте\r\n\r\nДля смены пароля перейдите по следующей ссылке:\r\n\r\n<a href="http://%SERVER_NAME%/user-account/?action=password-recovery&restore=%RESTORE%">http://%SERVER_NAME%/user-account/?action=password-recovery&restore=%RESTORE%</a>\r\n\r\nС наилучшими пожеланиями, администрация сайта %SERVER_NAME%'),
(7, 'FEEDBACK', 'Обратная связь', '%SITE_NAME%: Обратная связь', '%FROM_EMAIL%', 'Здравствуйте\r\n\r\nНовое сообщение с раздела "Контакты"\r\n\r\n%TEXT%\r\n\r\nС наилучшими пожеланиями, администрация сайта %SERVER_NAME%');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_seo`
--

DROP TABLE IF EXISTS `k2_mod_seo`;
CREATE TABLE IF NOT EXISTS `k2_mod_seo` (
`ID` int(11) NOT NULL,
  `PAGE` varchar(255) NOT NULL,
  `TITLE` varchar(255) NOT NULL,
  `KEYWORD` varchar(255) NOT NULL,
  `DESCRIPTION` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_seo`
--

INSERT INTO `k2_mod_seo` (`ID`, `PAGE`, `TITLE`, `KEYWORD`, `DESCRIPTION`) VALUES
(1, '/', 'Аваль-принт  Печать на ткани, на футболках', 'печать на ткани, футболках, вышивка, по крою', 'Аваль-принт предлагает клиентам печать по текстилю, печать на футболках, и готовых изделиях в промышленных масштабах.'),
(2, '/service/56/1/', 'Печать на ткани, полотне, по текстилю, на футболках и постельном белье', 'печать, текстиль, трафаретная, постельное белье, полотно', 'Наша компания предлагает вам полный спектр услуг в области печати по текстилю в промышленных масштабах'),
(3, '/service/56/2/', 'Продажа промо трикотажа - купить бейсболку, белую майку', 'Продажа, промо, трикотажа, купить бейсболку, белую майку, майка без рисунка, кепку', 'На нашем складе вы всегда сможете купить майку и бейсболки под промопечать.'),
(4, '/service/56/3/', 'Услуги вышивки - вышивка логотипов, машинная вышивка, изготовление шевронов', 'Услуги вышивки, вышивка логотипов, изготовление шевронов', 'Наша компания рада предложить нам услуги по высококачественной вышивке на крое и готовых изделиях.'),
(5, '/service/56/7/', 'Печатное производство в Ростове', 'Печать, на ткани, производство, цифровая', 'ООО "Победа" оказывает широкий спектр услуг по цифровой печати, печати на тканях и постельном белье, так же у нас вы можете приобрести промо продукцию - майки, кепки, сувенирные футболки.'),
(6, '/prodazha-promo-produkcii/tekstil/', 'Купить майку поло, футболки, майки оптом, сувенирные футболки, дешевые футболки, поло, бейсболки, оптовая продажа бейсболок, футболки производства Россия', 'майка, поло, футболки оптом, майки, сувенирные, бейсболки, дешевые, производство', 'Компания "ПОБЕДА" предлагает футболки и поло собственного производства со склада, в Ростове-на-Дону. Купить футболки и майки можно оптом. Все футболки производство Россия.');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_address`
--

DROP TABLE IF EXISTS `k2_mod_shop_address`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_address` (
  `ID` int(11) NOT NULL,
  `CITY` varchar(255) NOT NULL,
  `CITY_INDEX` varchar(255) NOT NULL,
  `STREET` varchar(255) NOT NULL,
  `DOM` varchar(255) NOT NULL,
  `CORP` varchar(255) NOT NULL,
  `STR` varchar(255) NOT NULL,
  `POD` varchar(255) NOT NULL,
  `FLOAR` varchar(255) NOT NULL,
  `OFFICE` varchar(255) NOT NULL,
  `KRAY` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_cart`
--

DROP TABLE IF EXISTS `k2_mod_shop_cart`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_cart` (
`ID` int(11) NOT NULL,
  `USER` int(11) NOT NULL,
  `SESSION` char(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `CODE` int(11) NOT NULL,
  `PRICE` decimal(15,2) NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `DATA` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `DATA_ORDER` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_shop_cart`
--

INSERT INTO `k2_mod_shop_cart` (`ID`, `USER`, `SESSION`, `DATE_CREATED`, `NAME`, `CODE`, `PRICE`, `QUANTITY`, `DATA`, `DATA_ORDER`) VALUES
(8, 1, '', '2011-12-06 17:01:20', 'Динозавр', 1, '1000.00', 1, 'a:0:{}', 'a:0:{}');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_delivery`
--

DROP TABLE IF EXISTS `k2_mod_shop_delivery`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_delivery` (
`ID` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `TEXT` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `PRICE` decimal(15,2) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_shop_delivery`
--

INSERT INTO `k2_mod_shop_delivery` (`ID`, `ACTIVE`, `NAME`, `TEXT`, `PRICE`) VALUES
(1, 1, 'Самовывоз', 'Вы можете самостоятельно забрать заказ из нашего магазина', '0.00'),
(3, 1, 'Почта России', '', '0.00');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_handler`
--

DROP TABLE IF EXISTS `k2_mod_shop_handler`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_handler` (
  `HANDLER` varchar(50) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `DATA` mediumtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_shop_handler`
--

INSERT INTO `k2_mod_shop_handler` (`HANDLER`, `NAME`, `DATA`) VALUES
('bank', 'Банковский перевод', 'a:7:{s:8:"POL_NAME";s:20:"Получатель";s:3:"INN";s:12:"115264532637";s:7:"N_SCHET";s:20:"10807810620300041568";s:3:"KPP";s:3:"kpp";s:4:"BANK";s:29:"Московский банк";s:3:"BIK";s:9:"114241203";s:9:"KOR_SCHET";s:20:"30102810930000040003";}'),
('robokassa', 'RoboKassa', 'a:3:{s:5:"LOGIN";s:4:"demo";s:8:"PASSWORD";s:8:"Morbid11";s:9:"PASSWORD2";s:8:"Morbid11";}'),
('beznal', 'Безналичная оплата', 'a:6:{s:7:"COMPANY";s:37:"OOO "Интернет-Магазин"";s:4:"BANK";s:46:"Московский банк развития";s:8:"BANK_BIK";s:8:"00000000";s:10:"BANK_SCHET";s:10:"0000000000";s:14:"BANK_SCHET_POL";s:10:"0000000000";s:3:"NDS";s:0:"";}');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_order`
--

DROP TABLE IF EXISTS `k2_mod_shop_order`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_order` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL,
  `USER_CHANGE` int(11) NOT NULL,
  `PAYER` int(11) NOT NULL,
  `STATUS` int(11) NOT NULL,
  `SUM` decimal(15,2) NOT NULL,
  `DELIVERY` int(11) NOT NULL,
  `PAYMENT` int(11) NOT NULL,
  `COMMENT` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_shop_order`
--

INSERT INTO `k2_mod_shop_order` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `PAYER`, `STATUS`, `SUM`, `DELIVERY`, `PAYMENT`, `COMMENT`) VALUES
(1, '2011-11-30 00:29:37', '2012-02-13 00:21:18', 1, 1, 1, 3, '9000.00', 1, 2, 'asd'),
(2, '2011-11-30 00:30:55', '2012-02-13 00:19:03', 1, 1, 1, 5, '4000.00', 1, 1, '223');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_order_product`
--

DROP TABLE IF EXISTS `k2_mod_shop_order_product`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_order_product` (
`ID` int(11) NOT NULL,
  `SHOP_ORDER` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PRICE` decimal(15,2) NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `DATA_ORDER` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `k2_mod_shop_order_product`
--

INSERT INTO `k2_mod_shop_order_product` (`ID`, `SHOP_ORDER`, `NAME`, `PRICE`, `QUANTITY`, `DATA_ORDER`) VALUES
(1, 1, 'Динозавр', '1000.00', 1, 'a:0:{}'),
(2, 1, 'Раптор', '2000.00', 4, 'a:0:{}'),
(3, 2, 'Орг', '4000.00', 1, 'a:0:{}');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_payer`
--

DROP TABLE IF EXISTS `k2_mod_shop_payer`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_payer` (
`ID` int(11) NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `SORT` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_shop_payer`
--

INSERT INTO `k2_mod_shop_payer` (`ID`, `NAME`, `ACTIVE`, `SORT`) VALUES
(1, 'Физическое лицо', 1, 0),
(2, 'Юридическое лицо', 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_payer1`
--

DROP TABLE IF EXISTS `k2_mod_shop_payer1`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_payer1` (
`ID` int(11) NOT NULL,
  `SHOP_ORDER` int(11) NOT NULL,
  `USER` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `PHONE` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `ADRESS` mediumtext NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_shop_payer1`
--

INSERT INTO `k2_mod_shop_payer1` (`ID`, `SHOP_ORDER`, `USER`, `NAME`, `PHONE`, `EMAIL`, `ADRESS`) VALUES
(1, 1, 1, 'ewf', 'wef', 'admin@admin.ru', 'asd'),
(2, 2, 1, '33', '23', 'aaaaa@aaaaaaaa.ru', '33'),
(3, 3, 1, '567', 'asd', 'aaaaa@aaaaaaaa.ru', 'asd');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_payer2`
--

DROP TABLE IF EXISTS `k2_mod_shop_payer2`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_payer2` (
`ID` int(11) NOT NULL,
  `SHOP_ORDER` int(11) NOT NULL,
  `USER` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `UR_ADRES` varchar(255) NOT NULL,
  `FACT_ADRES` varchar(255) NOT NULL,
  `BANK` varchar(255) NOT NULL,
  `BIK` varchar(255) NOT NULL,
  `KOR_SCHET` varchar(255) NOT NULL,
  `RAS_SCHET` varchar(255) NOT NULL,
  `OKPO` varchar(255) NOT NULL,
  `INN` varchar(255) NOT NULL,
  `KPP` varchar(255) NOT NULL,
  `FIO_RUK` varchar(255) NOT NULL,
  `DOLZ_RUK` varchar(255) NOT NULL,
  `PHONE` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_payment`
--

DROP TABLE IF EXISTS `k2_mod_shop_payment`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_payment` (
`ID` int(11) NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `TEXT` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_shop_payment`
--

INSERT INTO `k2_mod_shop_payment` (`ID`, `ACTIVE`, `NAME`, `TEXT`) VALUES
(1, 1, 'Оплата наличными', '1. Оплата наличными курьеру в момент получения товара.\r\n2. Оплата наличными в офисе при получении товара.\r\n3. Оплата наличными при получении товара в «Почте России».'),
(2, 1, 'Банковский перевод', 'В данном случае банки взимают дополнительно до 3% комиссии, в зависимости от суммы оплаты).\r\nВнимание! Счет на заказ действителен в течении 5-и банковских дней.');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_shop_status`
--

DROP TABLE IF EXISTS `k2_mod_shop_status`;
CREATE TABLE IF NOT EXISTS `k2_mod_shop_status` (
`ID` int(11) NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_shop_status`
--

INSERT INTO `k2_mod_shop_status` (`ID`, `NAME`) VALUES
(1, 'В обработке'),
(2, 'Ваш заказ собран. Ожидаем оплаты.'),
(3, 'Доставлен'),
(4, 'Заказ передан в транспортную компанию'),
(5, 'Заказ передан на Почту'),
(6, 'Курьер с Вашим заказом, в пути');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_mod_weather_city`
--

DROP TABLE IF EXISTS `k2_mod_weather_city`;
CREATE TABLE IF NOT EXISTS `k2_mod_weather_city` (
  `CODE` int(11) NOT NULL,
  `NAME` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_mod_weather_city`
--

INSERT INTO `k2_mod_weather_city` (`CODE`, `NAME`) VALUES
(99855, 'Абаза'),
(29865, 'Абакан'),
(29485, 'Абан'),
(28581, 'Абатский'),
(28815, 'Абдулино'),
(99666, 'Абинск'),
(89157, 'Автуры'),
(23383, 'Агата'),
(99729, 'Агвали'),
(99345, 'Агидель'),
(29676, 'Агинское (Красноярск.)'),
(30859, 'Агинское (Читинск.)'),
(28414, 'Агрыз'),
(99782, 'Адамовка'),
(37171, 'Адлер'),
(99949, 'Адыгейск'),
(28617, 'Азнакаево'),
(34723, 'Азов'),
(99567, 'Азово'),
(89130, 'Ак-Довурак'),
(35127, 'Акбулак'),
(99532, 'Аксай'),
(99475, 'Аксарка'),
(28607, 'Аксубаево'),
(28606, 'Акташ'),
(30957, 'Акша'),
(35037, 'Акьяр'),
(37227, 'Алагир'),
(28248, 'Алапаевск'),
(27679, 'Алатырь'),
(31004, 'Алдан'),
(88711, 'Алейск'),
(89087, 'Александрийская'),
(99960, 'Александров'),
(34391, 'Александров-Гай'),
(99791, 'Александровск (Пермск.)'),
(32061, 'Александровск-Сахалинский'),
(30971, 'Александровский Завод'),
(37051, 'Александровское (Ставр.)'),
(23955, 'Александровское (Томск.)'),
(99762, 'Алексеевка (Белгор.)'),
(99519, 'Алексеевка (Самарск.)'),
(27715, 'Алексин'),
(99674, 'Аликово'),
(24878, 'Аллах-Юнь'),
(89165, 'Аллерой'),
(88721, 'Алтайское'),
(89168, 'Алхан-Кала'),
(99954, 'Альметьевск'),
(24962, 'Амга'),
(23022, 'Амдерма'),
(99657, 'Амурзет'),
(99456, 'Амурск'),
(25563, 'Анадырь'),
(37001, 'Анапа'),
(88868, 'Анапская'),
(88877, 'Анастасиевская'),
(30715, 'Ангарск'),
(99409, 'Анжеро-Судженск'),
(99814, 'Анива'),
(34238, 'Анна'),
(31981, 'Анучино'),
(22213, 'Апатиты'),
(99403, 'Апрелевка'),
(99667, 'Апшеронск'),
(89039, 'Арамиль'),
(28548, 'Аргаяш'),
(89153, 'Аргун'),
(27655, 'Ардатов'),
(89063, 'Ардон'),
(27653, 'Арзамас'),
(34964, 'Арзгир'),
(89033, 'Аркадак'),
(37031, 'Армавир'),
(99477, 'Армизонское'),
(99478, 'Аромашево'),
(31938, 'Арсеньев'),
(27593, 'Арск'),
(31974, 'Артем'),
(28346, 'Артемовский'),
(99511, 'Арти'),
(22550, 'Архангельск'),
(28726, 'Архангельское (Башкорт.)'),
(99484, 'Архангельское (Тульск.)'),
(31594, 'Архара'),
(98923, 'Архыз'),
(30803, 'Аршан'),
(99402, 'Асбест'),
(89121, 'Асино'),
(99747, 'Аскарово'),
(29961, 'Аскиз'),
(28522, 'Аскино'),
(89166, 'Ассиновская'),
(34880, 'Астрахань'),
(34069, 'Аткарск'),
(99706, 'Атяшево'),
(28114, 'Афанасьево'),
(88858, 'Афипский'),
(34575, 'Ахтубинск'),
(37663, 'Ахты'),
(88857, 'Ахтырский'),
(29467, 'Ачинск'),
(98963, 'Ачит'),
(89158, 'Ачхой-Мартан'),
(99468, 'Аша'),
(89014, 'Аютинский'),
(31168, 'Аян'),
(27008, 'Бабаево'),
(37169, 'Бабаюрт'),
(99401, 'Бавлы'),
(99533, 'Багаевская'),
(29708, 'Баган'),
(30554, 'Багдарин'),
(99703, 'Базарные Матаки'),
(89036, 'Базарный Карабулак'),
(99507, 'Байкалово'),
(30818, 'Байкальск'),
(23891, 'Байкит'),
(28938, 'Баймак'),
(89143, 'Бакал'),
(28615, 'Бакалы'),
(37135, 'Баксан'),
(29328, 'Бакчар'),
(88817, 'Балабаново'),
(30612, 'Балаганск'),
(34085, 'Балаково'),
(99588, 'Балахна'),
(29662, 'Балахта'),
(99455, 'Балашиха'),
(34152, 'Балашов'),
(99683, 'Балезино'),
(30866, 'Балей'),
(99763, 'Балтай'),
(28407, 'Балтаси'),
(26701, 'Балтийск'),
(29612, 'Барабинск'),
(89060, 'Баранчинский'),
(30636, 'Баргузин'),
(99811, 'Барда'),
(29838, 'Барнаул'),
(99474, 'Барыш'),
(24263, 'Батагай'),
(24261, 'Батагай-Алыта'),
(99400, 'Батайск'),
(27685, 'Батырево'),
(88837, 'Бачатский'),
(89160, 'Бачи-Юрт'),
(99545, 'Башмаково'),
(30627, 'Баяндай'),
(99546, 'Беднодемьянск'),
(27217, 'Бежецк'),
(27995, 'Безенчук'),
(99547, 'Беково'),
(34836, 'Белая Глина'),
(24194, 'Белая Гора'),
(34539, 'Белая Калитва'),
(28105, 'Белая Холуница'),
(34214, 'Белгород'),
(99749, 'Белебей'),
(99770, 'Белев'),
(88780, 'Белиджи'),
(27955, 'Белинский'),
(29745, 'Белово'),
(31513, 'Белогорск'),
(22939, 'Белозерск'),
(99434, 'Белокуриха'),
(99716, 'Беломорск'),
(88955, 'Белоозёрский'),
(28831, 'Белорецк'),
(37013, 'Белореченск'),
(88818, 'Белоусово'),
(88720, 'Белоярск'),
(89058, 'Белоярский (Свердл. обл.)'),
(23634, 'Белоярский (Тюмен. обл.)'),
(88747, 'Белые Берега'),
(26585, 'Белый'),
(29241, 'Белый Яр'),
(35125, 'Беляевка'),
(24758, 'Бердигестях'),
(99573, 'Бердск'),
(28574, 'Бердюжье'),
(28028, 'Березники'),
(88891, 'Берёзовка (Краснояр. край)'),
(99804, 'Березовка (Перм. край)'),
(23631, 'Березово'),
(88830, 'Березовский (Кемеровская обл.)'),
(89040, 'Березовский (Свердловская область)'),
(25677, 'Беринговский'),
(37220, 'Беслан'),
(29962, 'Бея'),
(99751, 'Бижбуляк'),
(29947, 'Бийск'),
(29939, 'Бийск-Зональная'),
(31832, 'Бикин'),
(25147, 'Билибино'),
(31713, 'Биробиджан'),
(28621, 'Бирск'),
(89059, 'Бисерть'),
(30934, 'Бичура'),
(88718, 'Благовещенка'),
(31510, 'Благовещенск (Амур.)'),
(99745, 'Благовещенск (Башкорт.)'),
(89183, 'Благовещенская'),
(34958, 'Благодарный'),
(99634, 'Бобров'),
(28443, 'Богданович'),
(89123, 'Богородицк'),
(99578, 'Богородск'),
(99618, 'Богородское (Кировск.)'),
(31439, 'Богородское (Хабар.)'),
(29553, 'Боготол'),
(99854, 'Боград'),
(29282, 'Богучаны'),
(34336, 'Богучар'),
(30253, 'Бодайбо'),
(34445, 'Боковская'),
(99773, 'Бокситогорск'),
(27666, 'Болдино'),
(26298, 'Бологое'),
(29539, 'Болотное'),
(89124, 'Болохово'),
(27809, 'Болхов'),
(99696, 'Большая Атня'),
(35001, 'Большая Глушица'),
(29471, 'Большая Мурта'),
(28313, 'Большая Соснова'),
(99520, 'Большая Черниговка'),
(32562, 'Большерецк'),
(28593, 'Большеречье'),
(27777, 'Большие Березники'),
(28491, 'Большие Уки'),
(99707, 'Большое Игнатово'),
(99577, 'Большое Мурашкино'),
(99471, 'Большое Нагаткино'),
(99602, 'Большое Солдатское'),
(99480, 'Большое Сорокино'),
(88997, 'Большой Камень'),
(29464, 'Большой Улуй'),
(31253, 'Бомнак'),
(88974, 'Бор'),
(30965, 'Борзя'),
(88739, 'Борисовка'),
(34146, 'Борисоглебск'),
(26291, 'Боровичи'),
(88819, 'Боровск'),
(89132, 'Боровский'),
(24761, 'Борогонцы'),
(88884, 'Бородино'),
(99304, 'Борок'),
(99518, 'Борское'),
(37367, 'Ботлих'),
(30618, 'Бохан'),
(30309, 'Братск'),
(35041, 'Бреды'),
(27213, 'Брейтово'),
(99399, 'Бронницы'),
(99387, 'Брюховецкая'),
(26898, 'Брянск'),
(28711, 'Бугульма'),
(28806, 'Бугуруслан'),
(37061, 'Буденновск'),
(28713, 'Буздяк'),
(28909, 'Бузулук'),
(27689, 'Буинск'),
(27242, 'Буй'),
(37471, 'Буйнакск'),
(89057, 'Буланаш'),
(99753, 'Бураево'),
(27568, 'Бутурлино'),
(34233, 'Бутурлиновка'),
(34369, 'Быково (Волгогр.)'),
(27527, 'Быково (Моск.)'),
(28403, 'Вавож'),
(28469, 'Вагай'),
(99548, 'Вадинск'),
(26289, 'Валдай'),
(34321, 'Валуйки'),
(24908, 'Ванавара'),
(89137, 'Ванино'),
(98903, 'Ванкор'),
(99608, 'Варгаши'),
(88867, 'Варениковская'),
(28847, 'Варна (Челяб.)'),
(99579, 'Варнавино'),
(89093, 'Васильево'),
(88872, 'Васюринская'),
(88845, 'Вахруши'),
(37361, 'Ведено'),
(98919, 'Велеса (Тверск.)'),
(26578, 'Велиж'),
(26477, 'Великие Луки'),
(22981, 'Великий Устюг'),
(22867, 'Вельск'),
(29508, 'Венгерово'),
(22686, 'Вендинга'),
(99483, 'Венев'),
(28216, 'Верещагино'),
(99620, 'Верх-Чебула'),
(24644, 'Верхневилюйск'),
(89071, 'Верхнеднепровский'),
(25538, 'Верхнее Пенжино'),
(28833, 'Верхнеуральск'),
(28613, 'Верхнеяркеево'),
(99744, 'Верхние Киги'),
(99735, 'Верхние Татышлы'),
(34579, 'Верхний Баскунчак'),
(99628, 'Верхний Ландех'),
(99433, 'Верхний Тагил'),
(99697, 'Верхний Услон'),
(28541, 'Верхний Уфалей'),
(29789, 'Верхняя Гутара'),
(89041, 'Верхняя Пышма'),
(28244, 'Верхняя Салда'),
(89061, 'Верхняя Синячиха'),
(22778, 'Верхняя Тойма'),
(89042, 'Верхняя Тура'),
(99639, 'Верховажье'),
(27915, 'Верховье'),
(28144, 'Верхотурье'),
(27295, 'Верхошижемье'),
(24266, 'Верхоянск'),
(34733, 'Веселый'),
(99487, 'Весьегонск'),
(27277, 'Ветлуга'),
(88852, 'Ветлужский'),
(34348, 'Вешенская'),
(99388, 'Вешкайма'),
(99454, 'Видное'),
(28481, 'Викулово'),
(24641, 'Вилюйск'),
(99816, 'Вилючинск'),
(89133, 'Винзили'),
(30054, 'Витим'),
(88800, 'Вихоревка'),
(88785, 'Вичуга'),
(31960, 'Владивосток'),
(37228, 'Владикавказ'),
(27532, 'Владимир'),
(27524, 'Внуково'),
(89176, 'Внуково (Яросл.)'),
(22954, 'Вожега'),
(99580, 'Вознесенское'),
(34560, 'Волгоград'),
(99976, 'Волгодонск'),
(88850, 'Волгореченск'),
(99333, 'Волжск'),
(99948, 'Волжский'),
(99410, 'Волово (Липецк.)'),
(27824, 'Волово (Тульск.)'),
(27037, 'Вологда'),
(88975, 'Володарск'),
(27502, 'Волоколамск'),
(88740, 'Волоконовка'),
(26067, 'Волосово'),
(20982, 'Волочанка'),
(99772, 'Волхов'),
(89043, 'Волчанск'),
(88725, 'Волчиха'),
(99781, 'Вольск'),
(88847, 'Воргашор'),
(23226, 'Воркута'),
(34122, 'Воронеж'),
(88827, 'Воротынск'),
(88976, 'Ворсма'),
(99453, 'Воскресенск'),
(27463, 'Воскресенское (Нижегор.)'),
(99512, 'Воскресенское (Сарат.)'),
(28318, 'Воткинск'),
(27176, 'Вохма'),
(99432, 'Всеволожск'),
(99989, 'Вуктыл'),
(99675, 'Вурнары'),
(22892, 'Выборг'),
(27643, 'Выкса'),
(88849, 'Выльгорт'),
(88905, 'Вырица'),
(99668, 'Выселки'),
(99356, 'Высоковск'),
(22837, 'Вытегра'),
(26393, 'Вышний Волочек'),
(31786, 'Вяземский'),
(27543, 'Вязники'),
(26695, 'Вязьма'),
(28502, 'Вятские Поляны'),
(99629, 'Гаврилов Посад'),
(99459, 'Гаврилов-Ям'),
(27507, 'Гагарин'),
(88968, 'Гаджиево'),
(99306, 'Гай'),
(99810, 'Гайны'),
(27243, 'Галич'),
(28049, 'Гари'),
(99431, 'Гатчина'),
(26703, 'Гвардейск'),
(26157, 'Гдов'),
(37004, 'Геленджик'),
(37058, 'Георгиевск'),
(99613, 'Георгиевское'),
(99722, 'Гергебиль'),
(99754, 'Гиагинская'),
(89016, 'Гигант'),
(99341, 'Гладенькая'),
(28214, 'Глазов'),
(89013, 'Глубокий'),
(99610, 'Глядянское'),
(89161, 'Гойты'),
(99953, 'Голицыно'),
(28478, 'Голышманово'),
(99340, 'Гора Морозная'),
(36052, 'Горно-Алтайск'),
(99803, 'Горнозаводск'),
(89171, 'Горный'),
(36037, 'Горняк'),
(27453, 'Городец'),
(88762, 'Городище (Волгогр.)'),
(27877, 'Городище (Пенз. обл.)'),
(99961, 'Гороховец'),
(99603, 'Горшечное'),
(88763, 'Горьковский'),
(99568, 'Горьковское'),
(89074, 'Горячеводский'),
(37014, 'Горячий Ключ'),
(34202, 'Готня'),
(88838, 'Грамотеино'),
(99685, 'Грахово'),
(99561, 'Грачевка(Оренб.)'),
(99661, 'Грачевка(Ставр.)'),
(99790, 'Гремячинск'),
(88770, 'Грибановский'),
(37235, 'Грозный'),
(27937, 'Грязи'),
(88765, 'Грязовец'),
(99789, 'Губаха'),
(99430, 'Губкин'),
(98912, 'Губкинский'),
(37244, 'Гудермес'),
(99335, 'Гуково'),
(99386, 'Гулькевичи'),
(37463, 'Гуниб'),
(88813, 'Гурьевск (Калинингр. обл.)'),
(99458, 'Гурьевск (Кемер. обл.)'),
(88814, 'Гусев'),
(99850, 'Гусиноозерск'),
(27539, 'Гусь-Хрустальный'),
(30714, 'Дабады'),
(28724, 'Давлеканово'),
(88775, 'Дагестанские Огни'),
(99429, 'Дагомыс'),
(28457, 'Далматово'),
(99833, 'Дальнегорск'),
(27565, 'Дальнее Константиново'),
(31873, 'Дальнереченск'),
(27235, 'Данилов'),
(34267, 'Даниловка'),
(99600, 'Данков'),
(30858, 'Дарасун'),
(27185, 'Даровской'),
(22762, 'Двинской Березник'),
(88883, 'Двубратский'),
(28312, 'Дебессы'),
(89044, 'Дегтярск'),
(99539, 'Дедовичи'),
(88912, 'Дедовск'),
(26673, 'Демидов'),
(26381, 'Демянск'),
(24076, 'Депутатский'),
(88966, 'дер. Давыдово'),
(37470, 'Дербент'),
(99513, 'Дергачи (Сарат.)'),
(89070, 'Десногорск'),
(89095, 'Джалиль'),
(99965, 'Дзержинск(Нижегор.обл.)'),
(88913, 'Дзержинский'),
(29481, 'Дзержинское'),
(99853, 'Дивногорск'),
(34858, 'Дивное'),
(89064, 'Дигора'),
(20674, 'Диксон'),
(27799, 'Димитровград'),
(99669, 'Динская'),
(34004, 'Дмитриев-Льговский'),
(27419, 'Дмитров'),
(34001, 'Дмитровск-Орловский'),
(26268, 'Дно'),
(28222, 'Добрянка'),
(29716, 'Довольное'),
(88914, 'Долгопрудный'),
(32133, 'Долинск'),
(37197, 'Домбай'),
(35233, 'Домбаровский'),
(27613, 'Домодедово'),
(89004, 'Донецк (Ростов. обл.)'),
(99658, 'Донское'),
(89008, 'Донской'),
(89125, 'Донской'),
(99502, 'Дорогобуж'),
(88915, 'Дрезна'),
(27782, 'Дрожжаное'),
(99712, 'Дубенки'),
(88892, 'Дубинино'),
(99974, 'Дубна'),
(99779, 'Дубовка'),
(23074, 'Дудинка'),
(30952, 'Дульдурга'),
(99503, 'Духовщина'),
(99725, 'Дылым'),
(28610, 'Дюртюли'),
(98909, 'Дятьково'),
(89018, 'Егорлыкская'),
(27623, 'Егорьевск'),
(34727, 'Ейск'),
(28440, 'Екатеринбург'),
(31524, 'Екатеринославка'),
(28506, 'Елабуга'),
(30721, 'Еланцы'),
(34253, 'Елань'),
(27648, 'Елатьма'),
(27928, 'Елец'),
(88862, 'Елизаветинская'),
(32548, 'Елизово'),
(99805, 'Елово'),
(99764, 'Елховка'),
(26783, 'Ельня'),
(99350, 'Еманжелинск'),
(23704, 'Емва'),
(29572, 'Емельяново'),
(29263, 'Енисейск'),
(99649, 'Енотаевка'),
(24817, 'Ербогачен'),
(29869, 'Ермаковское'),
(88820, 'Ермолино'),
(99504, 'Ершичи'),
(34186, 'Ершов'),
(99945, 'Ессентуки'),
(89079, 'Ессентукская'),
(99467, 'Еткуль'),
(27921, 'Ефремов'),
(99047, 'Железноводск'),
(30316, 'Железногорск(Ирк.)'),
(98898, 'Железногорск(Краснояр.Кр.)'),
(34002, 'Железногорск(Курск.)'),
(98910, 'Железнодорожный'),
(34047, 'Жердевка'),
(30521, 'Жигалово'),
(24343, 'Жиганск'),
(99428, 'Жигулевск'),
(26896, 'Жиздра'),
(98997, 'Жирновск'),
(88821, 'Жуков'),
(26894, 'Жуковка'),
(99336, 'Жуковский'),
(30968, 'Забайкальск'),
(34753, 'Заветное'),
(31527, 'Завитинск'),
(99408, 'Заводоуковск'),
(89065, 'Заводской'),
(88786, 'Заволжск'),
(88977, 'Заволжье'),
(99342, 'Завьялиха'),
(99595, 'Задонск'),
(99849, 'Заиграево'),
(99698, 'Заинск'),
(99848, 'Закаменск'),
(30606, 'Залари'),
(88885, 'Заозерный'),
(88969, 'Заозерск'),
(26487, 'Западная Двина'),
(88970, 'Заполярный'),
(88958, 'Запрудня'),
(99593, 'Зарайск'),
(99294, 'Заречный (Пенз. обл.)'),
(89045, 'Заречный (Свердл. обл.)'),
(88712, 'Заринск'),
(88810, 'Заюково'),
(88907, 'Звенигово'),
(99452, 'Звенигород'),
(89005, 'Зверево'),
(28756, 'Звериноголовское'),
(29712, 'Здвинск'),
(99426, 'Зеленогорск (Краснояр.)'),
(99427, 'Зеленогорск (Ленингр.)'),
(99451, 'Зеленоград'),
(99297, 'Зеленоградск'),
(98911, 'Зеленодольск'),
(37056, 'Зеленокумск'),
(37112, 'Зеленчукская'),
(27857, 'Земетчино'),
(34735, 'Зерноград'),
(31300, 'Зея'),
(35026, 'Зилаир'),
(30603, 'Зима'),
(34743, 'Зимовники'),
(28630, 'Златоуст'),
(33042, 'Злынка'),
(36038, 'Змеиногорск'),
(88993, 'Знаменка (Орлов. обл.)'),
(99769, 'Знаменка(Тамбов.)'),
(88728, 'Знаменск'),
(99569, 'Знаменское'),
(88911, 'Зубова Поляна'),
(99488, 'Зубцов'),
(88841, 'Зуевка'),
(25400, 'Зырянка'),
(99839, 'Зырянское'),
(99676, 'Ибреси'),
(88896, 'Ивангород'),
(99832, 'Ивановка(Амурская обл.)'),
(27347, 'Иваново'),
(88916, 'Ивантеевка'),
(23921, 'Ивдель'),
(30825, 'Иволгинск'),
(23274, 'Игарка'),
(88733, 'Иглино'),
(30686, 'Игнашино'),
(98951, 'Игол'),
(99812, 'Игора'),
(28315, 'Игра'),
(99987, 'Игрим'),
(29766, 'Идринское'),
(28411, 'Ижевск'),
(23503, 'Ижма'),
(88776, 'Избербаш'),
(99596, 'Измалково'),
(34945, 'Изобильный'),
(34868, 'Ики-Бурул'),
(99650, 'Икряное'),
(88886, 'Иланский'),
(35112, 'Илек'),
(34461, 'Иловля'),
(99793, 'Ильинский'),
(30832, 'Илька'),
(88856, 'Ильский'),
(89092, 'Инжавино'),
(27872, 'Инза'),
(89075, 'Иноземцево'),
(27861, 'Инсар'),
(88839, 'Инской'),
(23327, 'Инта'),
(99662, 'Ипатово'),
(29587, 'Ирбейское'),
(28351, 'Ирбит'),
(30710, 'Иркутск'),
(99521, 'Исаклы'),
(99479, 'Исетское'),
(28688, 'Исилькуль'),
(29730, 'Искитим'),
(88808, 'Исламей'),
(27511, 'Истра'),
(99740, 'Исянгулово'),
(89136, 'Ишеевка'),
(28573, 'Ишим'),
(99741, 'Ишимбай'),
(99990, 'Йошкар-Ола'),
(89131, 'Каа-Хем'),
(30729, 'Кабанск'),
(31946, 'Кавалерово'),
(99385, 'Кавказская'),
(99527, 'Кадом'),
(88768, 'Кадуй'),
(99398, 'Кажим'),
(34344, 'Казанская'),
(88879, 'Казанская'),
(99476, 'Казанское'),
(27595, 'Казань'),
(30337, 'Казачинское(Ирк.)'),
(29374, 'Казачинское(Краснояр.)'),
(88887, 'Кайеркан'),
(34247, 'Калач'),
(34552, 'Калач-на-Дону'),
(28696, 'Калачинск'),
(99462, 'Калга'),
(22408, 'Калевала'),
(26702, 'Калининград'),
(88965, 'Калининец'),
(88855, 'Калинино'),
(34164, 'Калининск'),
(99384, 'Калининская'),
(88831, 'Калтан'),
(99742, 'Калтасы'),
(27703, 'Калуга'),
(99489, 'Калязин'),
(89134, 'Камбарка'),
(27961, 'Каменка'),
(89010, 'Каменоломни'),
(28449, 'Каменск-Уральский'),
(34535, 'Каменск-Шахтинский'),
(25744, 'Каменское'),
(29822, 'Камень-на-Оби'),
(89002, 'Камень-Рыболов'),
(88750, 'Камешково'),
(99293, 'Камские Поляны'),
(99699, 'Камское Устье'),
(99651, 'Камызяк'),
(34363, 'Камышин'),
(28451, 'Камышлов'),
(27587, 'Канаш'),
(22217, 'Кандалакша'),
(88734, 'Кандры'),
(34825, 'Каневская'),
(29581, 'Канск'),
(88773, 'Кантемировка'),
(88796, 'Кантышево'),
(88751, 'Карабаново'),
(89144, 'Карабаш'),
(88781, 'Карабудахкент'),
(99726, 'Карабудахкент'),
(88791, 'Карабулак'),
(99794, 'Карагай'),
(28526, 'Караидель'),
(99686, 'Каракулино'),
(30437, 'Карам'),
(29814, 'Карасук'),
(29874, 'Каратузское'),
(20978, 'Караул'),
(30549, 'Карафтит'),
(37116, 'Карачаевск'),
(27901, 'Карачев'),
(99612, 'Каргаполье'),
(29122, 'Каргасок'),
(29624, 'Каргат'),
(22845, 'Каргополь'),
(99743, 'Кармаскалы'),
(89046, 'Карпинск'),
(22671, 'Карпогоры'),
(28941, 'Карталы'),
(30853, 'Карымское'),
(99526, 'Касимов'),
(99469, 'Касли'),
(99425, 'Каспийск'),
(34027, 'Касторное'),
(37597, 'Касумкент'),
(28639, 'Катав-Ивановск'),
(99607, 'Катайск'),
(28135, 'Качканар'),
(30622, 'Качуг'),
(99535, 'Кашары'),
(27316, 'Кашин'),
(27627, 'Кашира'),
(99755, 'Кашхатау'),
(88782, 'Каякент'),
(99784, 'Кваркено'),
(88834, 'Кедровка'),
(30102, 'Кежма'),
(99687, 'Кез'),
(29642, 'Кемерово'),
(99708, 'Кемля'),
(22522, 'Кемь-Порт'),
(88811, 'Кенже'),
(99490, 'Кесова Гора'),
(34668, 'Кетченеры'),
(30833, 'Кижинга'),
(28131, 'Кизел'),
(28939, 'Кизильское'),
(88777, 'Кизилюрт'),
(37163, 'Кизляр'),
(99688, 'Кизнер'),
(99619, 'Кикнур'),
(28402, 'Кильмезь'),
(89126, 'Кимовск'),
(27412, 'Кимры'),
(26059, 'Кингисепп'),
(99334, 'Кинель'),
(28805, 'Кинель-Черкассы'),
(27346, 'Кинешма'),
(99734, 'Киргиз-Мияки'),
(99485, 'Киреевск'),
(30230, 'Киренск'),
(99424, 'Киржач'),
(27021, 'Кириллов'),
(26080, 'Кириши'),
(27196, 'Киров'),
(88822, 'Киров (Калужская область)'),
(89047, 'Кировград'),
(99397, 'Кирово-Чепецк'),
(98948, 'Кировск (Ленингр.)'),
(22216, 'Кировск (Мурм.)'),
(31878, 'Кировский'),
(28009, 'Кирс'),
(27957, 'Кирсанов'),
(29749, 'Киселевск'),
(37123, 'Кисловодск'),
(27071, 'Кичменгский Городок'),
(99689, 'Киясово'),
(99643, 'Клетня'),
(88745, 'Климово'),
(27417, 'Клин'),
(26987, 'Клинцы'),
(32389, 'Ключи'),
(28709, 'Клявлино'),
(22204, 'Ковдор'),
(99963, 'Ковров'),
(99709, 'Ковылкино'),
(23748, 'Когалым'),
(29197, 'Кодинск'),
(29532, 'Кожевниково'),
(99621, 'Козельск'),
(99677, 'Козловка'),
(27479, 'Козьмодемьянск'),
(23904, 'Койгородок'),
(22112, 'Кола'),
(27164, 'Кологрив'),
(27625, 'Коломна'),
(28498, 'Колосовка'),
(29231, 'Колпашево'),
(29631, 'Колывань'),
(89056, 'Кольцово'),
(99307, 'Кольчугино'),
(88897, 'Коммунар (Ленингр.)'),
(29759, 'Коммунар (Хакасия)'),
(31561, 'Комсомольск-на-Амуре'),
(34975, 'Комсомольский (Калмыкия)'),
(88910, 'Комсомольский (Мордовия)'),
(99486, 'Конаково'),
(28066, 'Кондинское'),
(27966, 'Кондоль'),
(22727, 'Кондопога'),
(88823, 'Кондрово'),
(30246, 'Конкудера'),
(22951, 'Коноша'),
(31586, 'Константиновка'),
(34644, 'Константиновск'),
(89145, 'Копейск'),
(99852, 'Копьево'),
(89027, 'Кораблино'),
(99604, 'Коренево'),
(34926, 'Кореновск'),
(89146, 'Коркино'),
(99570, 'Кормиловка'),
(99411, 'Королев'),
(99646, 'Короча'),
(32158, 'Корсаков'),
(99775, 'Коряжма'),
(99809, 'Коса'),
(22695, 'Кослан'),
(99977, 'Костомукша'),
(27333, 'Кострома'),
(88952, 'Котельники'),
(34655, 'Котельниково'),
(27283, 'Котельнич'),
(22887, 'Котлас'),
(98996, 'Котово'),
(89089, 'Котовск'),
(88787, 'Кохма'),
(99808, 'Кочево'),
(29626, 'Коченево'),
(29724, 'Кочки'),
(89078, 'Кочубеевское'),
(36259, 'Кош-Агач'),
(99766, 'Кошки'),
(88959, 'Красково'),
(26976, 'Красная Гора'),
(28625, 'Красная Горка'),
(37107, 'Красная Поляна'),
(88917, 'Красноармейск (Моск. обл.)'),
(99514, 'Красноармейск (Сарат.)'),
(22876, 'Красноборск'),
(88840, 'Краснобродский'),
(23917, 'Красновишерск'),
(34848, 'Красногвардейское'),
(99540, 'Красногородск'),
(99450, 'Красногорск'),
(89150, 'Красногорский'),
(34929, 'Краснодар'),
(99597, 'Красное'),
(88918, 'Краснозаводск'),
(29813, 'Краснозерское'),
(88919, 'Краснознаменск (Моск. обл.)'),
(30977, 'Краснокаменск'),
(99788, 'Краснокамск'),
(89082, 'Краснокумское'),
(88986, 'Краснообск'),
(88764, 'Краснооктябрьский'),
(23465, 'Красноселькуп'),
(27756, 'Краснослободск'),
(88760, 'Краснослободск (Волгогр.)'),
(29765, 'Краснотуранск'),
(28041, 'Краснотурьинск'),
(99437, 'Красноуральск'),
(99738, 'Красноусольский'),
(28434, 'Красноуфимск'),
(29574, 'Красноярск'),
(27369, 'Красные Баки'),
(99505, 'Красный'),
(34273, 'Красный Кут'),
(88759, 'Красный Октябрь (Ковровский р-н)'),
(89006, 'Красный Сулин'),
(27215, 'Красный Холм'),
(30935, 'Красный Чикой'),
(88730, 'Красный Яр'),
(99522, 'Красный Яр'),
(88824, 'Кремёнки'),
(26285, 'Крестцы'),
(29335, 'Кривошеино'),
(89026, 'Кривянская'),
(34936, 'Кропоткин'),
(99842, 'Крутинка'),
(99383, 'Крыловская'),
(37002, 'Крымск'),
(88978, 'Кстово'),
(99389, 'Кубинка'),
(35126, 'Кувандык'),
(26398, 'Кувшиново'),
(89175, 'Кугеси'),
(28116, 'Кудымкар'),
(99796, 'Куеда'),
(99713, 'Куженер'),
(27953, 'Кузнецк'),
(99843, 'Куйбышев'),
(99536, 'Куйбышево'),
(30505, 'Куйтун'),
(89094, 'Кукмор'),
(99581, 'Кулебаки'),
(89020, 'Кулешовка'),
(24891, 'Кулу'),
(36024, 'Кулунда'),
(27296, 'Кумены'),
(28927, 'Кумертау'),
(37477, 'Кумух'),
(28326, 'Кунгур'),
(36325, 'Кунгуртуг'),
(29706, 'Купино'),
(29870, 'Курагино'),
(99727, 'Курах'),
(28661, 'Курган'),
(99382, 'Курганинск'),
(32174, 'Курильск'),
(99563, 'Курманаевка'),
(88920, 'Куровское'),
(37045, 'Курсавка'),
(34009, 'Курск'),
(89083, 'Курская'),
(28659, 'Куртамыш'),
(30547, 'Курумкан'),
(89156, 'Курчалой'),
(34102, 'Курчатов'),
(98947, 'Куса'),
(30616, 'Кутулик'),
(89048, 'Кушва'),
(28624, 'Кушнаренково'),
(34737, 'Кущевская'),
(36096, 'Кызыл'),
(99693, 'Кызыл-Мажалык'),
(30949, 'Кыра'),
(30806, 'Кырен'),
(28036, 'Кытлым'),
(29405, 'Кыштовка'),
(99438, 'Кыштым'),
(30925, 'Кяхта'),
(37026, 'Лабинск'),
(25496, 'Лаврентия'),
(34984, 'Лагань'),
(99381, 'Лаго-Наки плато'),
(88866, 'Ладожская'),
(99423, 'Лазаревское'),
(31986, 'Лазо'),
(27693, 'Лаишево'),
(88752, 'Лакинск'),
(22983, 'Лальск'),
(89184, 'Лахденпохья'),
(99594, 'Лебедянь'),
(29768, 'Лебяжье(Краснояр.)'),
(28662, 'Лебяжье(Курган.)'),
(27923, 'Лев Толстой'),
(37474, 'Леваши'),
(89084, 'Левокумское'),
(99380, 'Ленинградская'),
(88779, 'Ленинкент'),
(99348, 'Лениногорск'),
(99765, 'Ленинск'),
(99845, 'Ленинск-Кузнецкий'),
(31710, 'Ленинское'),
(24923, 'Ленск'),
(89072, 'Лермонтов'),
(99491, 'Лесное'),
(28136, 'Лесной'),
(26488, 'Лесной Заповедник'),
(31875, 'Лесозаводск'),
(98897, 'Лесосибирск'),
(99659, 'Летняя Ставка'),
(22573, 'Лешуконское'),
(34013, 'Ливны'),
(99319, 'Ликино-Дулёво'),
(34887, 'Лиман'),
(88985, 'Линёво'),
(27930, 'Липецк'),
(34231, 'Лиски'),
(98949, 'Листвянка'),
(89009, 'Лиховской'),
(99492, 'Лихославль'),
(88921, 'Лобня'),
(22127, 'Ловозеро'),
(22913, 'Лодейное Поле'),
(89152, 'Локомотивный'),
(88746, 'Локоть'),
(89118, 'Ломоносов'),
(99979, 'Лонг-Юган'),
(26978, 'Лопатино'),
(88956, 'Лопатинский'),
(88922, 'Лосино-Петровский'),
(99439, 'Лотошино'),
(99771, 'Луга'),
(88842, 'Луза'),
(88988, 'Лузино'),
(27665, 'Лукоянов'),
(27349, 'Лух'),
(99440, 'Луховицы'),
(88999, 'Лучегорск'),
(27563, 'Лысково'),
(89088, 'Лысогорская'),
(99758, 'Лысые Горы'),
(28234, 'Лысьва'),
(88923, 'Лыткарино'),
(88960, 'Львовский'),
(34101, 'Льгов'),
(99407, 'Любань'),
(99441, 'Люберцы'),
(88987, 'Любинский'),
(99305, 'Людиново'),
(88844, 'Лянгасово'),
(25913, 'Магадан'),
(31295, 'Магдагачи'),
(28838, 'Магнитогорск'),
(37479, 'Маджалис'),
(31443, 'Мазаново'),
(37021, 'Майкоп'),
(99731, 'Майма'),
(89163, 'Майртуп'),
(88803, 'Майский'),
(89011, 'Майский'),
(99705, 'Майя'),
(32116, 'Макаров'),
(27259, 'Макарьев'),
(27208, 'Максатиха'),
(28666, 'Макушино'),
(88951, 'Малаховка'),
(26184, 'Малая Вишера'),
(99549, 'Малая Сердоба'),
(88792, 'Малгобек'),
(99331, 'Малмыж'),
(99555, 'Малоархангельск'),
(27606, 'Малоярославец'),
(34662, 'Малые Дербеты'),
(20744, 'Малые Кармакулы'),
(89062, 'Малышева'),
(30157, 'Мама'),
(28508, 'Мамадыш'),
(26704, 'Мамоново'),
(99614, 'Мантурово'),
(26384, 'Марево'),
(29551, 'Мариинск'),
(89172, 'Мариинский Посад'),
(25551, 'Марково'),
(34173, 'Маркс'),
(88882, 'Марьянская'),
(29736, 'Маслянино'),
(34625, 'Матвеев Курган'),
(99564, 'Матвеевка'),
(37472, 'Махачкала'),
(89177, 'Мегион'),
(88908, 'Медведево'),
(88865, 'Медведовская'),
(22721, 'Медвежьегорск'),
(99605, 'Медвенка'),
(99422, 'Медногорск'),
(88731, 'Межгорье'),
(29854, 'Междуреченск'),
(99396, 'Междуреченский'),
(22471, 'Мезень'),
(99642, 'Меленки'),
(28925, 'Мелеуз'),
(99301, 'Менделеевск'),
(28517, 'Мензелинск'),
(99394, 'Меренга'),
(89162, 'Мескер-Юрт'),
(99739, 'Месягутово'),
(28647, 'Миасс'),
(88846, 'Микунь'),
(34438, 'Миллерово'),
(32496, 'Мильково'),
(37054, 'Минеральные Воды'),
(29866, 'Минусинск'),
(89147, 'Миньяр'),
(24726, 'Мирный'),
(27729, 'Михайлов'),
(99955, 'Михайловка (Волгогр.)'),
(28438, 'Михайловск (Свердл.)'),
(89073, 'Михайловск (Ставропольский край)'),
(88723, 'Михайловское (Алтайский край)'),
(89069, 'Михайловское (Сев. Осетия)'),
(27935, 'Мичуринск'),
(99733, 'Мишкино (Башкорт.)'),
(99609, 'Мишкино (Курган.)'),
(99838, 'Могойтуй'),
(30673, 'Могоча'),
(27509, 'Можайск'),
(28409, 'Можга'),
(37145, 'Моздок'),
(28566, 'Мокроусово'),
(27868, 'Мокшан'),
(29332, 'Молчаново'),
(99506, 'Монастырщина'),
(88949, 'Монино'),
(99897, 'Мончегорск'),
(99761, 'Мордово'),
(27498, 'Морки'),
(34545, 'Морозовск'),
(27848, 'Моршанск'),
(27704, 'Мосальск'),
(99571, 'Москаленки'),
(27612, 'Москва'),
(99379, 'Мостовской'),
(29276, 'Мотыгино'),
(29632, 'Мошково'),
(28928, 'Мраково'),
(36278, 'Мугур-Аксы'),
(23426, 'Мужи'),
(88980, 'Мулино'),
(99969, 'Муравленко'),
(27097, 'Мураши'),
(22113, 'Мурманск'),
(88973, 'Мурмаши'),
(27549, 'Муром'),
(99841, 'Муромцево'),
(28611, 'Муслюмово'),
(30837, 'Мухоршибирь'),
(27817, 'Мценск'),
(20476, 'Мыс Стерлигова'),
(25173, 'Мыс Шмидта'),
(99844, 'Мыски'),
(99449, 'Мытищи'),
(99460, 'Мышкин'),
(28507, 'Набережные Челны'),
(88979, 'Навашино'),
(26996, 'Навля'),
(88788, 'Наволоки'),
(28007, 'Нагорск'),
(88829, 'Надвоицы'),
(99981, 'Надым'),
(29561, 'Назарово'),
(99946, 'Назрань'),
(28588, 'Называевск'),
(37212, 'Нальчик'),
(24753, 'Намцы'),
(88729, 'Нариманов'),
(27611, 'Наро-Фоминск'),
(27853, 'Наровчат'),
(88806, 'Нартан'),
(88804, 'Нарткала'),
(99393, 'Нарым'),
(23205, 'Нарьян-Мар'),
(37157, 'Наурская'),
(88946, 'Нахабино'),
(31970, 'Находка'),
(99541, 'Невель'),
(32145, 'Невельск'),
(37036, 'Невинномысск'),
(28344, 'Невьянск'),
(89080, 'Незлобная'),
(99461, 'Некрасовское'),
(99493, 'Нелидово'),
(99615, 'Нема'),
(88815, 'Неман'),
(27336, 'Нерехта'),
(30768, 'Нерчинск'),
(30879, 'Нерчинский з-д'),
(99837, 'Нерюнгри'),
(88795, 'Нестеровская'),
(99395, 'Нефедова'),
(99421, 'Нефтегорск'),
(99975, 'Нефтекамск'),
(37071, 'Нефтекумск'),
(23848, 'Нефтеюганск'),
(88851, 'Нея'),
(30433, 'Нижнеангарск'),
(23471, 'Нижневартовск'),
(34121, 'Нижнедевицк'),
(88783, 'Нижнее Казанище'),
(99700, 'Нижнекамск'),
(29698, 'Нижнеудинск'),
(89049, 'Нижние Серги'),
(27856, 'Нижний Ломов'),
(27553, 'Нижний Новгород'),
(88848, 'Нижний Одес'),
(28240, 'Нижний Тагил'),
(30964, 'Нижний Цасучей'),
(89096, 'Нижняя Мактама'),
(99840, 'Нижняя Омка'),
(89050, 'Нижняя Салда'),
(28362, 'Нижняя Тавда'),
(89051, 'Нижняя Тура'),
(22004, 'Никель'),
(98999, 'Николаевск'),
(31369, 'Николаевск-на-Амуре'),
(27066, 'Никольск(Вологод.)'),
(99550, 'Никольск(Пенз.)'),
(88950, 'Никольско-Архангельский'),
(32618, 'Никольское (Камчат.)'),
(88898, 'Никольское (Ленингр.)'),
(99420, 'Новая Игирма'),
(89052, 'Новая Ляля'),
(88774, 'Новая Усмань'),
(26179, 'Новгород Великий'),
(34944, 'Новоалександровск'),
(88713, 'Новоалтайск'),
(34254, 'Новоаннинский'),
(99750, 'Новобелокатай'),
(29367, 'Новобирилюссы'),
(34126, 'Нововоронеж'),
(98915, 'Новодвинск'),
(98921, 'Новодеревянковская'),
(99966, 'Новозаполярный'),
(88742, 'Новозыбков'),
(99378, 'Новокубанск'),
(29846, 'Новокузнецк'),
(89028, 'Новокуйбышевск'),
(88874, 'Новоминская'),
(88860, 'Новомихайловский'),
(99392, 'Новомичуринск'),
(99482, 'Новомосковск'),
(98998, 'Новониколаевский'),
(30611, 'Новонукутский'),
(99783, 'Новоорск'),
(99663, 'Новопавловск'),
(99836, 'Новопокровка'),
(99670, 'Новопокровская'),
(37006, 'Новороссийск'),
(99660, 'Новоселицкое'),
(99856, 'Новоселово'),
(35015, 'Новосергиевка'),
(29634, 'Новосибирск'),
(88716, 'Новосиликатный'),
(99556, 'Новосиль'),
(99473, 'Новоспасское'),
(88861, 'Новотитаровская'),
(98953, 'Новотроицк'),
(34289, 'Новоузенск'),
(89135, 'Новоульяновск'),
(99337, 'Новоуральск'),
(34148, 'Новохоперск'),
(89173, 'Новочебоксарск'),
(99944, 'Новочеркасск'),
(29590, 'Новочунка'),
(89007, 'Новошахтинск'),
(99516, 'Новые Бурасы'),
(34213, 'Новый Оскол'),
(27491, 'Новый Торьял'),
(23358, 'Новый Уренгой'),
(99971, 'Ногинск'),
(89066, 'Ногир'),
(32053, 'Ноглики'),
(27393, 'Нолинск'),
(23078, 'Норильск'),
(99968, 'Ноябрьск'),
(99310, 'Нурлат'),
(23912, 'Ныроб'),
(99797, 'Нытва'),
(22974, 'Нюксеница'),
(24639, 'Нюрба'),
(23739, 'Нягань'),
(28533, 'Нязепетровск'),
(22854, 'Няндома'),
(34554, 'Обливская'),
(31702, 'Облучье'),
(99457, 'Обнинск'),
(34109, 'Обоянь'),
(88962, 'Обухово'),
(88983, 'Обь'),
(22996, 'Обьячево'),
(28797, 'Одесское'),
(99952, 'Одинцово'),
(88924, 'Ожерелье'),
(89120, 'Озерный'),
(99624, 'Озерск (Калинингр.)'),
(99349, 'Озерск (Челяб.)'),
(99443, 'Озеры'),
(34199, 'Озинки'),
(24688, 'Оймякон'),
(89155, 'Ойсхара'),
(99572, 'Оконешниково'),
(89029, 'Октябрьск'),
(88876, 'Октябрьская'),
(28714, 'Октябрьский (Башк.)'),
(88964, 'Октябрьский (Моск. обл.)'),
(28429, 'Октябрьский (Перм. край)'),
(99565, 'Октябрьское'),
(89068, 'Октябрьское'),
(23734, 'Октябрьское (Тюм.)'),
(28754, 'Октябрьское (Чел.)'),
(26283, 'Окуловка'),
(25912, 'Ола'),
(24944, 'Олекминск'),
(99896, 'Оленегорск'),
(24125, 'Оленек'),
(99494, 'Оленино'),
(30961, 'Оловянная'),
(22912, 'Олонец'),
(31995, 'Ольга'),
(99636, 'Ольховатка'),
(34362, 'Ольховка'),
(25428, 'Омолон'),
(28698, 'Омск'),
(25715, 'Омсукчан'),
(28109, 'Омутнинск'),
(36231, 'Онгудай'),
(22641, 'Онега'),
(88749, 'Онохой'),
(27083, 'Опарино'),
(26456, 'Опочка'),
(99792, 'Орда'),
(37234, 'Орджоникидзевская'),
(29726, 'Ордынское'),
(27906, 'Орел'),
(35121, 'Оренбург'),
(99972, 'Орехово-Зуево'),
(29998, 'Орлик'),
(89017, 'Орловский'),
(35138, 'Орск'),
(30615, 'Оса (Ирк.)'),
(28324, 'Оса (Перм.)'),
(88832, 'Осинники'),
(32246, 'Оссора'),
(26389, 'Осташков'),
(89003, 'Остров'),
(34223, 'Острогожск'),
(37035, 'Отрадная'),
(88899, 'Отрадное'),
(98896, 'Отрадный'),
(32010, 'Оха'),
(28321, 'Оханск'),
(31088, 'Охотск'),
(99798, 'Очер'),
(88967, 'п. Завода «Мосрентген»'),
(27823, 'Павелец'),
(27987, 'Павловка'),
(27555, 'Павлово'),
(88717, 'Павловск'),
(34237, 'Павловск'),
(99377, 'Павловская'),
(27523, 'Павловский Посад'),
(28798, 'Павлоградка'),
(32227, 'Палана'),
(25907, 'Палатка'),
(34373, 'Палласовка'),
(88982, 'Панковка'),
(29128, 'Парабель'),
(99714, 'Параньга'),
(31987, 'Партизанск'),
(99665, 'Партизанское'),
(99574, 'Парфино'),
(27858, 'Пачелма'),
(88854, 'Пашковский'),
(25051, 'Певек'),
(27962, 'Пенза'),
(99582, 'Первомайск(Нижегор.)'),
(35008, 'Первомайский (Оренб.)'),
(89091, 'Первомайский (Тамбов.)'),
(89129, 'Первомайский (Тульск.)'),
(89151, 'Первомайский (Челяб.)'),
(89170, 'Первомайский (Чит.)'),
(29348, 'Первомайское(Томск.)'),
(29761, 'Первомайское(Хакасия)'),
(99332, 'Первоуральск'),
(99587, 'Перевоз'),
(99982, 'Перегребное'),
(35007, 'Перелюб'),
(88925, 'Пересвет'),
(27425, 'Переславль-Залесский'),
(89140, 'Переяславка'),
(28225, 'Пермь'),
(89019, 'Персиановский'),
(99575, 'Пестово'),
(99523, 'Пестравка'),
(89023, 'Песчанокопское'),
(88761, 'Петров Вал'),
(34063, 'Петровск'),
(88288, 'Петровск (Яросл. обл.)'),
(30838, 'Петровск-Забайкальский'),
(88869, 'Петровская'),
(99495, 'Петровское'),
(22820, 'Петрозаводск'),
(30924, 'Петропавловка'),
(32540, 'Петропавловск-Камчатский'),
(28674, 'Петухово'),
(27526, 'Петушки'),
(99419, 'Печенга'),
(23418, 'Печора'),
(99542, 'Печоры'),
(88900, 'Пикалево'),
(22563, 'Пинега'),
(26607, 'Пионерский'),
(29363, 'Пировское'),
(99528, 'Пителино'),
(99515, 'Питерка'),
(88828, 'Питкяранта'),
(27814, 'Плавск'),
(28850, 'Пласт'),
(88875, 'Платнировская'),
(99630, 'Плес'),
(99653, 'Плесецк'),
(99562, 'Плешаново'),
(99543, 'Плюсса'),
(99637, 'Поворино'),
(99644, 'Погар'),
(31915, 'Пограничный'),
(99638, 'Подгоренский'),
(29237, 'Подгорное'),
(99576, 'Поддорье'),
(99970, 'Подольск'),
(22988, 'Подосиновец'),
(99778, 'Подпорожье'),
(88753, 'Покров'),
(99664, 'Покровка'),
(24856, 'Покровск'),
(89022, 'Покровское'),
(99557, 'Покровское'),
(88994, 'Полазна'),
(89053, 'Полевской'),
(99625, 'Полесск'),
(28668, 'Половинное'),
(28786, 'Полтавка'),
(99376, 'Полтавская'),
(88833, 'Полысаево'),
(88971, 'Полярные Зори'),
(22019, 'Полярный'),
(99566, 'Пономаревка'),
(34003, 'Поныри'),
(27675, 'Порецкое'),
(32098, 'Поронайск'),
(99538, 'Порхов'),
(88906, 'Посёлок имени Морозова'),
(88722, 'Поспелиха'),
(31969, 'Посьет'),
(99524, 'Похвистнево'),
(26986, 'Почеп'),
(27762, 'Починки'),
(26784, 'Починок'),
(27223, 'Пошехонье'),
(31587, 'Поярково'),
(99626, 'Правдинск'),
(88963, 'Правдинский'),
(89085, 'Прасковея'),
(99718, 'Преградная'),
(99759, 'Преображенская'),
(30975, 'Приаргунск'),
(89032, 'Прибрежный'),
(27344, 'Приволжск'),
(89034, 'Приволжский'),
(88771, 'Придонской'),
(34824, 'Приморско-Ахтарск'),
(22807, 'Приозерск'),
(99984, 'Приполярный'),
(88732, 'Приютово'),
(25594, 'Провидения Бухта'),
(88727, 'Прогресс'),
(99355, 'Прокопьевск'),
(34748, 'Пролетарск'),
(88835, 'Промышленная'),
(88926, 'Протвино'),
(37144, 'Прохладный'),
(99647, 'Прохоровка'),
(22816, 'Пряжа'),
(88859, 'Псебай'),
(26258, 'Псков'),
(34098, 'Пугачев'),
(22831, 'Пудож'),
(99544, 'Пустошка'),
(99627, 'Пучеж'),
(99448, 'Пушкино'),
(26359, 'Пушкинские Горы'),
(99329, 'Пущино'),
(26357, 'Пыталово'),
(99508, 'Пышма'),
(27174, 'Пыщуг'),
(37050, 'Пятигорск'),
(99470, 'Радищево'),
(88754, 'Радужный (Владимирск.)'),
(23758, 'Радужный (Тюмен.)'),
(28710, 'Раевский'),
(88737, 'Разумное'),
(99655, 'Райчихинск'),
(88741, 'Ракитное'),
(99447, 'Раменское'),
(89090, 'Рассказово'),
(29923, 'Ребриха'),
(28430, 'Ревда'),
(89119, 'Редкино'),
(99509, 'Реж'),
(34759, 'Ремонтное'),
(88927, 'Реутов'),
(89055, 'Рефтинский'),
(99496, 'Ржакса'),
(26498, 'Ржев'),
(99648, 'Ровеньки'),
(99780, 'Ровное'),
(99631, 'Родники'),
(99534, 'Романовская'),
(26882, 'Рославль'),
(34331, 'Россошь'),
(27329, 'Ростов'),
(34731, 'Ростов-на-Дону'),
(88928, 'Рошаль'),
(89031, 'Рощинский'),
(34056, 'Ртищево'),
(36034, 'Рубцовск'),
(34262, 'Рудня (Волгогр.)'),
(26678, 'Рудня(Смоленск.)'),
(99446, 'Руза'),
(88909, 'Рузаевка'),
(28895, 'Русская Поляна'),
(27975, 'Русский Камешкир'),
(99730, 'Рутул'),
(27225, 'Рыбинск'),
(99701, 'Рыбная Слобода'),
(99529, 'Рыбное'),
(33166, 'Рыльск'),
(27835, 'Ряжск'),
(27731, 'Рязань'),
(88798, 'Сагопши'),
(99560, 'Сакмара'),
(99418, 'Салават'),
(23330, 'Салехард'),
(34842, 'Сальск'),
(28900, 'Самара'),
(89025, 'Самарское'),
(89164, 'Самашки'),
(24652, 'Сангар'),
(26063, 'Санкт-Петербург'),
(27480, 'Санчурск'),
(99531, 'Сапожок'),
(27836, 'Сараи'),
(88990, 'Саракташ'),
(30605, 'Сарам'),
(27760, 'Саранск'),
(28418, 'Сарапул'),
(34172, 'Саратов'),
(28598, 'Саргатское'),
(99702, 'Сарманово'),
(99311, 'Саров'),
(36104, 'Сарыг-Сеп'),
(21802, 'Саскылах'),
(27745, 'Сасово'),
(99463, 'Сатка'),
(26686, 'Сафоново'),
(99851, 'Саяногорск'),
(30509, 'Саянск'),
(99623, 'Светлогорск (Калинингр.)'),
(34954, 'Светлоград'),
(89035, 'Светлый'),
(99622, 'Светлый (Калинингр.)'),
(99985, 'Светлый (Тюмен.)'),
(99767, 'Светлый Яр'),
(88901, 'Светогорск'),
(88801, 'Свирск'),
(31445, 'Свободный'),
(89076, 'Свободы'),
(99537, 'Себеж'),
(29418, 'Северное'),
(23986, 'Северо-Енисейский'),
(32215, 'Северо-Курильск'),
(30435, 'Северобайкальск'),
(22546, 'Северодвинск'),
(99417, 'Североморск'),
(23919, 'Североуральск'),
(89122, 'Северск'),
(99671, 'Северская'),
(22621, 'Сегежа'),
(29401, 'Седельниково'),
(25703, 'Сеймчан'),
(88748, 'Селенгинск'),
(28309, 'Селты'),
(88743, 'Сельцо'),
(27462, 'Семенов'),
(34636, 'Семикаракорск'),
(88769, 'Семилуки'),
(27891, 'Сенгилей'),
(34357, 'Серафимович'),
(88735, 'Серафимовский'),
(27577, 'Сергач'),
(99973, 'Сергиев Посад'),
(37475, 'Сергокала'),
(99551, 'Сердобск'),
(99589, 'Серебряные Пруды'),
(99715, 'Сернур'),
(28044, 'Серов'),
(27618, 'Серпухов'),
(88902, 'Сертолово'),
(99656, 'Серышево'),
(99584, 'Сеченово'),
(28935, 'Сибай'),
(88719, 'Сибирский'),
(28213, 'Сива'),
(88904, 'Сиверский'),
(89148, 'Сим'),
(30692, 'Сковородино'),
(99530, 'Скопин'),
(29915, 'Славгород'),
(89001, 'Славянка'),
(34924, 'Славянск-на-Кубани'),
(28587, 'Сладково'),
(99601, 'Сланцы'),
(88286, 'Слаутное'),
(99616, 'Слободской'),
(99846, 'Слюдянка'),
(31725, 'Смидович'),
(99813, 'Смирных'),
(26781, 'Смоленск'),
(28807, 'Смышляевка'),
(99998, 'Снежинск'),
(88972, 'Снежногорск'),
(23179, 'Снежногорск'),
(88755, 'Собинка'),
(32477, 'Соболево'),
(26614, 'Советск(Калинингр.)'),
(27391, 'Советск(Кировск.)'),
(31770, 'Советская Гавань'),
(23826, 'Советский'),
(89181, 'Сокол'),
(89086, 'Солдато-Александровское'),
(27143, 'Солигалич'),
(28026, 'Соликамск'),
(99768, 'Солнечногорск'),
(89077, 'Солнечнодольск'),
(88893, 'Солнечный (Краснояр.)'),
(31550, 'Солнечный (Хабар.)'),
(22429, 'Соловки'),
(35120, 'Соль-Илецк'),
(99776, 'Сольвычегодск'),
(88981, 'Сольцы'),
(88772, 'Сомово'),
(35011, 'Сорочинск'),
(89141, 'Сорск'),
(22802, 'Сортавала'),
(99978, 'Сорум'),
(88825, 'Сосенский'),
(99558, 'Сосково'),
(88843, 'Сосновка (Киров.)'),
(99497, 'Сосновка (Тамбов.)'),
(30745, 'Сосново-Озерское'),
(88889, 'Сосновоборск'),
(99416, 'Сосновый Бор'),
(99415, 'Сосногорск'),
(99986, 'Сосьва'),
(88954, 'Софрино'),
(37099, 'Сочи'),
(26795, 'Спас-Деменск'),
(99308, 'Спас-Клепики'),
(31926, 'Спасск-Дальний'),
(99309, 'Спасск-Рязанский'),
(25206, 'Среднеколымск'),
(89054, 'Среднеуральск'),
(99777, 'Средняя Ахтуба'),
(30777, 'Сретенск'),
(34949, 'Ставрополь'),
(88948, 'Старая Купавна'),
(26275, 'Старая Русса'),
(26499, 'Старица'),
(88870, 'Старовеличковская'),
(88871, 'Стародеревянковская'),
(26988, 'Стародуб'),
(27764, 'Старое Шайгово'),
(27734, 'Старожилово'),
(88878, 'Старокорсунская'),
(34729, 'Староминская'),
(88880, 'Старомышастовская'),
(88881, 'Старонижестеблиевская'),
(99746, 'Старосубхангулово'),
(88873, 'Старотитаровская'),
(88863, 'Старощербиновская'),
(99498, 'Староюрьево'),
(89167, 'Старые Атаги'),
(34116, 'Старый Оскол'),
(28827, 'Стерлибашево'),
(28825, 'Стерлитамак'),
(23952, 'Стрежевой'),
(88284, 'Стрельчиха'),
(88736, 'Строитель'),
(26264, 'Струги-Красные'),
(88756, 'Струнино'),
(99445, 'Ступино'),
(27717, 'Суворов'),
(89081, 'Суворовская'),
(88757, 'Судогда'),
(99641, 'Суздаль'),
(29823, 'Сузун'),
(99799, 'Суксун'),
(88784, 'Султан-Янги-Юрт');
INSERT INTO `k2_mod_weather_city` (`CODE`, `NAME`) VALUES
(99617, 'Суна'),
(89067, 'Сунжа'),
(24738, 'Сунтар'),
(22717, 'Суоярви'),
(99645, 'Сураж'),
(88283, 'Сургут (Самарск.)'),
(23849, 'Сургут (Тюмен.)'),
(98995, 'Суровикино'),
(27776, 'Сурское'),
(88797, 'Сурхахи'),
(24790, 'Сусуман'),
(27707, 'Сухиничи'),
(29477, 'Сухобузимское'),
(98950, 'Сухой Лог'),
(26462, 'Сущево'),
(88929, 'Сходня'),
(99299, 'Сывдарма'),
(27983, 'Сызрань'),
(23804, 'Сыктывкар'),
(28448, 'Сысерть'),
(26595, 'Сычевка'),
(99690, 'Сюмси'),
(88903, 'Сясьстрой'),
(28158, 'Таборы'),
(28264, 'Тавда'),
(28793, 'Таврическое'),
(34720, 'Таганрог'),
(23256, 'Тазовский'),
(29541, 'Тайга'),
(29594, 'Тайшет'),
(30356, 'Таксимо'),
(99442, 'Талдом'),
(99510, 'Талица'),
(88890, 'Талнах'),
(99635, 'Таловая'),
(88714, 'Тальменка'),
(99552, 'Тамала'),
(89182, 'Тамань'),
(20864, 'Тамбей'),
(27947, 'Тамбов'),
(99654, 'Тамбовка'),
(28493, 'Тара'),
(30826, 'Тарбагатай'),
(23552, 'Тарко-Сале'),
(22966, 'Тарногский Городок'),
(99721, 'Тарумовка'),
(29379, 'Тасеево'),
(29605, 'Татарск'),
(89024, 'Тацинская'),
(99559, 'Ташла'),
(29954, 'Таштагол'),
(29956, 'Таштып'),
(99375, 'Тбилисская'),
(27402, 'Тверь'),
(37193, 'Теберда'),
(28383, 'Тевриз'),
(29355, 'Тегульдет'),
(88789, 'Тейково'),
(27604, 'Темкино'),
(27752, 'Темников'),
(34915, 'Темрюк'),
(99710, 'Теньгушево'),
(99598, 'Тербуны'),
(99720, 'Терек'),
(37079, 'Терекли-Мектеб'),
(22028, 'Териберка'),
(31909, 'Терней'),
(37204, 'Терскол'),
(27697, 'Тетюши'),
(32293, 'Тигиль'),
(21824, 'Тикси'),
(99815, 'Тиличики'),
(34112, 'Тим'),
(34922, 'Тимашевск'),
(29557, 'Тисуль'),
(26094, 'Тихвин'),
(34838, 'Тихорецк'),
(37468, 'Тлярата'),
(28725, 'Тобольск'),
(88826, 'Товарково'),
(29636, 'Тогучин'),
(30127, 'Токма'),
(22908, 'Токсово'),
(99748, 'Толбазы'),
(27890, 'Тольятти'),
(99829, 'Томари'),
(88945, 'Томилино'),
(30439, 'Томпа'),
(24671, 'Томпо'),
(29430, 'Томск'),
(99583, 'Тоншаево'),
(36103, 'Тоора-Хем'),
(29641, 'Топки'),
(27758, 'Торбеево'),
(27401, 'Торжок'),
(26479, 'Торопец'),
(26078, 'Тосно'),
(27051, 'Тотьма'),
(88991, 'Тоцкое Второе'),
(99036, 'Трехгорный'),
(88930, 'Троицк (Моск.)'),
(28748, 'Троицк (Челяб.)'),
(88793, 'Троицкая'),
(23711, 'Троицко-Печорск'),
(31655, 'Троицкое'),
(88726, 'Троицкое'),
(88816, 'Троицкое'),
(26997, 'Трубчевск'),
(89000, 'Трудовое'),
(37018, 'Туапсе'),
(28359, 'Тугулым'),
(28712, 'Туймазы'),
(27719, 'Тула'),
(23815, 'Тулпан'),
(30504, 'Тулун'),
(88939, 'Тульский'),
(27636, 'Тума'),
(30664, 'Тунгокочен'),
(30576, 'Тупик'),
(24507, 'Тура'),
(36092, 'Туран'),
(28255, 'Туринск'),
(28353, 'Туринская Слобода'),
(99517, 'Турки'),
(36061, 'Турочак'),
(99847, 'Турунтаево'),
(23472, 'Туруханск'),
(27229, 'Тутаев'),
(23589, 'Тутончаны'),
(88953, 'Тучково'),
(32071, 'Тымовское'),
(30499, 'Тында'),
(99756, 'Тырныауз'),
(36078, 'Тэли'),
(28586, 'Тюкалинск'),
(88992, 'Тюльган'),
(99695, 'Тюлячи'),
(28367, 'Тюмень'),
(29456, 'Тюхтет'),
(29552, 'Тяжин'),
(30455, 'Уакит'),
(29613, 'Убинское'),
(99691, 'Ува'),
(99950, 'Уваровка'),
(99760, 'Уварово'),
(28172, 'Уват'),
(99464, 'Увельский'),
(32088, 'Углегорск'),
(88996, 'Углеуральский'),
(27321, 'Углич'),
(89037, 'Удачный'),
(88957, 'Удельная'),
(99339, 'Удомля'),
(29653, 'Ужур'),
(27821, 'Узловая'),
(99988, 'Узюм-Юган'),
(99800, 'Уинское'),
(98920, 'Уйское'),
(30823, 'Улан-Удэ'),
(30846, 'Улеты'),
(27805, 'Ульяново'),
(27786, 'Ульяновск'),
(22324, 'Умба'),
(26985, 'Унеча'),
(28302, 'Уни'),
(99481, 'Упорово'),
(23928, 'Урай'),
(23453, 'Уренгой'),
(98917, 'Урень'),
(28307, 'Уржум'),
(99723, 'Уркарах'),
(99947, 'Урус-Мартан'),
(99357, 'Уруссу'),
(34240, 'Урюпинск'),
(23410, 'Усинск'),
(99599, 'Усмань'),
(99801, 'Усолье'),
(30712, 'Усолье-Сибирское'),
(99672, 'Успенское'),
(99835, 'Уссурийск'),
(99785, 'Усть-Абакан'),
(30635, 'Усть-Баргузин'),
(99719, 'Усть-Джегута'),
(89012, 'Усть-Донецкий'),
(30117, 'Усть-Илимск'),
(28382, 'Усть-Ишим'),
(36044, 'Усть-Калманка'),
(32408, 'Усть-Камчатск'),
(36213, 'Усть-Кан'),
(30565, 'Усть-Каренга'),
(99338, 'Усть-Катав'),
(99795, 'Усть-Кишерть'),
(36229, 'Усть-Кокса'),
(23803, 'Усть-Кулом'),
(30320, 'Усть-Кут'),
(34937, 'Усть-Лабинск'),
(24966, 'Усть-Мая'),
(30385, 'Усть-Нюкжа'),
(24898, 'Усть-Омчуг'),
(30713, 'Усть-Ордынский'),
(29500, 'Усть-Тарка'),
(30514, 'Усть-Уда'),
(99732, 'Усть-Улаган'),
(23405, 'Усть-Цильма'),
(27106, 'Устюжна'),
(99724, 'Усухчай'),
(28722, 'Уфа'),
(23606, 'Ухта'),
(28736, 'Учалы'),
(99717, 'Учкекен'),
(25399, 'Уэлен'),
(29576, 'Уяр'),
(28202, 'Фаленки'),
(34005, 'Фатеж'),
(28826, 'Федоровка'),
(88744, 'Фокино (Брянская область)'),
(88998, 'Фокино (Приморский край)'),
(34356, 'Фролово'),
(88931, 'Фрязино'),
(88961, 'Фряново'),
(88790, 'Фурманов'),
(31735, 'Хабаровск'),
(88853, 'Хадыженск'),
(99694, 'Хандагайты'),
(88936, 'Ханская'),
(23933, 'Ханты-Мансийск'),
(34687, 'Харабали'),
(88766, 'Харовск'),
(37248, 'Хасавюрт'),
(99406, 'Хасан'),
(88812, 'Хасанья'),
(20891, 'Хатанга'),
(34083, 'Хвалынск'),
(26196, 'Хвойная'),
(99525, 'Хворостянка'),
(99728, 'Хив'),
(30844, 'Хилок'),
(99590, 'Химки'),
(99501, 'Хиславичи'),
(36090, 'Хову-Аксы'),
(26378, 'Холм'),
(99499, 'Холм-Жирковский'),
(22559, 'Холмогоры'),
(32128, 'Холмск'),
(88864, 'Холмская'),
(99606, 'Хомутовка'),
(89139, 'Хор'),
(30739, 'Хоринск'),
(31924, 'Хороль'),
(99405, 'Хоста'),
(88932, 'Хотьково'),
(30629, 'Хужир'),
(88278, 'Хулимсунт'),
(37369, 'Хунзах'),
(34747, 'Целина'),
(28752, 'Целинное'),
(99678, 'Цивильск'),
(34646, 'Цимлянск'),
(89159, 'Цоцин-Юрт'),
(99692, 'Чаа-Холь'),
(99640, 'Чагода'),
(36087, 'Чадан'),
(99787, 'Чайковский'),
(89021, 'Чалтырь'),
(99711, 'Чамзинка'),
(29602, 'Чаны'),
(89030, 'Чапаевск'),
(99302, 'Чаплыгин'),
(30372, 'Чара'),
(99611, 'Частоозерье'),
(99802, 'Частые'),
(99465, 'Чебаркуль'),
(27581, 'Чебоксары'),
(31469, 'Чегдомын'),
(88805, 'Чегем'),
(88809, 'Чегем Второй'),
(99343, 'Чегет'),
(99736, 'Чекмагуш'),
(28705, 'Челно-Вершины'),
(99414, 'Челюскин'),
(28642, 'Челябинск'),
(36058, 'Чемал'),
(99472, 'Чердаклы'),
(23914, 'Чердынь'),
(29963, 'Черемушки'),
(30617, 'Черемхово'),
(28702, 'Черемшан'),
(88984, 'Черепаново'),
(27113, 'Череповец'),
(37047, 'Черкесск'),
(28799, 'Черлак'),
(28128, 'Чермоз'),
(99834, 'Черниговка'),
(88933, 'Черноголовка'),
(89142, 'Черногорск'),
(28428, 'Чернушка'),
(34578, 'Черный Яр'),
(30766, 'Чернышевск'),
(98994, 'Чернышковский'),
(27815, 'Чернь'),
(88738, 'Чернянка'),
(26711, 'Черняховск'),
(25123, 'Черский'),
(34432, 'Чертково'),
(27538, 'Черусти'),
(99466, 'Чесма'),
(99435, 'Чехов'),
(37216, 'Чикола'),
(29702, 'Чистоозерное'),
(28602, 'Чистополь'),
(30758, 'Чита'),
(28721, 'Чишмы'),
(98934, 'Чкаловск'),
(21946, 'Чокурдах'),
(31939, 'Чугуевка'),
(26088, 'Чудово (Ленингр.)'),
(26173, 'Чудово (Новгор.)'),
(29625, 'Чулым'),
(31286, 'Чумикан'),
(88802, 'Чунский'),
(24768, 'Чурапча'),
(99786, 'Чусовой'),
(27157, 'Чухлома'),
(98954, 'Чыаппара'),
(27281, 'Шабалино'),
(99554, 'Шаблыкино'),
(36089, 'Шагонар'),
(28552, 'Шадринск'),
(89154, 'Шали '),
(29578, 'Шалинское'),
(88807, 'Шалушка'),
(28334, 'Шамары'),
(99737, 'Шаран'),
(99681, 'Шаркан'),
(28916, 'Шарлык'),
(29558, 'Шарыпово'),
(27271, 'Шарья'),
(99586, 'Шатки'),
(37351, 'Шатой'),
(28456, 'Шатрово'),
(99444, 'Шатура'),
(99591, 'Шаховская'),
(89038, 'Шахтерск'),
(34635, 'Шахты'),
(27373, 'Шахунья'),
(27842, 'Шацк'),
(36057, 'Шебалино'),
(99757, 'Шебекино'),
(88767, 'Шексна'),
(24329, 'Шелагонцы'),
(30711, 'Шелехов'),
(37168, 'Шелковская'),
(30874, 'Шелопугино'),
(99553, 'Шемышейка'),
(22768, 'Шенкурск'),
(98952, 'Шентала'),
(28791, 'Шербакуль'),
(98913, 'Шерегеш'),
(27514, 'Шереметьево'),
(89169, 'Шерловая Гора'),
(30862, 'Шилка'),
(27736, 'Шилово'),
(31442, 'Шимановск'),
(88724, 'Шипуново'),
(29756, 'Шира'),
(26072, 'Шлиссельбург'),
(89015, 'Шолоховский'),
(89174, 'Шумерля'),
(28655, 'Шумиха'),
(99500, 'Шумячи'),
(99857, 'Шушенское'),
(27441, 'Шуя'),
(89127, 'Щёкино'),
(99592, 'Щёлково'),
(99391, 'Щельяюр'),
(88935, 'Щербинка'),
(88895, 'Щигры'),
(88894, 'Щучье'),
(24766, 'Ытык-Кюёль'),
(25820, 'Эвенск'),
(25378, 'Эгвекинот'),
(88794, 'Экажево'),
(31329, 'Экимчан'),
(88941, 'Электрогорск'),
(99318, 'Электросталь'),
(88942, 'Электроугли'),
(34861, 'Элиста'),
(89138, 'Эльбан'),
(99344, 'Эльбрус'),
(34476, 'Эльтон'),
(99704, 'Эльхотово'),
(34175, 'Энгельс'),
(88938, 'Энем'),
(36307, 'Эрзин'),
(99633, 'Эртиль'),
(32363, 'Эссо'),
(88943, 'Юбилейный'),
(99980, 'Югорск'),
(99632, 'Южа'),
(32165, 'Южно-Курильск'),
(32150, 'Южно-Сахалинск'),
(88778, 'Южно-Сухокумск'),
(28745, 'Южноуральск'),
(88715, 'Южный'),
(89149, 'Южный Горняк'),
(99684, 'Юкаменское'),
(29536, 'Юрга'),
(28463, 'Юргинское'),
(99807, 'Юрла'),
(99390, 'Юровск'),
(27437, 'Юрьев-Польский'),
(88758, 'Юрьевец (Владимирск.)'),
(27355, 'Юрьевец (Иванов.)'),
(99412, 'Юрюзань'),
(34772, 'Юста'),
(99806, 'Юсьва'),
(88937, 'Яблоновский'),
(24796, 'Ягодное'),
(99673, 'Ядрин'),
(99752, 'Языково'),
(88995, 'Яйва'),
(31935, 'Яковлевка'),
(24959, 'Якутск'),
(23812, 'Якша'),
(99682, 'Якшур-Бодья'),
(28465, 'Ялуторовск'),
(99679, 'Яльчики'),
(99967, 'Ямбург'),
(28419, 'Янаул'),
(88799, 'Яндаре'),
(99680, 'Яр'),
(23341, 'Яр-Сале'),
(27385, 'Яранск'),
(22798, 'Яренск'),
(28366, 'Ярково'),
(99320, 'Яровое'),
(27331, 'Ярославль'),
(99951, 'Ярцево'),
(89128, 'Ясногорск'),
(88989, 'Ясный (Оренб.)'),
(99404, 'Ясный (Якутия)'),
(88944, 'Яхрома'),
(88836, 'Яшкино'),
(34866, 'Яшкуль'),
(29540, 'Яя');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_nav`
--

DROP TABLE IF EXISTS `k2_nav`;
CREATE TABLE IF NOT EXISTS `k2_nav` (
`ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_nav`
--

INSERT INTO `k2_nav` (`ID`, `NAME`) VALUES
(1, 'Постраничная навигация'),
(2, 'Путь  назад'),
(8, 'Верхнее меню'),
(9, 'Нижнее меню');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_permission_default`
--

DROP TABLE IF EXISTS `k2_permission_default`;
CREATE TABLE IF NOT EXISTS `k2_permission_default` (
  `TYPE` varchar(100) NOT NULL,
  `KEY` varchar(100) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `CHECKED` tinyint(1) NOT NULL DEFAULT '0',
  `SORT` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_permission_default`
--

INSERT INTO `k2_permission_default` (`TYPE`, `KEY`, `NAME`, `CHECKED`, `SORT`) VALUES
('ADMIN', 'INDEX', 'Вход в панель управления', 0, 10),
('USER', 'INDEX', 'Управление пользователями', 0, 20),
('SELECT', 'INDEX', 'Управление списками', 0, 30),
('TEMPLATE', 'INDEX', 'Редактирование дизайна, функционала, навигации, настройки', 0, 40),
('USER', 'GROUP', 'Управление группами', 0, 50),
('MODULE', 'CACHE', 'Управление модулем "Кэширование"', 0, 100),
('MODULE', 'CURRENCY', 'Управление модулем "Курс валют"', 0, 120),
('MODULE', 'WEATHER', 'Управление модулем "Прогноз погоды"', 0, 130),
('MODULE', 'SHOP', 'Управление модулем "Интернет-магазин"', 0, 140);

-- --------------------------------------------------------

--
-- Структура таблицы `k2_permission_type`
--

DROP TABLE IF EXISTS `k2_permission_type`;
CREATE TABLE IF NOT EXISTS `k2_permission_type` (
  `TYPE` varchar(50) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `SORT` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_permission_type`
--

INSERT INTO `k2_permission_type` (`TYPE`, `NAME`, `SORT`) VALUES
('ADMIN', 'Панель администратора', 10),
('SELECT', 'Списки', 20),
('USER', 'Пользователи', 30),
('TEMPLATE', 'Разработка', 40),
('MODULE', 'Модули', 50);

-- --------------------------------------------------------

--
-- Структура таблицы `k2_section`
--

DROP TABLE IF EXISTS `k2_section`;
CREATE TABLE IF NOT EXISTS `k2_section` (
`ID` int(11) NOT NULL,
  `ACTIVE` tinyint(4) NOT NULL DEFAULT '0',
  `NAME` varchar(255) NOT NULL DEFAULT '',
  `SORT` int(11) NOT NULL DEFAULT '0',
  `SITE` int(11) DEFAULT '0',
  `PARENT` int(11) DEFAULT '0',
  `FOLDER` varchar(255) NOT NULL DEFAULT '',
  `EXTERNAL` varchar(255) NOT NULL DEFAULT '',
  `URL` varchar(255) NOT NULL DEFAULT '',
  `LEVEL` int(11) NOT NULL DEFAULT '0',
  `DESIGN` smallint(6) DEFAULT '0',
  `DESIGN_SHOW` smallint(6) NOT NULL DEFAULT '0',
  `PERMISSION` tinyint(1) NOT NULL,
  `H1` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_section`
--

INSERT INTO `k2_section` (`ID`, `ACTIVE`, `NAME`, `SORT`, `SITE`, `PARENT`, `FOLDER`, `EXTERNAL`, `URL`, `LEVEL`, `DESIGN`, `DESIGN_SHOW`, `PERMISSION`, `H1`) VALUES
(1, 0, 'Главная', 0, 1, 0, 'home', '', '/home/', 0, 1, 1, 1, 'Печать на ткани, на футболках'),
(64, 1, 'О нас', 30, 1, 0, 'about', '', '/about/', 0, 0, 6, 0, ''),
(65, 1, 'Услуги', 40, 1, 0, 'service', '', '/service/', 0, 0, 6, 0, ''),
(46, 1, '234', 110, 1, 46, '234', '', '/234/234/', 1, 0, 2, 0, ''),
(66, 1, 'Оборудование', 50, 1, 0, 'ob', '', '/ob/', 0, 0, 6, 0, ''),
(67, 1, 'Продажа промо-продукции', 60, 1, 0, 'prodazha-promo-produkcii', '/prodazha-promo-produkcii/tekstil/', '/prodazha-promo-produkcii/', 0, 0, 6, 0, ''),
(68, 1, 'Портфолио', 70, 1, 0, 'portfolio', '', '/portfolio/', 0, 7, 7, 0, ''),
(69, 1, 'Прайс на печать по текстилю', 40, 1, 85, 'prajs-na-pechat-po-tekstilju', '', '/prajs/prajs-na-pechat-po-tekstilju/', 1, 0, 6, 0, 'Тарифы на печать по текстилю'),
(70, 1, 'Контакты', 100, 1, 0, 'contact', '', '/contact/', 0, 0, 6, 0, ''),
(71, 0, 'Отдел промо изделий и печати по текстилю', 10, 1, 64, 'otdel-promo-izdelij-i-pechati-po-tekstilju', '', '/about/otdel-promo-izdelij-i-pechati-po-tekstilju/', 1, 0, 6, 0, ''),
(72, 0, 'Отдел разработки и дизайна', 20, 1, 64, 'otdel-razrabotki-i-dizajna', '', '/about/otdel-razrabotki-i-dizajna/', 1, 0, 6, 0, ''),
(73, 0, 'Эксперементальный цех', 30, 1, 64, 'jeksperementalnij-ceh', '', '/about/jeksperementalnij-ceh/', 1, 0, 6, 0, ''),
(74, 0, 'Собственные марки, опт', 40, 1, 64, 'sobstvennie-marki-opt', '', '/about/sobstvennie-marki-opt/', 1, 0, 6, 0, ''),
(76, 0, 'Карта сайта', 20, 1, 0, 'site-map', '', '/site-map/', 0, 0, 6, 0, ''),
(77, 0, 'Страница не найдена', 10, 1, 0, 'page-not-found', '', '/page-not-found/', 0, 0, 6, 0, ''),
(82, 0, 'Заявка', 110, 1, 0, 'form', '', '/form/', 0, 0, 6, 0, ''),
(83, 0, 'Прайс вышивка', 120, 1, 0, 'prajs-vishivka', '', '/prajs-vishivka/', 0, 0, 6, 0, ''),
(85, 1, 'Прайсы', 80, 1, 0, 'prajs', 'http://printtextil.ru/prajs/prajs-na-pechat-po-tekstilju/', '/prajs/', 0, 0, 6, 0, ''),
(86, 1, 'Прайс на вышивку', 50, 1, 85, 'prajs-na-vishivku', '', '/prajs/prajs-na-vishivku/', 1, 0, 6, 0, ''),
(87, 0, 'Прайс по цифровой печати', 60, 1, 85, 'prajs-po-cifrovoj-pechati', '', '/prajs/prajs-po-cifrovoj-pechati/', 1, 0, 6, 0, ''),
(88, 0, 'Прайс на трафаретные рамы', 70, 1, 85, 'prajs-na-trafaretnie-rami', '', '/prajs/prajs-na-trafaretnie-rami/', 1, 0, 6, 0, ''),
(89, 0, 'Прайс на трафаретную сетку', 80, 1, 85, 'prajs-na-trafaretnuju-setku', '', '/prajs/prajs-na-trafaretnuju-setku/', 1, 0, 6, 0, ''),
(91, 0, 'Прайс на фотовывод и натяжку сетки', 90, 1, 85, 'prajs-na-fotovivod-i-natjazhku-setki2', '', '/prajs/prajs-na-fotovivod-i-natjazhku-setki2/', 1, 0, 6, 0, ''),
(92, 1, 'Прайс на интерьерную печать', 20, 1, 85, 'prajs-na-interernuju-pechat', '', '/prajs/prajs-na-interernuju-pechat/', 1, 0, 6, 0, ''),
(93, 0, ' Прайс на трафаретную печать', 10, 1, 85, 'prajs-na-trafaretnuju-pechat', '', '/prajs/prajs-na-trafaretnuju-pechat/', 1, 0, 6, 0, ''),
(94, 1, 'Текстиль', 0, 1, 67, 'tekstil', '', '/prodazha-promo-produkcii/tekstil/', 1, 0, 6, 0, ''),
(95, 1, 'Изделия для записей', 10, 1, 67, 'izdelija-dlja-zapisej', '', '/prodazha-promo-produkcii/izdelija-dlja-zapisej/', 1, 0, 6, 0, ''),
(98, 1, 'Прайс на цифровую печать', 0, 1, 85, 'prajs-na-cifrovuju-pechat', '', '/prajs/prajs-na-cifrovuju-pechat/', 1, 0, 6, 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_section_block`
--

DROP TABLE IF EXISTS `k2_section_block`;
CREATE TABLE IF NOT EXISTS `k2_section_block` (
`ID` int(11) NOT NULL,
  `SECTION` int(11) DEFAULT NULL,
  `BLOCK` int(11) DEFAULT NULL,
  `ACTIVE` tinyint(4) NOT NULL DEFAULT '1',
  `NAME` varchar(255) NOT NULL DEFAULT '',
  `SORT` smallint(6) DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=90 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_section_block`
--

INSERT INTO `k2_section_block` (`ID`, `SECTION`, `BLOCK`, `ACTIVE`, `NAME`, `SORT`) VALUES
(53, 77, 1, 1, 'Текстовая страница', 0),
(54, 1, 6, 1, 'Услуги', 20),
(55, 1, 26, 1, 'О компании', 30),
(56, 65, 27, 1, 'Услуги', 0),
(57, 66, 28, 1, 'Оборудование', 0),
(58, 1, 29, 1, 'Наши возможности', 40),
(59, 1, 30, 1, 'Наши клиенты', 60),
(60, 67, 1, 1, 'Текстовая страница', 20),
(61, 67, 31, 1, 'Слайдшоу', 10),
(62, 68, 32, 1, 'Портфолио', 0),
(63, 70, 1, 1, 'Текстовая страница', 0),
(64, 69, 33, 1, 'Тарифы на печать', 0),
(65, 82, 34, 1, 'Заявка', 0),
(66, 69, 1, 1, 'Текстовая страница', 10),
(67, 64, 1, 1, 'Текстовая страница', 0),
(68, 83, 33, 1, 'Тарифы на печать', 0),
(69, 72, 1, 1, 'Текстовая страница', 0),
(71, 86, 1, 1, 'Текстовая страница', 0),
(72, 76, 2, 1, 'Карта сайта', 0),
(73, 87, 1, 1, 'Текстовая страница', 0),
(74, 88, 1, 1, 'Текстовая страница', 0),
(75, 89, 1, 1, 'Текстовая страница', 0),
(79, 1, 35, 1, 'Нам доверяют', 50),
(77, 91, 1, 1, 'Текстовая страница', 0),
(80, 1, 36, 1, 'Слайдер', 10),
(81, 92, 1, 1, 'Текстовая страница', 0),
(82, 93, 1, 1, 'Текстовая страница', 0),
(84, 94, 1, 1, 'Текстовая страница', 0),
(85, 95, 1, 1, 'Текстовая страница', 0),
(89, 98, 1, 1, 'Текстовая страница', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `k2_select`
--

DROP TABLE IF EXISTS `k2_select`;
CREATE TABLE IF NOT EXISTS `k2_select` (
`ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL DEFAULT '',
  `FIELD_SORT` varchar(4) DEFAULT '0',
  `METHOD_SORT` varchar(4) DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_select`
--

INSERT INTO `k2_select` (`ID`, `NAME`, `FIELD_SORT`, `METHOD_SORT`) VALUES
(6, 'Тираж', 'ID', 'ASC'),
(7, 'Цвета', 'ID', 'ASC'),
(8, 'Формат', 'ID', 'ASC'),
(9, 'Эффект', 'ID', 'ASC');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_select_option`
--

DROP TABLE IF EXISTS `k2_select_option`;
CREATE TABLE IF NOT EXISTS `k2_select_option` (
`ID` int(11) NOT NULL,
  `SELECT` int(11) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_select_option`
--

INSERT INTO `k2_select_option` (`ID`, `SELECT`, `NAME`) VALUES
(38, 6, '100'),
(37, 6, '50'),
(39, 6, '200'),
(40, 6, '300'),
(41, 6, '500'),
(42, 6, '700'),
(43, 6, '1000'),
(44, 6, '2000'),
(45, 6, '5000'),
(46, 7, '1'),
(47, 7, '2'),
(48, 7, '3'),
(49, 7, '4'),
(50, 7, '5'),
(51, 7, '6'),
(52, 7, '7'),
(53, 7, '8'),
(54, 7, '9'),
(55, 7, '10'),
(56, 8, 'Меньше А4'),
(57, 8, 'А4'),
(58, 8, 'А3'),
(59, 9, 'Золото'),
(60, 9, 'Серебро'),
(61, 9, 'Пуф'),
(62, 9, 'Глиттер (Лак)'),
(63, 9, 'Кожа'),
(64, 9, 'Замша'),
(65, 9, 'Вытравка');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_setting`
--

DROP TABLE IF EXISTS `k2_setting`;
CREATE TABLE IF NOT EXISTS `k2_setting` (
  `TYPE` varchar(50) NOT NULL DEFAULT '',
  `SETTING` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_setting`
--

INSERT INTO `k2_setting` (`TYPE`, `SETTING`) VALUES
('AUTH_TIME', '525600'),
('AUTH_UNUQ_EMAIL', '1'),
('DEBUG_PANEL', '0');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_site`
--

DROP TABLE IF EXISTS `k2_site`;
CREATE TABLE IF NOT EXISTS `k2_site` (
`ID` int(11) NOT NULL,
  `ACTIVE` tinyint(4) NOT NULL DEFAULT '0',
  `NAME` varchar(255) DEFAULT NULL,
  `DOMAIN` varchar(255) DEFAULT NULL,
  `DESIGN` int(11) DEFAULT NULL,
  `ALIAS` text NOT NULL,
  `SECTION_INDEX` int(11) DEFAULT NULL,
  `SECTION_NOT_FOUND` int(11) DEFAULT NULL,
  `PERMISSION` tinyint(1) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `PHONE` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_site`
--

INSERT INTO `k2_site` (`ID`, `ACTIVE`, `NAME`, `DOMAIN`, `DESIGN`, `ALIAS`, `SECTION_INDEX`, `SECTION_NOT_FOUND`, `PERMISSION`, `EMAIL`, `ADDRESS`, `PHONE`) VALUES
(1, 1, 'APrint', 'printtextil.ru', 6, '', 1, 77, 0, 'president@printtextil.com', 'Ростов-на-Дону, ул. Вавилова 53', '<font color="red" size="3">По всем вопросам звонить: <br/><b>+ 7 (863) 204 32 54 | 204 32 55 | 204 32 56</b><br>e-mail: <a href="mailto:zakaz@printtextil.com">zakaz@printtextil.com</a></font>');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_system`
--

DROP TABLE IF EXISTS `k2_system`;
CREATE TABLE IF NOT EXISTS `k2_system` (
  `VERSION` varchar(5) NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `LAST_CONNECT` datetime NOT NULL,
  `VERSION_KEY` char(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8

;

--
-- Дамп данных таблицы `k2_system`
--

INSERT INTO `k2_system` (`VERSION`, `DATE_UPDATE`, `LAST_CONNECT`, `VERSION_KEY`) VALUES
('3.1', '2011-08-12 00:48:01', '2011-08-12 00:48:01', '2');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_template`
--

DROP TABLE IF EXISTS `k2_template`;
CREATE TABLE IF NOT EXISTS `k2_template` (
`ID` int(11) NOT NULL,
  `OBJECT` smallint(6) NOT NULL,
  `OBJECT_ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `FILE` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_template`
--

INSERT INTO `k2_template` (`ID`, `OBJECT`, `OBJECT_ID`, `NAME`, `FILE`) VALUES
(1, 1, 22, '123123', '123123.php'),
(5, 1, 23, 'dfgfdg', 'dfgfdg.php'),
(6, 1, 25, 'asd', 'asd.php'),
(7, 1, 26, 'Форма', 'form.php');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_user`
--

DROP TABLE IF EXISTS `k2_user`;
CREATE TABLE IF NOT EXISTS `k2_user` (
`ID` int(11) NOT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_CHANGE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_CREATED` int(11) NOT NULL DEFAULT '0',
  `USER_CHANGE` int(11) NOT NULL DEFAULT '0',
  `ACTIVE` tinyint(4) NOT NULL DEFAULT '0',
  `LOGIN` varchar(50) DEFAULT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `PASSWORD` char(32) DEFAULT NULL,
  `HASH` char(32) NOT NULL DEFAULT '',
  `RESTORE` char(20) NOT NULL,
  `USER_GROUP` smallint(6) DEFAULT '2'
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_user`
--

INSERT INTO `k2_user` (`ID`, `DATE_CREATED`, `DATE_CHANGE`, `USER_CREATED`, `USER_CHANGE`, `ACTIVE`, `LOGIN`, `EMAIL`, `PASSWORD`, `HASH`, `RESTORE`, `USER_GROUP`) VALUES
(1, '2011-06-05 08:33:36', '2014-04-25 13:36:10', 1, 1, 1, 'admin', 'wsandreiko@gmail.com', '72017afb8e6fe7be40f02e4c14ffa8f2', 'b141b21e0830ed0783fa5b3972bd5912', '', 1),
(48, '2014-10-22 07:53:11', '0000-00-00 00:00:00', 1, 0, 1, 'manager', 'nik-and-kristi@yandex.ru', 'd01b0b7b98dd8e98f61d83e40a68e832', '', '', 1),
(49, '2014-10-30 11:11:30', '0000-00-00 00:00:00', 1, 0, 1, 'kosmos', 'wizardshadow@yandex.ru', '2ffd877e9ccc8b2c490d4a9647ac7dd0', '', '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `k2_user_group`
--

DROP TABLE IF EXISTS `k2_user_group`;
CREATE TABLE IF NOT EXISTS `k2_user_group` (
`ID` smallint(11) NOT NULL,
  `NAME` varchar(255) NOT NULL DEFAULT '',
  `PERMISSION_DEFAULT` text NOT NULL,
  `PERMISSION_SITE` text NOT NULL,
  `PERMISSION_SECTION` mediumtext NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_user_group`
--

INSERT INTO `k2_user_group` (`ID`, `NAME`, `PERMISSION_DEFAULT`, `PERMISSION_SITE`, `PERMISSION_SECTION`) VALUES
(1, 'Администраторы', 'a:5:{s:5:"ADMIN";a:1:{s:5:"INDEX";s:1:"1";}s:6:"SELECT";a:1:{s:5:"INDEX";s:1:"1";}s:4:"USER";a:2:{s:5:"INDEX";s:1:"1";s:5:"GROUP";s:1:"1";}s:8:"TEMPLATE";a:1:{s:5:"INDEX";s:1:"1";}s:6:"MODULE";a:3:{s:5:"CACHE";s:1:"1";s:8:"CURRENCY";s:1:"1";s:7:"WEATHER";s:1:"1";}}', 'N;', 'N;'),
(2, 'Зарегистрированные пользователи', 'a:1:{s:4:"USER";a:1:{s:5:"INDEX";s:1:"1";}}', 'a:0:{}', 'a:0:{}');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_user_setting`
--

DROP TABLE IF EXISTS `k2_user_setting`;
CREATE TABLE IF NOT EXISTS `k2_user_setting` (
  `USER` int(11) NOT NULL,
  `ACTION` varchar(50) NOT NULL,
  `DATA` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_user_setting`
--

INSERT INTO `k2_user_setting` (`USER`, `ACTION`, `DATA`) VALUES
(1, 'SITE_ACTIVE', '1'),
(3, 'SITE_ACTIVE', '1'),
(1, 'FM_PARENT', '23');

-- --------------------------------------------------------

--
-- Структура таблицы `k2_user_setting_view`
--

DROP TABLE IF EXISTS `k2_user_setting_view`;
CREATE TABLE IF NOT EXISTS `k2_user_setting_view` (
  `USER` int(11) NOT NULL DEFAULT '0',
  `TYPE` tinyint(1) NOT NULL,
  `OBJECT` smallint(6) NOT NULL,
  `DEFAULT` tinyint(1) DEFAULT '0',
  `PREVIEW` tinyint(1) NOT NULL,
  `DATA` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `k2_user_setting_view`
--

INSERT INTO `k2_user_setting_view` (`USER`, `TYPE`, `OBJECT`, `DEFAULT`, `PREVIEW`, `DATA`) VALUES
(1, 10, 0, 0, 0, 'a:10:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:5:"LOGIN";a:4:{s:4:"NAME";s:10:"Логин";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"EMAIL";a:4:{s:4:"NAME";s:6:"E-mail";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:10:"USER_GROUP";a:4:{s:4:"NAME";s:12:"Группа";s:6:"FORMAT";s:10:"USER_GROUP";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"PHOTO";a:4:{s:4:"NAME";s:8:"Фото";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}}'),
(1, 1, 3, 0, 0, 'a:13:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"NAME";a:4:{s:4:"NAME";s:16:"Название";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:4:"TEXT";a:4:{s:4:"NAME";s:31:"Краткое описание";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:9:"TEXT_FULL";a:4:{s:4:"NAME";s:29:"Полное описание";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:5:"PHOTO";a:4:{s:4:"NAME";s:16:"Картинка";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:13:"USER_RELATION";a:4:{s:4:"NAME";s:13:"USER_RELATION";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:16:"SECTION_RELATION";a:4:{s:4:"NAME";s:16:"SECTION_RELATION";s:6:"FORMAT";s:7:"SECTION";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}}'),
(1, 2, 1, 0, 0, 'a:8:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:4:"NAME";a:4:{s:4:"NAME";s:16:"Название";s:6:"FORMAT";s:13:"CATEGORY_NAME";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}}'),
(1, 1, 25, 0, 0, 'a:15:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"TEXT";a:4:{s:4:"NAME";s:4:"TEXT";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"MULTI_SELECT";a:4:{s:4:"NAME";s:12:"MULTI_SELECT";s:6:"FORMAT";s:6:"SELECT";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:8:"RELATION";a:4:{s:4:"NAME";s:8:"RELATION";s:6:"FORMAT";s:7:"SECTION";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:8:"TEXTAREA";a:4:{s:4:"NAME";s:8:"TEXTAREA";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:6:"HIDDEN";a:4:{s:4:"NAME";s:6:"HIDDEN";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:4:"TORF";a:4:{s:4:"NAME";s:4:"TORF";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:11:"MULTI_PHOTO";a:4:{s:4:"NAME";s:11:"MULTI_PHOTO";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:4:"DATE";a:4:{s:4:"NAME";s:4:"DATE";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}}'),
(1, 1, 6, 0, 0, 'a:11:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"NAME";a:4:{s:4:"NAME";s:16:"Название";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"PHOTO";a:4:{s:4:"NAME";s:16:"Картинка";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:4:"LINK";a:4:{s:4:"NAME";s:12:"Ссылка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:5:"CLASS";a:4:{s:4:"NAME";s:14:"CSS Класс";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}'),
(1, 1, 26, 0, 0, 'a:8:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"TEXT";a:4:{s:4:"NAME";s:8:"Тест";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}}'),
(1, 1, 27, 0, 0, 'a:12:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"NAME";a:4:{s:4:"NAME";s:16:"Название";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"PHOTO";a:4:{s:4:"NAME";s:16:"Картинка";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:4:"TEXT";a:4:{s:4:"NAME";s:31:"Краткое описание";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:9:"TEXT_FULL";a:4:{s:4:"NAME";s:35:"Подробное описание";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:5:"CLASS";a:4:{s:4:"NAME";s:14:"CSS Класс";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}'),
(1, 1, 2, 0, 1, 'a:11:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:5:"PHOTO";a:4:{s:4:"NAME";s:22:"Фотогалерея";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"AGENT";a:4:{s:4:"NAME";s:10:"Агент";s:6:"FORMAT";s:6:"SELECT";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"PHONE";a:4:{s:4:"NAME";s:14:"Телефон";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:5:"EMAIL";a:4:{s:4:"NAME";s:16:"Эл. почта";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}'),
(1, 1, 7, 0, 0, 'a:14:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"NAME";a:4:{s:4:"NAME";s:6:"ФИО";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"PHONE";a:4:{s:4:"NAME";s:35:"Контактный телефон";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"EMAIL";a:4:{s:4:"NAME";s:6:"E-mail";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:3:"CH1";a:4:{s:4:"NAME";s:65:"Хочу продать дом/земельный участок ";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:3:"CH2";a:4:{s:4:"NAME";s:63:"Хочу купить дом/земельный участок ";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:3:"CH3";a:4:{s:4:"NAME";s:61:"Нужна помощь в оформлении сделки ";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:3:"CH4";a:4:{s:4:"NAME";s:60:"Пока не знаю, чем вы мне поможете!";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}'),
(1, 1, 28, 0, 0, 'a:10:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"NAME";a:4:{s:4:"NAME";s:16:"Название";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"PHOTO";a:4:{s:4:"NAME";s:16:"Картинка";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:4:"TEXT";a:4:{s:4:"NAME";s:16:"Описание";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}'),
(1, 1, 30, 0, 1, 'a:9:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:5:"PHOTO";a:4:{s:4:"NAME";s:16:"Картинка";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:4:"LINK";a:4:{s:4:"NAME";s:12:"Ссылка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}'),
(1, 1, 1, 0, 0, 'a:8:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"TEXT";a:4:{s:4:"NAME";s:10:"Текст";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}'),
(1, 1, 31, 0, 1, 'a:8:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:5:"PHOTO";a:4:{s:4:"NAME";s:16:"Картинка";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}}'),
(1, 1, 32, 0, 0, 'a:9:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"NAME";a:4:{s:4:"NAME";s:16:"Название";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"PHOTO";a:4:{s:4:"NAME";s:16:"Картинки";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}'),
(1, 1, 33, 0, 0, 'a:9:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"NAME";a:4:{s:4:"NAME";s:16:"Название";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:6:"MATRIX";a:4:{s:4:"NAME";s:14:"Матрица";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}'),
(1, 1, 34, 0, 0, 'a:12:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"NAME";a:4:{s:4:"NAME";s:6:"ФИО";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:7:"COMPANY";a:4:{s:4:"NAME";s:16:"Компания";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"PHONE";a:4:{s:4:"NAME";s:14:"Телефон";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:5:"EMAIL";a:4:{s:4:"NAME";s:5:"Email";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:3:"PAR";a:4:{s:4:"NAME";s:31:"Параметры заказа";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}'),
(1, 1, 35, 0, 1, 'a:9:{s:2:"ID";a:4:{s:4:"NAME";s:2:"ID";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:1;}s:6:"ACTIVE";a:4:{s:4:"NAME";s:20:"Активность";s:6:"FORMAT";s:4:"TORF";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:4:"SORT";a:4:{s:4:"NAME";s:20:"Сортировка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}s:12:"DATE_CREATED";a:4:{s:4:"NAME";s:25:"Дата создания";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"DATE_CHANGE";a:4:{s:4:"NAME";s:27:"Дата изменения";s:6:"FORMAT";s:4:"DATE";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:12:"USER_CREATED";a:4:{s:4:"NAME";s:21:"Кем создана";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:11:"USER_CHANGE";a:4:{s:4:"NAME";s:23:"Кем изменена";s:6:"FORMAT";s:4:"USER";s:5:"ALIGN";s:6:"center";s:6:"ACTIVE";i:0;}s:5:"PHOTO";a:4:{s:4:"NAME";s:16:"Картинка";s:6:"FORMAT";s:4:"FILE";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:1;}s:4:"LINK";a:4:{s:4:"NAME";s:12:"Ссылка";s:6:"FORMAT";s:0:"";s:5:"ALIGN";s:4:"left";s:6:"ACTIVE";i:0;}}');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `k2_block`
--
ALTER TABLE `k2_block`
 ADD PRIMARY KEY (`ID`), ADD KEY `BLOCK_GROUP` (`BLOCK_GROUP`), ADD KEY `CATEGORY` (`CATEGORY`);

--
-- Индексы таблицы `k2_block1`
--
ALTER TABLE `k2_block1`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block1category`
--
ALTER TABLE `k2_block1category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block2`
--
ALTER TABLE `k2_block2`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block2category`
--
ALTER TABLE `k2_block2category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block6`
--
ALTER TABLE `k2_block6`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block6category`
--
ALTER TABLE `k2_block6category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block7`
--
ALTER TABLE `k2_block7`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block7category`
--
ALTER TABLE `k2_block7category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block26`
--
ALTER TABLE `k2_block26`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block26category`
--
ALTER TABLE `k2_block26category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block27`
--
ALTER TABLE `k2_block27`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block27category`
--
ALTER TABLE `k2_block27category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block28`
--
ALTER TABLE `k2_block28`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block28category`
--
ALTER TABLE `k2_block28category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block29`
--
ALTER TABLE `k2_block29`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block29category`
--
ALTER TABLE `k2_block29category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block30`
--
ALTER TABLE `k2_block30`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block30category`
--
ALTER TABLE `k2_block30category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block31`
--
ALTER TABLE `k2_block31`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block31category`
--
ALTER TABLE `k2_block31category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block32`
--
ALTER TABLE `k2_block32`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block32category`
--
ALTER TABLE `k2_block32category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block33`
--
ALTER TABLE `k2_block33`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block33category`
--
ALTER TABLE `k2_block33category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block34`
--
ALTER TABLE `k2_block34`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block34category`
--
ALTER TABLE `k2_block34category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block35`
--
ALTER TABLE `k2_block35`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block35category`
--
ALTER TABLE `k2_block35category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block36`
--
ALTER TABLE `k2_block36`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block36category`
--
ALTER TABLE `k2_block36category`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_block_group`
--
ALTER TABLE `k2_block_group`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_component`
--
ALTER TABLE `k2_component`
 ADD PRIMARY KEY (`ID`), ADD KEY `COMPONENT_GROUP` (`COMPONENT_GROUP`), ADD KEY `CATEGORY` (`CATEGORY`);

--
-- Индексы таблицы `k2_component_field`
--
ALTER TABLE `k2_component_field`
 ADD PRIMARY KEY (`COMPONENT`,`FIELD`,`COLLECTION`);

--
-- Индексы таблицы `k2_component_group`
--
ALTER TABLE `k2_component_group`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_design`
--
ALTER TABLE `k2_design`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_field`
--
ALTER TABLE `k2_field`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_field_separator`
--
ALTER TABLE `k2_field_separator`
 ADD PRIMARY KEY (`ID`), ADD KEY `OBJECT` (`TABLE`,`OBJECT`);

--
-- Индексы таблицы `k2_file`
--
ALTER TABLE `k2_file`
 ADD PRIMARY KEY (`ID`), ADD KEY `USER` (`USER`);

--
-- Индексы таблицы `k2_file_dir`
--
ALTER TABLE `k2_file_dir`
 ADD PRIMARY KEY (`ID`), ADD KEY `USER` (`USER`);

--
-- Индексы таблицы `k2_module`
--
ALTER TABLE `k2_module`
 ADD PRIMARY KEY (`MODULE`), ADD KEY `ACTIVE` (`ACTIVE`);

--
-- Индексы таблицы `k2_mod_currency`
--
ALTER TABLE `k2_mod_currency`
 ADD UNIQUE KEY `CODE` (`CODE`);

--
-- Индексы таблицы `k2_mod_email`
--
ALTER TABLE `k2_mod_email`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `TYPE` (`TYPE`);

--
-- Индексы таблицы `k2_mod_seo`
--
ALTER TABLE `k2_mod_seo`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_mod_shop_address`
--
ALTER TABLE `k2_mod_shop_address`
 ADD UNIQUE KEY `USER` (`ID`);

--
-- Индексы таблицы `k2_mod_shop_cart`
--
ALTER TABLE `k2_mod_shop_cart`
 ADD PRIMARY KEY (`ID`), ADD KEY `USER` (`USER`), ADD KEY `CODE` (`CODE`);

--
-- Индексы таблицы `k2_mod_shop_delivery`
--
ALTER TABLE `k2_mod_shop_delivery`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_mod_shop_handler`
--
ALTER TABLE `k2_mod_shop_handler`
 ADD UNIQUE KEY `HANDLER` (`HANDLER`);

--
-- Индексы таблицы `k2_mod_shop_order`
--
ALTER TABLE `k2_mod_shop_order`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_mod_shop_order_product`
--
ALTER TABLE `k2_mod_shop_order_product`
 ADD PRIMARY KEY (`ID`), ADD KEY `SHOP_ORDER` (`SHOP_ORDER`);

--
-- Индексы таблицы `k2_mod_shop_payer`
--
ALTER TABLE `k2_mod_shop_payer`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_mod_shop_payer1`
--
ALTER TABLE `k2_mod_shop_payer1`
 ADD PRIMARY KEY (`ID`), ADD KEY `SHOP_ORDER` (`SHOP_ORDER`);

--
-- Индексы таблицы `k2_mod_shop_payer2`
--
ALTER TABLE `k2_mod_shop_payer2`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_mod_shop_payment`
--
ALTER TABLE `k2_mod_shop_payment`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_mod_shop_status`
--
ALTER TABLE `k2_mod_shop_status`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_mod_weather_city`
--
ALTER TABLE `k2_mod_weather_city`
 ADD PRIMARY KEY (`CODE`);

--
-- Индексы таблицы `k2_nav`
--
ALTER TABLE `k2_nav`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_permission_default`
--
ALTER TABLE `k2_permission_default`
 ADD KEY `TYPE` (`TYPE`), ADD KEY `KEY` (`KEY`);

--
-- Индексы таблицы `k2_section`
--
ALTER TABLE `k2_section`
 ADD PRIMARY KEY (`ID`), ADD KEY `ACTIVE` (`ACTIVE`), ADD KEY `URL` (`URL`), ADD KEY `PARENT` (`PARENT`), ADD KEY `SITE` (`SITE`);

--
-- Индексы таблицы `k2_section_block`
--
ALTER TABLE `k2_section_block`
 ADD PRIMARY KEY (`ID`), ADD KEY `SECTION` (`SECTION`), ADD KEY `BLOCK` (`BLOCK`), ADD KEY `ACTIVE` (`ACTIVE`);

--
-- Индексы таблицы `k2_select`
--
ALTER TABLE `k2_select`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_select_option`
--
ALTER TABLE `k2_select_option`
 ADD PRIMARY KEY (`ID`), ADD KEY `SELECT` (`SELECT`);

--
-- Индексы таблицы `k2_setting`
--
ALTER TABLE `k2_setting`
 ADD UNIQUE KEY `TYPE` (`TYPE`);

--
-- Индексы таблицы `k2_site`
--
ALTER TABLE `k2_site`
 ADD PRIMARY KEY (`ID`), ADD KEY `ACTIVE` (`ACTIVE`);

--
-- Индексы таблицы `k2_template`
--
ALTER TABLE `k2_template`
 ADD PRIMARY KEY (`ID`), ADD KEY `OBJECT` (`OBJECT`), ADD KEY `OBJECT_ID` (`OBJECT_ID`);

--
-- Индексы таблицы `k2_user`
--
ALTER TABLE `k2_user`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `LOGIN` (`LOGIN`), ADD KEY `ACTIVE` (`ACTIVE`,`HASH`);

--
-- Индексы таблицы `k2_user_group`
--
ALTER TABLE `k2_user_group`
 ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `k2_user_setting`
--
ALTER TABLE `k2_user_setting`
 ADD KEY `ACTION` (`ACTION`), ADD KEY `USER` (`USER`);

--
-- Индексы таблицы `k2_user_setting_view`
--
ALTER TABLE `k2_user_setting_view`
 ADD KEY `USER` (`USER`), ADD KEY `TYPE` (`TYPE`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `k2_block`
--
ALTER TABLE `k2_block`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT для таблицы `k2_block1`
--
ALTER TABLE `k2_block1`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT для таблицы `k2_block1category`
--
ALTER TABLE `k2_block1category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT для таблицы `k2_block2`
--
ALTER TABLE `k2_block2`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `k2_block2category`
--
ALTER TABLE `k2_block2category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block6`
--
ALTER TABLE `k2_block6`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT для таблицы `k2_block6category`
--
ALTER TABLE `k2_block6category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT для таблицы `k2_block7`
--
ALTER TABLE `k2_block7`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT для таблицы `k2_block7category`
--
ALTER TABLE `k2_block7category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block26`
--
ALTER TABLE `k2_block26`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `k2_block26category`
--
ALTER TABLE `k2_block26category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block27`
--
ALTER TABLE `k2_block27`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `k2_block27category`
--
ALTER TABLE `k2_block27category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block28`
--
ALTER TABLE `k2_block28`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT для таблицы `k2_block28category`
--
ALTER TABLE `k2_block28category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `k2_block29`
--
ALTER TABLE `k2_block29`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block29category`
--
ALTER TABLE `k2_block29category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block30`
--
ALTER TABLE `k2_block30`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT для таблицы `k2_block30category`
--
ALTER TABLE `k2_block30category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block31`
--
ALTER TABLE `k2_block31`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT для таблицы `k2_block31category`
--
ALTER TABLE `k2_block31category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block32`
--
ALTER TABLE `k2_block32`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT для таблицы `k2_block32category`
--
ALTER TABLE `k2_block32category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block33`
--
ALTER TABLE `k2_block33`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `k2_block33category`
--
ALTER TABLE `k2_block33category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block34`
--
ALTER TABLE `k2_block34`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT для таблицы `k2_block34category`
--
ALTER TABLE `k2_block34category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block35`
--
ALTER TABLE `k2_block35`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `k2_block35category`
--
ALTER TABLE `k2_block35category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block36`
--
ALTER TABLE `k2_block36`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `k2_block36category`
--
ALTER TABLE `k2_block36category`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_block_group`
--
ALTER TABLE `k2_block_group`
MODIFY `ID` smallint(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT для таблицы `k2_component`
--
ALTER TABLE `k2_component`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT для таблицы `k2_component_group`
--
ALTER TABLE `k2_component_group`
MODIFY `ID` smallint(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `k2_design`
--
ALTER TABLE `k2_design`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `k2_field`
--
ALTER TABLE `k2_field`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=193;
--
-- AUTO_INCREMENT для таблицы `k2_field_separator`
--
ALTER TABLE `k2_field_separator`
MODIFY `ID` smallint(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT для таблицы `k2_file`
--
ALTER TABLE `k2_file`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=951;
--
-- AUTO_INCREMENT для таблицы `k2_file_dir`
--
ALTER TABLE `k2_file_dir`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT для таблицы `k2_mod_email`
--
ALTER TABLE `k2_mod_email`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `k2_mod_seo`
--
ALTER TABLE `k2_mod_seo`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `k2_mod_shop_cart`
--
ALTER TABLE `k2_mod_shop_cart`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT для таблицы `k2_mod_shop_delivery`
--
ALTER TABLE `k2_mod_shop_delivery`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `k2_mod_shop_order`
--
ALTER TABLE `k2_mod_shop_order`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `k2_mod_shop_order_product`
--
ALTER TABLE `k2_mod_shop_order_product`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `k2_mod_shop_payer`
--
ALTER TABLE `k2_mod_shop_payer`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `k2_mod_shop_payer1`
--
ALTER TABLE `k2_mod_shop_payer1`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `k2_mod_shop_payer2`
--
ALTER TABLE `k2_mod_shop_payer2`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `k2_mod_shop_payment`
--
ALTER TABLE `k2_mod_shop_payment`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `k2_mod_shop_status`
--
ALTER TABLE `k2_mod_shop_status`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `k2_nav`
--
ALTER TABLE `k2_nav`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT для таблицы `k2_section`
--
ALTER TABLE `k2_section`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=99;
--
-- AUTO_INCREMENT для таблицы `k2_section_block`
--
ALTER TABLE `k2_section_block`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=90;
--
-- AUTO_INCREMENT для таблицы `k2_select`
--
ALTER TABLE `k2_select`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT для таблицы `k2_select_option`
--
ALTER TABLE `k2_select_option`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT для таблицы `k2_site`
--
ALTER TABLE `k2_site`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `k2_template`
--
ALTER TABLE `k2_template`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `k2_user`
--
ALTER TABLE `k2_user`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT для таблицы `k2_user_group`
--
ALTER TABLE `k2_user_group`
MODIFY `ID` smallint(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
